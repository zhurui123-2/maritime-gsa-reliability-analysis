from pathlib import Path
import argparse,shutil,subprocess,sys,json
import pandas as pd
import numpy as np
ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
ap.add_argument('--sensitivity-python',type=Path,help='Optional NumPy/pandas interpreter for fixed-backbone enumeration when the main environment has incompatible native BLAS libraries')
a=ap.parse_args()
a.data=a.data.resolve();a.out=a.out.resolve()
code=Path(__file__).resolve().parents[1];a.out.mkdir(parents=True,exist_ok=True)
tasks=[('new_primary','analyze_reexecution.py','analysis/primary_outcomes.csv'),('development','analyze_development.py','analysis/table4_new_execution.csv'),('fixed_backbone','analyze_sensitivity_expanded.py','analysis_expanded/primary_tests_40.csv'),('quality','analyze_data_quality.py','analysis/primary_tests_eight.csv'),('quality_screening','analyze_screening.py','analysis/screening_primary_tests_eight.csv')]
checks=[]
for name,script,key in tasks:
 target=a.out/name
 if target.exists():raise RuntimeError('Use an empty output folder: '+str(target))
 shutil.copytree(code/'current'/name,target)
 shutil.copytree(a.data/'current'/name,target,dirs_exist_ok=True)
 reference=pd.read_csv(a.data/'current'/name/key)
 interpreter=str(a.sensitivity_python.resolve()) if name=='fixed_backbone' and a.sensitivity_python else sys.executable
 command=[interpreter,str(code/'tools'/'reanalyze_quality_summaries.py'),'--root',str(target)] if name=='quality' else [interpreter,str(target/script)]
 subprocess.run(command,check=True,cwd=target)
 regenerated=pd.read_csv(target/key)
 pd.testing.assert_frame_equal(reference,regenerated,check_exact=False,rtol=1e-10,atol=1e-12)
 checks.append({'component':name,'key_table':key,'rows':len(reference),'matched':True})
(a.out/'reanalysis_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
