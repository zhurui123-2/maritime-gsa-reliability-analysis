from pathlib import Path
import argparse,importlib.util

def main():
    parser=argparse.ArgumentParser(description="Regenerate five management and fleet summary tables without training")
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    spec=importlib.util.spec_from_file_location('management_analysis',root/'working'/'management_analysis.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    args.out.mkdir(parents=True,exist_ok=True)
    module.OUT=args.out;module.FIG=args.out/'figures';module.FIG.mkdir(exist_ok=True)
    module.analyze()

if __name__=='__main__':main()
