from pathlib import Path
import argparse,importlib.util,sys

def main():
    parser=argparse.ArgumentParser(description="Train the independent recovery extension with an explicit authorized cohort path")
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    if not args.data.is_file():parser.error('Data file does not exist: '+str(args.data))
    root=Path(__file__).resolve().parents[1]
    path=root/'recovery_extension'/'run_recovery_validation.py'
    spec=importlib.util.spec_from_file_location('recovery_training',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.DATA=args.data.resolve()
    sys.argv=[str(path)]+(['--smoke'] if args.smoke else [])
    module.main()

if __name__=='__main__':main()
