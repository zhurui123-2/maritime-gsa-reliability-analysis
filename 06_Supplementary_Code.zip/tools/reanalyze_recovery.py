from pathlib import Path
import argparse,importlib.util,json,shutil,tempfile

def main():
    parser=argparse.ArgumentParser(description="Regenerate recovery statistics without training or raw vessel records")
    parser.add_argument('--data-tables',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    path=root/'recovery_extension'/'analyze_recovery.py'
    spec=importlib.util.spec_from_file_location('recovery_analysis',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    args.out.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='recovery_reanalysis_',dir=args.out.resolve()) as temp:
        tmp=Path(temp)
        shutil.copy2(args.data_tables/'recovery_all_6000_rounds.csv',tmp/'all_rounds.csv')
        shutil.copy2(args.data_tables/'recovery_all_100_test_results.csv',tmp/'all_test_results.csv')
        shutil.copy2(root/'recovery_extension'/'protocol.json',tmp/'protocol.json')
        module.R=tmp;module.OUT=args.out
        module.main()

if __name__=='__main__':main()
