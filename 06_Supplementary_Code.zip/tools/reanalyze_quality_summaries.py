"""Execute the saved-output portion of the unchanged quality analyzer.

The original analyzer also performs a fresh model/weather-perturbation check
using the non-distributed raw cohort. This wrapper retains every statistical
statement verbatim and omits that separate raw-dependent execution audit.
"""
from pathlib import Path
import argparse,hashlib,json

ap=argparse.ArgumentParser()
ap.add_argument('--root',type=Path,required=True)
args=ap.parse_args()
root=args.root.resolve()
source=root/'analyze_data_quality.py'
text=source.read_text(encoding='utf-8')
marker='    # Test that environmental-value perturbations cannot alter predictions in the frozen class.'
if text.count(marker)!=1:
    raise RuntimeError('Frozen quality analyzer layout changed; inspect before regenerating')
saved_output_program=text.split(marker,1)[0]
namespace={'__name__':'saved_quality_statistics','__file__':str(source)}
exec(compile(saved_output_program,str(source),'exec'),namespace)
namespace['main']()
scope={'scope':'Saved-results statistical regeneration, including all eight Holm-adjusted comparisons and matched pre-stress checks.',
       'executed_analyzer_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
       'statistical_program':'Exact unchanged source statements before the separately marked raw-dependent audit block.',
       'raw_weather_perturbation_check_rerun':False,
       'raw_weather_perturbation_reason':'The raw linked cohort is not distributed. The original execution audit remains archived; it is not relabeled as a regenerated audit.'}
(root/'analysis'/'reanalysis_scope.json').write_text(json.dumps(scope,indent=2),encoding='utf-8')
print(json.dumps(scope,indent=2))
