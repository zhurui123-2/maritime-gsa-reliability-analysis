from pathlib import Path
import runpy
root=Path(__file__).resolve().parent/'weather_free_validation_20261027'
required=['results/all_new_rounds.csv','results/all_new_test_results.csv','inputs/reused_quality_rounds.csv']
missing=[name for name in required if not (root/name).is_file()]
if missing:raise SystemExit('Extract the companion data ZIP here first: '+', '.join(missing))
runpy.run_path(str(root/'analyze_weather_robustness.py'),run_name='__main__')
