# Weather-free severity and recovery validation

320 new formal trajectories contain 15,600 round records. The dose-response
analysis also reuses 160 existing weather-free quality trajectories verbatim.
The three preflight replay trajectories are excluded from scientific analyses.

The plan was fixed before new training. `plan_frozen.json`, worker manifests,
core hashes, splits, per-run outputs, and complete paired statistics are retained.
The original 1,172-vessel cohort and the 1,155 full-year subset are separate
conditions; their results are not pooled as independent fleet samples.

## Recompute statistics without training

From the extracted experiment directory, run:

    python analyze_weather_robustness.py

This reads `results/all_new_rounds.csv`, `results/all_new_test_results.csv`, and
`inputs/reused_quality_rounds.csv`. It uses NumPy and pandas. No raw AIS, weather,
MRV records or trained model weights are required for these statistical summaries.
`plot_weather_recovery.py` additionally requires Matplotlib and regenerates both
weather-free recovery figures from the analysis curves.

## Metric definitions

Severity endpoints are signed cumulative validation-NLL differences over rounds
11–20 and 21–30. Positive-part severity endpoints are also saved descriptively.
The longer recovery primary endpoint sums max(stressed NLL minus matched-clean
NLL, 0) over rounds21–40 after a single disruption or41–60 after the final
recurrent disruption. Tests use ten seed pairs,20,000 paired bootstrap draws,
unadjusted95% intervals, and1,024 exact sign-flip assignments. Holm adjustments
are separate families of8 severity tests and12 recovery tests, as specified
before new outcomes. Seed variability is not external-fleet uncertainty.

## Training

`run_weather_robustness_20261027.py` is the executed local wrapper. It imports the
unchanged `historical_core` snapshot. Retraining requires authorized access to
the original linked cohort with the SHA256 specified in the frozen plan and
appropriate local path routing. There was no GSA parameter, seed or stopping
selection based on new results. All scheduled outcomes are included.

Supplementary material, Highlights and the cover letter are unchanged at the
user's request. This archive records the new experiments independently.
