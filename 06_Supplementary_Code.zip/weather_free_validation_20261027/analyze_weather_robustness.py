from pathlib import Path
from itertools import product
import json,hashlib
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent;B=R.parent;O=R/'analysis';O.mkdir(exist_ok=True)
def write(name,v):(O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def test(delta,**labels):
 delta=np.asarray(delta,float);assert len(delta)==10 and np.isfinite(delta).all()
 rng=np.random.default_rng(41503);boot=delta[rng.integers(0,10,size=(20000,10))].mean(axis=1)
 null=(np.array(list(product([-1,1],repeat=10)))*delta).mean(axis=1)
 return {**labels,'mean_difference':float(delta.mean()),'ci_low':float(np.quantile(boot,.025)),'ci_high':float(np.quantile(boot,.975)),'p_exact':float((abs(null)>=abs(delta.mean())-1e-15).mean()),'n_seed_pairs':10}
def holm(rows):
 order=sorted(range(len(rows)),key=lambda i:rows[i]['p_exact']);last=0.
 for rank,i in enumerate(order):
  last=max(last,min(1.,rows[i]['p_exact']*(len(rows)-rank)));rows[i]['p_holm']=last
 return pd.DataFrame(rows)

def main():
 completion=json.loads((R/'results'/'completion.json').read_text(encoding='utf-8'));assert completion['status']=='COMPLETED'
 new=pd.read_csv(R/'results'/'all_new_rounds.csv');tests=pd.read_csv(R/'results'/'all_new_test_results.csv')
 reuse=R/'inputs'/'reused_quality_rounds.csv'
 old=pd.read_csv(reuse if reuse.exists() else B/'OCM数据质量敏感性_20261024'/'results'/'all_rounds.csv')
 old['family']='dose';old['record_origin']='archived_quality_20261024';new['record_origin']='new_weather_robustness_20261027'
 dose=pd.concat([old,new[new.family=='dose']],ignore_index=True)
 assert len(dose)==8400 and not dose[['regime','seed','scenario','method','round']].duplicated().any()
 assert len(dose.groupby(['regime','seed','scenario','method']))==280
 dose.to_csv(O/'dose_all_rounds_with_reused_records.csv',index=False)
 dose_metrics=[];prechecks=[];curves=[]
 for (regime,seed,scenario,method),g in dose[dose.scenario!='clean'].groupby(['regime','seed','scenario','method']):
  cm='gsa' if method in ['gsa','sa_gsa'] else 'fedavg'
  c=dose[(dose.regime==regime)&(dose.seed==seed)&(dose.scenario=='clean')&(dose.method==cm)]
  g=g.merge(c[['round','validation_nll']],on='round',suffixes=('','_clean')).sort_values('round')
  g['excess']=g.validation_nll-g.validation_nll_clean
  pre=float(g.loc[g['round']<=10,'excess'].abs().max());assert pre<1e-12
  prechecks.append({'family':'dose','regime':regime,'seed':int(seed),'scenario':scenario,'method':method,'pre_stress_max_abs_difference':pre})
  a=g[g['round'].between(11,20)];b=g[g['round'].between(21,30)]
  dose_metrics.append({'regime':regime,'seed':seed,'severity':scenario,'method':method,'stress_signed_excess':float(a.excess.sum()),'recovery_signed_excess':float(b.excess.sum()),'stress_positive_excess':float(a.excess.clip(lower=0).sum()),'recovery_positive_excess':float(b.excess.clip(lower=0).sum())})
 m=pd.DataFrame(dose_metrics);m.to_csv(O/'dose_per_seed.csv',index=False)
 summary=m.groupby(['regime','severity','method']).mean(numeric_only=True).drop(columns='seed').reset_index();summary.to_csv(O/'dose_summary.csv',index=False)
 dose_tests=[]
 for regime in m.regime.unique():
  f=m[(m.regime==regime)&(m.method=='fedavg')]
  mild=f[f.severity=='stale_mild'].set_index('seed').sort_index()
  for severity in ['stale_moderate','stale_severe']:
   b=f[f.severity==severity].set_index('seed').sort_index()
   for endpoint in ['stress_signed_excess','recovery_signed_excess']:
    dose_tests.append(test(b[endpoint].values-mild[endpoint].values,regime=regime,contrast=severity+' minus stale_mild',endpoint=endpoint,mean_proposed=float(b[endpoint].mean()),mean_reference=float(mild[endpoint].mean())))
 holm(dose_tests).to_csv(O/'dose_eight_paired_tests.csv',index=False)
 rec=new[new.family=='recovery'];assert len(rec)==12000
 outcomes=[]
 for (regime,seed,scenario,method),g in rec[rec.scenario!='clean'].groupby(['regime','seed','scenario','method']):
  cm='gsa' if method in ['gsa','sa_gsa'] else 'fedavg'
  clean=rec[(rec.regime==regime)&(rec.seed==seed)&(rec.scenario=='clean')&(rec.method==cm)]
  g=g.merge(clean[['round','validation_nll']],on='round',suffixes=('','_clean')).sort_values('round');g['excess']=g.validation_nll-g.validation_nll_clean
  pre=float(g.loc[g['round']<=10,'excess'].abs().max());assert pre<1e-12
  prechecks.append({'family':'recovery','regime':regime,'seed':int(seed),'scenario':scenario,'method':method,'pre_stress_max_abs_difference':pre})
  end=20 if scenario=='single' else 40;a=g[g['round'].between(end+1,end+20)];stress=g[g.phase=='stress'];crossing=None
  for t in range(end+1,end+19):
   part=a.loc[a['round'].between(t,t+2),'excess']
   if len(part)==3 and (part<=.01).all():crossing=t-end;break
  tr=tests[(tests.family=='recovery')&(tests.regime==regime)&(tests.seed==seed)&(tests.scenario==scenario)&(tests.method==method)].iloc[0]
  premean=float(stress.d_spec_before.mean());postmean=float(stress.d_spec_after.mean())
  outcomes.append({'regime':regime,'seed':seed,'pattern':scenario,'method':method,'recovery_positive_auc':float(a.excess.clip(lower=0).sum()),'recovery_signed_auc':float(a.excess.sum()),'stress_positive_auc':float(stress.excess.clip(lower=0).sum()),'recovered_by20':crossing is not None,'first_recovery_round':crossing,'spectral_reduction_pct':100*(1-postmean/premean) if premean>0 else None,'test_nll':float(tr.nll),'test_macro_f1':float(tr.macro_f1)})
  for _,v in g.iterrows():curves.append({'regime':regime,'seed':int(seed),'pattern':scenario,'method':method,'round':int(v['round']),'excess_nll':float(v.excess)})
 m=pd.DataFrame(outcomes);m.to_csv(O/'recovery_per_seed.csv',index=False)
 pd.DataFrame(curves).to_csv(O/'matched_recovery_curves.csv',index=False)
 summary=m.groupby(['regime','pattern','method']).agg(recovery_positive_auc=('recovery_positive_auc','mean'),recovery_signed_auc=('recovery_signed_auc','mean'),stress_positive_auc=('stress_positive_auc','mean'),recovered_seeds=('recovered_by20','sum'),spectral_reduction_pct=('spectral_reduction_pct','mean'),test_nll=('test_nll','mean'),test_macro_f1=('test_macro_f1','mean')).reset_index();summary.to_csv(O/'recovery_summary.csv',index=False)
 rows=[]
 for regime in m.regime.unique():
  for pattern in ['single','repeated']:
   sub=m[(m.regime==regime)&(m.pattern==pattern)]
   for proposed,reference in [('staleness_decay','fedavg'),('gsa','fedavg'),('sa_gsa','staleness_decay')]:
    a=sub[sub.method==proposed].set_index('seed').sort_index();b=sub[sub.method==reference].set_index('seed').sort_index()
    rows.append(test(a.recovery_positive_auc.values-b.recovery_positive_auc.values,regime=regime,pattern=pattern,contrast=proposed+' minus '+reference,mean_proposed=float(a.recovery_positive_auc.mean()),mean_reference=float(b.recovery_positive_auc.mean())))
 holm(rows).to_csv(O/'recovery_twelve_paired_tests.csv',index=False)
 write('pre_stress_checks.json',prechecks)
 write('validation_summary.json',{'new_runs':320,'new_rounds':15600,'reused_runs':160,'dose_total_runs':280,'recovery_total_runs':200,'all_pre_stress_pairs_match':True,'pre_stress_pairs_checked':len(prechecks),'independent_unit':'10 seed-paired outcomes within each cohort; no independent fleet or year replication','intervals':'Unadjusted95% percentile seed bootstrap20000draws','multiplicity':'Dose8-test family and recovery12-test family','seed_block_extended':False,'all_planned_results_retained':True,'source_note':'Both regimes remain the original vessel cohort or its full-year subset, not new external observations.'})
 print('DOSE');print(holm(dose_tests).to_string(index=False));print('RECOVERY');print(holm(rows).to_string(index=False));print('METHOD MEANS');print(summary.to_string(index=False))
if __name__=='__main__':main()
