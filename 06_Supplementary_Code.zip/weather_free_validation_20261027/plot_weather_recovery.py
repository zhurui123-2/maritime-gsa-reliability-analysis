from pathlib import Path
import os,sys
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parent/'working'/'matplotlib')
_bin=Path(sys.prefix)/'Library'/'bin'
_dll_handle=os.add_dll_directory(str(_bin)) if os.name=='nt' and _bin.exists() else None
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;O=R/'figures';O.mkdir(exist_ok=True)
curves=pd.read_csv(R/'analysis'/'matched_recovery_curves.csv')
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.titlesize':11,'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
methods=[('fedavg','FedAvg','#28648F'),('staleness_decay','Delay weighting','#2C8B79'),('sa_gsa','Weighting + GSA','#C88232')]
for regime in ['all1172_weather_free','full2024_weather_free']:
 fig,axes=plt.subplots(1,2,figsize=(7.3,3.4),sharey=True)
 for ax,pattern,label in zip(axes,['single','repeated'],['(a) Single disruption','(b) Recurrent disruption']):
  for method,name,color in methods:
   g=curves[(curves.regime==regime)&(curves.pattern==pattern)&(curves.method==method)]
   pivot=g.pivot(index='seed',columns='round',values='excess_nll').sort_index();assert pivot.shape==(10,60)
   y=pivot.to_numpy();rng=np.random.default_rng(20261027);b=y[rng.integers(0,10,size=(10000,10))].mean(axis=1)
   low,high=np.quantile(b,[.025,.975],axis=0);x=pivot.columns.to_numpy()
   ax.fill_between(x,low,high,color=color,alpha=.10,linewidth=0)
   ax.plot(x,y.mean(axis=0),color=color,label=name,linewidth=1.7,linestyle='--' if method=='sa_gsa' else '-')
  ax.axvspan(10.5,20.5,color='#9CA3AA',alpha=.16,zorder=-3)
  if pattern=='repeated':ax.axvspan(30.5,40.5,color='#9CA3AA',alpha=.16,zorder=-3)
  ax.axhline(0,color='#6C7379',linewidth=.65,linestyle=':')
  ax.set_xlim(1,60);ax.set_xticks([1,10,20,30,40,50,60]);ax.set_xlabel('Training round')
  ax.grid(axis='y',color='#E4E8EC',linewidth=.55);ax.spines[['left','bottom']].set_color('#69737B')
  ax.text(.5,-.31,label,transform=ax.transAxes,ha='center',va='top',fontweight='bold',fontsize=10)
 axes[0].set_ylabel('Validation NLL excess')
 handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.5,1.01),handlelength=2.2)
 fig.subplots_adjust(left=.10,right=.99,top=.84,bottom=.29,wspace=.13)
 fig.savefig(O/(regime+'_recovery.png'),dpi=400,facecolor='white');fig.savefig(O/(regime+'_recovery.pdf'),facecolor='white');plt.close(fig)
print(str(O))
