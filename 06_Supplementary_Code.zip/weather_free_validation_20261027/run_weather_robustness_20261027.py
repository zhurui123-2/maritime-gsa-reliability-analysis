from pathlib import Path
import argparse,copy,hashlib,json,os,platform,sys,time
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ.setdefault(k,'1')
B=Path(r'D:\ASC投稿');ROOT=B/'OCM无天气机制与恢复补验_20261027';CORE=ROOT/'historical_core'
sys.path.insert(0,str(CORE))
import numpy as np
import pandas as pd
import torch
import run_rebuilt_experiments as base
import run_sa_gsa_confirmatory as historic

OriginalNet=base.MultiModalNet
class WeatherFreeNet(OriginalNet):
 def forward(self,x,mask):
  assert self.modalities==['ais','weather','operations','registry']
  return super().forward(x,mask*mask.new_tensor([1.,0.,1.,1.]))

QUALITY_MEASUREMENTS=copy.deepcopy(historic.MEASUREMENT_ROUNDS)
RECOVERY_MEASUREMENTS={10,11,15,20,21,25,30,31,35,40,41,45,50,60}
ORIGINAL_DELAYS=historic.delays_for;ORIGINAL_PHASE=historic.phase_for
METHODS=['fedavg','gsa','staleness_decay','sa_gsa']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),encoding='utf-8');t.replace(p)
def frame(regime):
 data=Path(json.loads((ROOT/'plan_frozen.json').read_text(encoding='utf-8'))['data_path'])
 assert sha(data)=='03ddbf7bdb9364c0dd07ffdee5be8248a747a8f8ecfbfc13bbec66c3ac4ef0eb'
 f=pd.read_csv(data);assert len(f)==1172
 if regime=='full2024_weather_free':f=f[f.ReportingPeriod.astype(str).str.strip().eq('2024')].copy().reset_index(drop=True);assert len(f)==1155
 if regime!='original_linked':f['weather_time_diff_hours']=0.
 return f
def setup(family,pattern,seed,regime):
 base.MultiModalNet=OriginalNet if regime=='original_linked' else WeatherFreeNet
 cfg=base.load_config();cfg['rounds']=30 if family=='dose' else 60;cfg['local_epochs']=1
 assert cfg['gsa']=={'descriptor_bins':8,'rank_cap':8,'alpha':0.35,'tau':0.9,'ema_beta':0.8,'interval':1,'min_alpha':0.021875,'consensus':'coordinate_median'}
 if family=='dose':
  historic.MEASUREMENT_ROUNDS=QUALITY_MEASUREMENTS;historic.delays_for=ORIGINAL_DELAYS;historic.phase_for=ORIGINAL_PHASE
 else:
  historic.MEASUREMENT_ROUNDS=RECOVERY_MEASUREMENTS
  lag=np.roll(np.array([0,2,4,6,8]),(seed-3001)%5).tolist()
  def schedule(t,s):return lag if pattern!='clean' and (11<=t<=20 or (pattern=='repeated' and 31<=t<=40)) else [0]*5
  def phase(t,s):return 'stress' if any(schedule(t,s)) else ('clean' if t<=10 or pattern=='clean' else 'recovery')
  historic.delays_for=schedule;historic.phase_for=phase
 return cfg
def jobs():
 out=[]
 for regime in ['all1172_weather_free','full2024_weather_free']:
  for seed in range(57,67):
   out += [('dose',regime,seed,'stale_mild',m) for m in METHODS]
   out += [('dose',regime,seed,s,'gsa') for s in ['stale_moderate','stale_severe']]
  for seed in range(3001,3011):
   out += [('recovery',regime,seed,'clean',m) for m in ['fedavg','gsa']]
   out += [('recovery',regime,seed,p,m) for p in ['single','repeated'] for m in METHODS]
 return out
def run(job,folder):
 family,regime,seed,pattern,method=job;cfg=setup(family,pattern,seed,regime)
 stem=f'{regime}__{pattern}__{method}__seed{seed}'
 out=folder/family;rp=out/'runs'/(stem+'.rounds.csv');jp=out/'runs'/(stem+'.result.json')
 if rp.exists() or jp.exists():raise RuntimeError('Refuse automatic overwrite: '+stem)
 f=frame(regime);prepared=base.prepare_data(f,seed)
 assert all(np.isfinite(x).all() for x in prepared.arrays.values())
 sp=out/'splits'/regime/f'seed{seed}.json'
 if not sp.exists():write(sp,{'train':prepared.train_idx.tolist(),'validation':prepared.anchor_idx.tolist(),'test':prepared.test_idx.tolist(),'cutpoints':prepared.train_cutpoints,'features':prepared.feature_names,'dims':prepared.dims})
 start=time.monotonic();rr,result=historic.run_one(prepared,pattern,method,seed,copy.deepcopy(cfg),torch.device('cpu'))
 assert len(rr)==cfg['rounds'] and rr.validation_nll.notna().all()
 rr['regime']=regime;result.update(regime=regime,execution='weather_robustness_20261027')
 rp.parent.mkdir(parents=True,exist_ok=True);rr.to_csv(rp,index=False);write(jp,result)
 return {'stem':stem,'family':family,'seconds':time.monotonic()-start,'rows':len(rr)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--preflight',action='store_true');ap.add_argument('--worker',type=int,default=0);ap.add_argument('--workers',type=int,default=4);ap.add_argument('--combine',action='store_true');args=ap.parse_args()
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 if args.preflight:
  checks=[]
  controls=[('dose','all1172_weather_free',57,'clean','fedavg'),('dose','full2024_weather_free',57,'clean','fedavg'),('recovery','original_linked',3001,'clean','fedavg')]
  for job in controls:
   result=run(job,ROOT/'preflight');family,regime,seed,pattern,method=job
   actual=pd.read_csv(ROOT/'preflight'/family/'runs'/(result['stem']+'.rounds.csv'))
   expected=(B/'OCM数据质量敏感性_20261024'/'results'/'runs'/f'{regime}__clean__fedavg__seed57.rounds.csv') if family=='dose' else B/'OCM可靠性恢复验证_20261021'/'results'/'runs'/'clean__fedavg__seed3001.rounds.csv'
   old=pd.read_csv(expected);delta=float(np.max(abs(actual.validation_nll.to_numpy()-old.validation_nll.to_numpy())))
   assert delta<1e-12,(job,delta)
   checks.append({'control':job,'maximum_validation_nll_difference':delta})
  base.MultiModalNet=WeatherFreeNet;prepared=base.prepare_data(frame('full2024_weather_free'),57)
  base.seed_all(57);net=WeatherFreeNet(prepared.dims,24,16,.1).eval()
  x={m:torch.tensor(v[:8],dtype=torch.float32) for m,v in prepared.arrays.items()};mask=torch.ones((8,4))
  with torch.no_grad():
   a=net(x,mask)[0];x['weather']=torch.ones_like(x['weather'])*100.;b=net(x,mask)[0]
  assert torch.equal(a,b)
  checks.append({'weather_perturbation_changes_prediction':False})
  write(ROOT/'preflight'/'checks.json',checks);print(json.dumps(checks,ensure_ascii=False),flush=True);return
 if args.combine:
  j=jobs();all_r=[];all_t=[]
  for family,regime,seed,pattern,method in j:
   stem=f'{regime}__{pattern}__{method}__seed{seed}';p=ROOT/'results'/family/'runs'
   x=pd.read_csv(p/(stem+'.rounds.csv'));x['family']=family;assert len(x)==(30 if family=='dose' else 60)
   all_r.append(x);v=json.loads((p/(stem+'.result.json')).read_text(encoding='utf-8'));v['family']=family;all_t.append(v)
  rr=pd.concat(all_r,ignore_index=True);tt=pd.DataFrame(all_t)
  assert len(tt)==320 and len(rr)==15600 and not rr[['family','regime','seed','scenario','method','round']].duplicated().any()
  rr.to_csv(ROOT/'results'/'all_new_rounds.csv',index=False);tt.to_csv(ROOT/'results'/'all_new_test_results.csv',index=False)
  write(ROOT/'results'/'completion.json',{'status':'COMPLETED','new_runs':len(tt),'new_round_records':len(rr),'completed_utc':pd.Timestamp.now('UTC').isoformat()});print('COMPLETE',len(tt),len(rr));return
 assert (ROOT/'preflight'/'checks.json').is_file(),'Preflight must pass first'
 def owner(j):
  family,regime,seed,pattern,method=j
  return ((seed-(57 if family=='dose' else 3001))+(10 if regime=='full2024_weather_free' else 0))%args.workers
 selected=[j for j in jobs() if owner(j)==args.worker]
 log=ROOT/'results'/f'progress_worker{args.worker}.json';start=time.monotonic()
 write(ROOT/'results'/f'manifest_worker{args.worker}.json',{'status':'RUNNING','jobs':selected,'wrapper_sha256':sha(__file__),'plan_sha256':sha(ROOT/'plan_frozen.json'),'environment':{'python':sys.version,'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'device':'cpu','threads':1},'started_utc':pd.Timestamp.now('UTC').isoformat()})
 for i,job in enumerate(selected,1):
  info=run(job,ROOT/'results');write(log,{'completed':i,'total':len(selected),'elapsed_seconds':time.monotonic()-start,'last':info})
  print(f'worker{args.worker} {i}/{len(selected)} {info["family"]} {info["stem"]} {info["seconds"]:.2f}s',flush=True)
 write(ROOT/'results'/f'completed_worker{args.worker}.json',{'status':'COMPLETED','jobs':len(selected),'elapsed_seconds':time.monotonic()-start})
if __name__=='__main__':main()
