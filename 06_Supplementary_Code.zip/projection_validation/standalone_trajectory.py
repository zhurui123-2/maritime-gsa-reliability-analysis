from run_validation import *

def standalone_trajectory(df,arrays,enabled,y,tr,va,te,seed,method,lags,out,rounds=60):
    assert not (out/'metrics.csv').exists(),f'Refusing to select or silently reuse existing validation: {out}'
    B.seeds(seed);model=B.Model(arrays,enabled);history=[B.state(model)]
    keys=grouped_keys(model,enabled)
    if method=='ProjectorGSAOnly':
        torch.manual_seed(seed+777000)
        gsa=GradientSpectrumAlignment({n:sum(history[0][k].numel() for k in ks) for n,ks in keys.items()},32)
        optimizer=torch.optim.AdamW(gsa.parameters(),lr=.0005,weight_decay=.0001)
    else:gsa=optimizer=None
    clientids=[tr[df.federated_node.iloc[tr].to_numpy()==c] for c in B.CLIENTS]
    sizes=np.array([len(x) for x in clientids]);yt=torch.tensor(y,dtype=torch.long)
    ids=df.MMSI.iloc[te].to_numpy();co2=df.total_co2_emissions_tonnes.iloc[te].to_numpy(float);nodes=df.federated_node.iloc[te].to_numpy(dtype=str)
    floating=[k for k,v in history[0].items() if v.is_floating_point()]
    rows=[];pr=[];prounds=[];begin=time.perf_counter()
    for r in range(1,rounds+1):
        current=history[-1];lag=np.array(lags if 11<=r<=20 else [0]*5);deltas=[]
        for j,idx in enumerate(clientids):
            local=copy.deepcopy(model);local.load_state_dict(history[max(0,len(history)-1-int(lag[j]))])
            B.local_fit(local,arrays,yt,idx,seed*100000+r*10+j)
            st=B.state(local);deltas.append({k:st[k]-current[k] for k in floating})
        w=sizes.astype(float);w=w/w.sum();assert abs(w.sum()-1)<1e-12
        updates={k:sum(float(a)*d[k] for a,d in zip(w,deltas)) for k in floating}
        diagnostics={}
        if gsa is not None:
            gradients={n:-torch.cat([updates[k].flatten() for k in ks]).detach() for n,ks in keys.items()}
            corrected,projected=gsa.align(gradients,.1)
            objective,diagnostics=gsa.alignment_loss(projected)
            optimizer.zero_grad(set_to_none=True);objective.backward();nn.utils.clip_grad_norm_(gsa.parameters(),5.);optimizer.step()
            correction_norm=[];gradient_norm=[]
            for n,ks in keys.items():
                value=-corrected[n].detach();offset=0
                correction_norm.append(float(torch.linalg.vector_norm(corrected[n].detach()-gradients[n])))
                gradient_norm.append(float(torch.linalg.vector_norm(gradients[n])))
                for k in ks:
                    num=updates[k].numel();updates[k]=value[offset:offset+num].reshape_as(updates[k]);offset+=num
                assert offset==len(value)
            diagnostics['mean_correction_norm']=float(np.mean(correction_norm));diagnostics['mean_original_norm']=float(np.mean(gradient_norm))
        updated={k:current[k]+updates[k] if k in updates else current[k] for k in current}
        assert all(torch.isfinite(v).all() for v in updated.values())
        model.load_state_dict(updated);history.append(B.state(model))
        p=B.predict(model,arrays,te);vp=B.predict(model,arrays,va)
        assert np.isfinite(p).all() and np.max(np.abs(p.sum(1)-1))<1e-8
        row={'round':r,'val_nll':float(B.log_loss(y[va],vp,labels=np.arange(5))),**B.metrics(y[te],co2,p,ids,nodes),**diagnostics}
        high=(y[te]==4)
        row['high_count_10']=row['recall_10']*int(high.sum());row['selected_tonnes_10']=row['emission_coverage_10']*co2.sum()
        rows.append(row)
        if r in [10,20,30,60]:pr.append(p);prounds.append(r)
    out.mkdir(parents=True,exist_ok=True);pd.DataFrame(rows).to_csv(out/'metrics.csv',index=False)
    np.savez_compressed(out/'predictions.npz',probabilities=np.stack(pr),rounds=prounds,labels=y[te],co2=co2,nodes=nodes,ids=ids)
    dump(out/'run.json',{'seed':seed,'method':method,'lags':list(map(int,lags)),'rounds':rounds,'runtime_seconds':time.perf_counter()-begin})
    return pd.DataFrame(rows)
