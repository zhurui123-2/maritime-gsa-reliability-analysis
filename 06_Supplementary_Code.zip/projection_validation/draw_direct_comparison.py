from pathlib import Path
import json,hashlib
import pandas as pd
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.colors import HexColor
import pypdfium2 as pdfium
R=Path(__file__).resolve().parent;F=R/'Figures';F.mkdir(exist_ok=True)
SOURCE=R/'four_method_analysis'/'direct_management_summary.csv'
d=pd.read_csv(SOURCE);d=d[d.metric.eq('high_count_10')]
W,H=534,270
pdf=F/'Fig11_direct_GSA_comparison.pdf';png=pdf.with_suffix('.png')
c=Canvas(str(pdf),pagesize=(W,H));c.setTitle('High-emitting vessels identified at a fixed review capacity');c.setAuthor('')
INK='#1C2E3A';GRAY='#64737D';GRID='#E5E9EC'
def txt(x,y,s,size=9,bold=False,align='left',color=INK):
    c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.setFillColor(HexColor(color));getattr(c,{'left':'drawString','center':'drawCentredString','right':'drawRightString'}[align])(x,y,s)
txt(W/2,251,'High-emitting vessels identified among 24 reviewed records',11,bold=True,align='center')
txt(W/2,234,'DW: delay weighting  |  Vertical lines: 95% bootstrap intervals',8.7,align='center',color=GRAY)
lefts=[36,213,390];pw=132;bottom=82;top=216;yp=lambda v:bottom+(top-bottom)*v/24
methods=[('FedAvg',('FedAvg',),'#AAB3BB'),('ProjectorGSAOnly',('GSA',),'#315D7C'),('DelayWeighting',('DW',),'#A5C2BA'),('ProjectorGSA',('GSA+DW',),'#2E8273')]
cells=[('primary','moderate'),('primary','severe'),('no_annual','moderate')]
captions=[('a','Annual inputs retained','Moderate lag'),('b','Annual inputs retained','Severe lag'),('c','Annual inputs removed','Moderate lag')]
points=[]
c.saveState();c.translate(9,(top+bottom)/2);c.rotate(90);txt(0,0,'High emitters identified (n)',8.6,align='center');c.restoreState()
for panel,((reg,sev),(letter,title,subtitle)) in enumerate(zip(cells,captions)):
    left=lefts[panel];right=left+pw
    for tick in [0,6,12,18,24]:
        y=yp(tick);c.setStrokeColor(HexColor('#9CA8B0' if tick==0 else GRID));c.setLineWidth(.65 if tick==0 else .4);c.line(left,y,right,y)
        if panel==0:txt(left-5,y-2.7,str(tick),8.1,align='right',color=GRAY)
    for j,(method,labels,color) in enumerate(methods):
        row=d[(d.regime==reg)&(d.severity==sev)&(d.method==method)];assert len(row)==1;row=row.iloc[0]
        mean,lo,hi=float(row['mean']),float(row.ci_low),float(row.ci_high);assert 0<=lo<=mean<=hi<=24
        x=left+15+34*j;bar=18
        c.setFillColor(HexColor(color));c.rect(x-bar/2,bottom,bar,yp(mean)-bottom,stroke=0,fill=1)
        c.setStrokeColor(HexColor(INK));c.setLineWidth(.75);c.line(x,yp(lo),x,yp(hi));c.line(x-3,yp(lo),x+3,yp(lo));c.line(x-3,yp(hi),x+3,yp(hi))
        txt(x,yp(hi)+4,f'{mean:.1f}',8.7,bold=method.startswith('Projector'),align='center')
        for line,label in enumerate(labels):txt(x,62-line*10,label,8.0,bold=method.startswith('Projector'),align='center',color=INK if method.startswith('Projector') else GRAY)
        points.append({'regime':reg,'severity':sev,'method':method,'high_emitters_identified_mean':mean,'ci_low':lo,'ci_high':hi})
    txt((left+right)/2,27,'('+letter+') '+title,9.0,bold=True,align='center')
    txt((left+right)/2,13,subtitle,8.7,align='center',color=GRAY)
c.save();doc=pdfium.PdfDocument(pdf);doc[0].render(scale=600/72).to_pil().save(png,dpi=(600,600));doc.close()
(F/'Fig11_values.json').write_text(json.dumps({'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'metric':'highest-quintile vessel count in a 24-record review list; descriptive','points':points,'figure_size_points':[W,H]},indent=2),encoding='utf-8')
print(str(png))
