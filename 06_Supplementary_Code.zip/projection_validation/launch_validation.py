from pathlib import Path
import json,sys,subprocess,time,hashlib
R=Path(__file__).resolve().parent
plan=json.loads((R/'validation_plan_frozen.json').read_text(encoding='utf-8'))
assert plan['dataset_sha256']==hashlib.sha256((R/'data'/'vessels.csv').read_bytes()).hexdigest()
for name,digest in plan['source_fingerprints'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest
groups={'worker_a':[2001,2002,2003,2004],'worker_b':[2005,2006,2007],'worker_c':[2008,2009,2010]}
assert not (R/'results').exists()
procs={};handles={};start=time.time();last=0;warned=False
for name,seeds in groups.items():
    log=open(R/(name+'.log'),'w',encoding='utf-8');handles[name]=log
    cmd=[sys.executable,'-X','utf8',str(R/'run_validation.py'),'--seeds',*map(str,seeds),'--out','results/'+name]
    procs[name]=subprocess.Popen(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(R/'processes.json').write_text(json.dumps({'start_time':start,'plan_sha256':hashlib.sha256((R/'validation_plan_frozen.json').read_bytes()).hexdigest(),'workers':{k:{'pid':p.pid,'seeds':groups[k]} for k,p in procs.items()}},indent=2),encoding='utf-8')
print(json.dumps({'event':'started','workers':{k:p.pid for k,p in procs.items()},'stress_runs':300,'clean_runs':40}),flush=True)
while True:
    elapsed=time.time()-start
    states={k:p.poll() for k,p in procs.items()}
    if elapsed-last>=30 or all(v is not None for v in states.values()):
        progress={}
        for k,p in procs.items():
            path=R/(k+'.log');lines=path.read_text(encoding='utf-8',errors='replace').splitlines()
            latest=next((x for x in reversed(lines) if 'stress_done' in x),'')
            progress[k]={'state':'running' if states[k] is None else 'exit '+str(states[k]),'bytes':path.stat().st_size,'last_progress':json.loads(latest) if latest else None}
        print(json.dumps({'event':'progress','elapsed_seconds':round(elapsed),'workers':progress}),flush=True);last=elapsed
    if all(v is not None for v in states.values()):break
    if elapsed>1740 and not warned:print('Hard timeout in 60 seconds; unfinished workers will be stopped.',flush=True);warned=True
    if elapsed>1800:
        for p in procs.values():
            if p.poll() is None:p.terminate()
        print('Hard timeout reached.',flush=True);sys.exit(124)
    time.sleep(2)
for h in handles.values():h.close()
if any(p.returncode!=0 for p in procs.values()):sys.exit(1)
print('All validation workers completed.',flush=True)
