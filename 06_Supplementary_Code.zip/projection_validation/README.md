# Projection-component comparison

This is the earlier learned projection-space GSA component transferred to the common supervised screening backbone, using seeds2001–2010. It is distinct from the primary parameter-block SVD implementation and the current recovery extension. Supplementary TablesS10–S12 report its results.

Data_Tables/projection_all_600_runs.csv supplies all600 stress summaries; projection_seed_means_four_methods.csv and projection_all_primary_tests_24.csv supply seed aggregation and the complete24-test family. No additional GSA benefit was established. Original training sources and the two analysis plans are preserved here.

Running analyze_four_methods.py as archived requires raw worker curves and completion records from standalone_results/ and analysis/ in addition to the authorized cohort used for retraining. Those worker directories are not included in this distribution. The distributed600-run summaries permit verification of the reported seed-level differences and tests without those training files. Root README specifies which regeneration paths have been tested from the delivered package.
