"""Fixed screening validation of the archived projection-space GSA component.

The GSA class is imported unchanged. The common supervised screening backbone,
leakage exclusions, splits and version-lag semantics come from the existing
management extension. This is a new component-transfer experiment, not a
reproduction of the unidentified primary 57--66 executable.
"""
from pathlib import Path
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='1'
import argparse,copy,hashlib,itertools,json,platform,sys,time,subprocess
import numpy as np
import pandas as pd
import torch
from torch import nn
import base_screening as B
from historical_gsa import GradientSpectrumAlignment

ROOT=Path(__file__).resolve().parent
SEEDS=list(range(2001,2011))
CELLS=[('primary','moderate'),('primary','severe'),('no_annual','moderate')]
METHODS=['DelayWeighting','ProjectorGSA']
SOURCE=Path(r'D:\ASC投稿\OCM_GSA实现核对_20261020')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),encoding='utf-8')

def spec():
    return {'status':'fixed before new validation results; not preregistered',
      'seeds':SEEDS,'excluded_smoke_seed':9000,'conditions':CELLS,'rotations':list(range(5)),
      'rounds':60,'stress_rounds':[11,20],'recovery_rounds':[21,60],
      'methods':METHODS,'primary_budget':.10,'selected_vessels':24,
      'backbone':'unchanged common four 32/16 MLP encoders, gated fusion, five-class head',
      'gsa_source':'unchanged archived repository GradientSpectrumAlignment class',
      'gsa_settings':{'spectrum_dim':32,'nonlinear':False,'structured_dim':None,'learning_rate':.0005,'weight_decay':.0001,'objective_weight':1.,'correction_strength':.1,'gradient_clip':5.,'warmup_rounds':0,'ramp_rounds':0},
      'adaptation':'After delay-weighted FedAvg, flatten each active modality encoder including biases. Negate local-minus-current delta to the historical server-minus-client sign convention. Apply original GSA align and alignment_loss, optimize projectors once, and subtract corrected deltas. Gate and classification head keep their common delay-weighted updates. Disabled annual encoder is excluded from alignment.',
      'local_training':'unchanged base: AdamW lr .003, decay .0001, batch 64, one epoch per round; same local batches across methods',
      'information_exclusions':'No emissions, fuel, fuel/emissions rates, vessel identifiers or names as predictors. Annual block retains time at sea; cargo-density field is all missing.',
      'inferential_unit':'Average five rotations within each seed, pair methods within seed. Ten split seeds on one known cohort, not an external validation population.',
      'primary_family':'12 tests: 3 conditions x 2 endpoints (recall, emission coverage) x 2 contrasts (reduction in matched-clean stress loss, absolute stressed performance gain). Positive contrasts favor GSA.',
      'inference':'10000 paired seed bootstrap resamples; exact two-sided sign flip over 1024 assignments; Holm across all 12 tests',
      'benefit_criterion':'For an endpoint and condition, both matched-clean loss reduction and absolute stressed performance gain must be positive with bootstrap lower bound >0 and Holm p<.05. Report condition-specific support only.',
      'secondary':'Oracle shortfall, high-emitter count per 24 reviews, represented tonnes, NLL, worst-client F1 and recovery are descriptive. No tuning on new validation outcomes.',
      'dataset_sha256':sha(ROOT/'data'/'vessels.csv'),
      'source_fingerprints':{n:sha(ROOT/n) for n in ['run_validation.py','base_screening.py','historical_gsa.py']},
      'planned_stress_runs':300,'planned_clean_runs':40,'hard_timeout_seconds':1800,
      'original_manuscript_figures':'not modified'}

def grouped_keys(model,enabled):
    sd=model.state_dict()
    return {name:[k for k,v in sd.items() if k.startswith('encoders.'+name+'.') and v.is_floating_point()]
            for name,flag in zip(model.names,enabled) if flag}

def trajectory(df,arrays,enabled,y,tr,va,te,seed,method,lags,out,rounds=60):
    assert not (out/'metrics.csv').exists(),f'Refusing to select or silently reuse existing validation: {out}'
    B.seeds(seed);model=B.Model(arrays,enabled);history=[B.state(model)]
    keys=grouped_keys(model,enabled)
    if method=='ProjectorGSA':
        torch.manual_seed(seed+777000)
        gsa=GradientSpectrumAlignment({n:sum(history[0][k].numel() for k in ks) for n,ks in keys.items()},32)
        optimizer=torch.optim.AdamW(gsa.parameters(),lr=.0005,weight_decay=.0001)
    else:gsa=optimizer=None
    clientids=[tr[df.federated_node.iloc[tr].to_numpy()==c] for c in B.CLIENTS]
    sizes=np.array([len(x) for x in clientids]);yt=torch.tensor(y,dtype=torch.long)
    ids=df.MMSI.iloc[te].to_numpy();co2=df.total_co2_emissions_tonnes.iloc[te].to_numpy(float);nodes=df.federated_node.iloc[te].to_numpy(dtype=str)
    floating=[k for k,v in history[0].items() if v.is_floating_point()]
    rows=[];pr=[];prounds=[];begin=time.perf_counter()
    for r in range(1,rounds+1):
        current=history[-1];lag=np.array(lags if 11<=r<=20 else [0]*5);deltas=[]
        for j,idx in enumerate(clientids):
            local=copy.deepcopy(model);local.load_state_dict(history[max(0,len(history)-1-int(lag[j]))])
            B.local_fit(local,arrays,yt,idx,seed*100000+r*10+j)
            st=B.state(local);deltas.append({k:st[k]-current[k] for k in floating})
        w=sizes*np.exp(-.7*lag);w=w/w.sum();assert abs(w.sum()-1)<1e-12
        updates={k:sum(float(a)*d[k] for a,d in zip(w,deltas)) for k in floating}
        diagnostics={}
        if gsa is not None:
            gradients={n:-torch.cat([updates[k].flatten() for k in ks]).detach() for n,ks in keys.items()}
            corrected,projected=gsa.align(gradients,.1)
            objective,diagnostics=gsa.alignment_loss(projected)
            optimizer.zero_grad(set_to_none=True);objective.backward();nn.utils.clip_grad_norm_(gsa.parameters(),5.);optimizer.step()
            correction_norm=[];gradient_norm=[]
            for n,ks in keys.items():
                value=-corrected[n].detach();offset=0
                correction_norm.append(float(torch.linalg.vector_norm(corrected[n].detach()-gradients[n])))
                gradient_norm.append(float(torch.linalg.vector_norm(gradients[n])))
                for k in ks:
                    num=updates[k].numel();updates[k]=value[offset:offset+num].reshape_as(updates[k]);offset+=num
                assert offset==len(value)
            diagnostics['mean_correction_norm']=float(np.mean(correction_norm));diagnostics['mean_original_norm']=float(np.mean(gradient_norm))
        updated={k:current[k]+updates[k] if k in updates else current[k] for k in current}
        assert all(torch.isfinite(v).all() for v in updated.values())
        model.load_state_dict(updated);history.append(B.state(model))
        p=B.predict(model,arrays,te);vp=B.predict(model,arrays,va)
        assert np.isfinite(p).all() and np.max(np.abs(p.sum(1)-1))<1e-8
        row={'round':r,'val_nll':float(B.log_loss(y[va],vp,labels=np.arange(5))),**B.metrics(y[te],co2,p,ids,nodes),**diagnostics}
        high=(y[te]==4)
        row['high_count_10']=row['recall_10']*int(high.sum());row['selected_tonnes_10']=row['emission_coverage_10']*co2.sum()
        rows.append(row)
        if r in [10,20,30,60]:pr.append(p);prounds.append(r)
    out.mkdir(parents=True,exist_ok=True);pd.DataFrame(rows).to_csv(out/'metrics.csv',index=False)
    np.savez_compressed(out/'predictions.npz',probabilities=np.stack(pr),rounds=prounds,labels=y[te],co2=co2,nodes=nodes,ids=ids)
    dump(out/'run.json',{'seed':seed,'method':method,'lags':list(map(int,lags)),'rounds':rounds,'runtime_seconds':time.perf_counter()-begin})
    return pd.DataFrame(rows)

def worker(args):
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    B.ROOT=ROOT;df=B.dataset();out=ROOT/args.out;assert not out.exists(),out
    out.mkdir(parents=True);dump(out/'execution.json',{'seeds':args.seeds,'started':time.time(),'executable':sys.executable,'environment':{'python':sys.version,'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'platform':platform.platform()},'spec':spec()})
    stressrows=[];cleanrows=[];done=0;begin=time.perf_counter()
    for seed in args.seeds:
        tr,va,te,thresholds,y=B.split_data(df,seed)
        for regime in (['primary'] if args.smoke else ['primary','no_annual']):
            arrays,enabled,ledger=B.features(df,tr,regime)
            runroot=out/f'{regime}_s{seed}';runroot.mkdir()
            dump(runroot/'split_and_features.json',{'train':tr.tolist(),'validation':va.tolist(),'test':te.tolist(),'thresholds':thresholds.tolist(),'enabled':enabled,'features':ledger})
            clean={}
            for method in METHODS:
                clean[method]=trajectory(df,arrays,enabled,y,tr,va,te,seed,method,[0]*5,runroot/f'clean_{method}',12 if args.smoke else 60)
                for _,r in clean[method].iterrows():cleanrows.append({'regime':regime,'seed':seed,'method':method,**r.to_dict()})
            for severity in (['moderate'] if args.smoke or regime=='no_annual' else ['moderate','severe']):
                for rotation in ([0] if args.smoke else range(5)):
                    lags=np.roll(B.LAGS[severity],rotation).tolist()
                    for method in METHODS:
                        curve=trajectory(df,arrays,enabled,y,tr,va,te,seed,method,lags,runroot/f'{severity}_r{rotation}_{method}',12 if args.smoke else 60)
                        ref=clean[method];assert np.max(np.abs(curve.nll.iloc[:10]-ref.nll.iloc[:10]))<1e-10
                        rows=[]
                        for _,r in curve.iterrows():
                            rr=int(r['round']);c=ref.iloc[rr-1]
                            rows.append({'regime':regime,'severity':severity,'rotation':rotation,'seed':seed,'method':method,**r.to_dict(),**{f'clean_{k}':float(c[k]) for k in ['recall_10','emission_coverage_10','regret_10','nll','high_count_10','selected_tonnes_10']}})
                        stressrows.extend(rows);done+=1
                        print(json.dumps({'event':'stress_done','seed':seed,'regime':regime,'severity':severity,'rotation':rotation,'method':method,'completed':done,'elapsed_seconds':round(time.perf_counter()-begin,1)}),flush=True)
                        pd.DataFrame(stressrows).to_csv(out/'all_curves.csv',index=False)
            pd.DataFrame(cleanrows).to_csv(out/'clean_curves.csv',index=False)
    dump(out/'completion.json',{'stress_runs':done,'elapsed_seconds':time.perf_counter()-begin,'status':'completed'})

def smoke_unit():
    torch.manual_seed(1234);g=GradientSpectrumAlignment({'ais':17,'weather':25,'registry':39,'annual':9},32)
    vectors={n:torch.randn(p.input_dim) for n,p in g.projectors.items()}
    corrected,payload=g.align(vectors,.1)
    with torch.no_grad():
        projected={n:g.projectors[n].project(x) for n,x in vectors.items()}
        cons=nn.functional.normalize(torch.stack([nn.functional.normalize(x,dim=0) for x in projected.values()]).mean(0),dim=0)
        for n,x in vectors.items():
            expected=x+.1*g.projectors[n].back_project(cons-nn.functional.normalize(projected[n],dim=0))
            assert torch.equal(expected,corrected[n])
    loss,diag=g.alignment_loss(payload);loss.backward();assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in g.parameters())
    dump(ROOT/'smoke_unit.json',{'status':'passed','manual_formula_exact_match':True,'projector_gradients_finite':True,'gsa_module_sha256':sha(ROOT/'historical_gsa.py'),'data_sha256':sha(ROOT/'data'/'vessels.csv')})
    print('Historical align formula and projector gradients passed.',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seeds',nargs='+',type=int);p.add_argument('--out',default='results/worker');p.add_argument('--smoke',action='store_true');p.add_argument('--unit',action='store_true');p.add_argument('--freeze',action='store_true');args=p.parse_args()
    if args.unit:smoke_unit()
    elif args.freeze:
        assert not (ROOT/'results').exists();dump(ROOT/'validation_plan_frozen.json',{'frozen_time_unix':time.time(),**spec()});print('Validation plan frozen.')
    else:worker(args)
