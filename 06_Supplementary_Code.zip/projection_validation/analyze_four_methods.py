from pathlib import Path
import json,itertools
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent;A=R/'four_method_analysis';A.mkdir(exist_ok=True)
CELLS=[('primary','moderate'),('primary','severe'),('no_annual','moderate')]
def ci(v):
    x=np.asarray(v,float);b=np.random.default_rng(90210).choice(x,(10000,len(x)),replace=True).mean(1)
    return float(x.mean()),float(np.quantile(b,.025)),float(np.quantile(b,.975))
def exact(v):
    x=np.asarray(v,float);signs=np.array(list(itertools.product([-1,1],repeat=len(x))))
    return float((np.abs((signs*x).mean(1))>=abs(x.mean())-1e-12).mean())
def holm(p):
    order=np.argsort(p);result=np.empty(len(p));running=0.
    for rank,index in enumerate(order):running=max(running,min(1.,(len(p)-rank)*p[index]));result[index]=running
    return result
workers=sorted((R/'standalone_results').glob('worker_*'));assert len(workers)==3
curves=[]
for w in workers:
    c=json.loads((w/'completion.json').read_text());assert c['status']=='completed'
    curves.append(pd.read_csv(w/'all_curves.csv'))
curves=pd.concat(curves,ignore_index=True);assert len(curves)==18000
ids=['regime','severity','rotation','seed','method'];assert curves.groupby(ids).size().eq(60).all()
assert (curves[curves['round'].le(10)].nll-curves[curves['round'].le(10)].clean_nll).abs().max()<1e-10
rows=[]
for key,g in curves.groupby(ids):
    d=dict(zip(ids,key));s=g[g['round'].between(11,20)]
    for metric in ['recall_10','emission_coverage_10','regret_10','nll','high_count_10','selected_tonnes_10']:
        d['stress_'+metric]=s[metric].mean();d['clean_'+metric]=s['clean_'+metric].mean()
    for low,high,label in [(11,20,'stress'),(21,30,'recovery10'),(51,60,'late_recovery')]:
        z=g[g['round'].between(low,high)];d[label+'_nll_damage']=(z.nll-z.clean_nll).sum()
    d['stress_worst_client_f1']=s.worst_client_f1.mean();rows.append(d)
new=pd.DataFrame(rows);assert len(new)==300
old=pd.read_csv(R/'analysis'/'all_300_runs.csv')
allruns=pd.concat([old,new],ignore_index=True);assert len(allruns)==600
allruns.to_csv(A/'all_600_runs.csv',index=False)
means=allruns.groupby(['regime','severity','seed','method']).mean(numeric_only=True).reset_index();means.to_csv(A/'seed_means_four_methods.csv',index=False)
tests=[];paired=[];summary=[];secondary=[]
contrasts=[('ProjectorGSAOnly','FedAvg','GSA alone vs FedAvg'),('ProjectorGSA','DelayWeighting','GSA added to delay weighting')]
for reg,sev in CELLS:
    g=means[(means.regime==reg)&(means.severity==sev)]
    def pivot(col):return g.pivot(index='seed',columns='method',values=col)
    for left,right,comparison in contrasts:
        for endpoint,metric in [('recall','recall_10'),('coverage','emission_coverage_10')]:
            p=pivot('stress_'+metric);q=pivot('clean_'+metric)
            for contrast,x in [('absolute_stress_gain',100*(p[left]-p[right])),('matched_clean_loss_reduction',100*((q[right]-p[right])-(q[left]-p[left])))]:
                m,lo,hi=ci(x);tests.append({'regime':reg,'severity':sev,'comparison':comparison,'endpoint':endpoint,'contrast':contrast,'mean_pp':m,'ci_low_pp':lo,'ci_high_pp':hi,'raw_p':exact(x),'favorable_seeds':int((x>1e-12).sum()),'unfavorable_seeds':int((x< -1e-12).sum()),'ties':int((x.abs()<=1e-12).sum())})
                paired += [{'regime':reg,'severity':sev,'comparison':comparison,'endpoint':endpoint,'contrast':contrast,'seed':int(seed),'difference_pp':float(value)} for seed,value in x.items()]
        for col in ['stress_high_count_10','stress_selected_tonnes_10','stress_nll_damage','recovery10_nll_damage','late_recovery_nll_damage']:
            p=pivot(col);x=p[left]-p[right];m,lo,hi=ci(x)
            secondary.append({'regime':reg,'severity':sev,'comparison':comparison,'metric':col,'left_minus_right':m,'ci_low':lo,'ci_high':hi,'inferential_status':'descriptive'})
    for method,gg in g.groupby('method'):
        assert len(gg)==10
        for metric,scale in [('high_count_10',1),('recall_10',100),('emission_coverage_10',100),('regret_10',100)]:
            m,lo,hi=ci(scale*gg['stress_'+metric]);summary.append({'regime':reg,'severity':sev,'method':method,'metric':metric,'mean':m,'ci_low':lo,'ci_high':hi,'n_seeds':10})
tests=pd.DataFrame(tests);assert len(tests)==24
tests['holm_p_24']=holm(tests.raw_p.to_numpy());tests['passes_positive_ci_holm']=(tests.mean_pp>0)&(tests.ci_low_pp>0)&(tests.holm_p_24<.05)
support=tests.groupby(['regime','severity','comparison','endpoint']).passes_positive_ci_holm.all().reset_index(name='both_criteria_pass')
tests.to_csv(A/'all_primary_tests_24.csv',index=False);support.to_csv(A/'support_decision.csv',index=False)
pd.DataFrame(paired).to_csv(A/'paired_seed_differences.csv',index=False);pd.DataFrame(summary).to_csv(A/'direct_management_summary.csv',index=False);pd.DataFrame(secondary).to_csv(A/'secondary_differences.csv',index=False)
# All earlier tests remain in the enlarged family, with the same effect sizes.
prior=pd.read_csv(R/'analysis'/'primary_tests_12.csv')
same=tests[tests.comparison.eq('GSA added to delay weighting')]
for r in prior.itertuples():
    x=same[(same.regime==r.regime)&(same.severity==r.severity)&(same.endpoint==r.endpoint)&(same.contrast==r.contrast)].iloc[0]
    assert abs(x.mean_pp-r.mean_pp)<1e-10 and abs(x.raw_p-r.raw_p)<1e-10
decision={'status':'all four methods evaluated on the same screening backbone; supplementary extension',
'stress_runs':600,'clean_runs':40,'new_standalone_stress_runs':300,'all_prior_results_retained':True,'multiplicity_family':24,'support':support.to_dict('records'),
'primary_seeds':list(range(2001,2011)),'primary_budget':'24 of 235 vessel records','component_scope':'Unchanged archived projection-space GSA module transferred to a common screening model; not a reproduction of the unidentified primary manuscript implementation.'}
(A/'verification_summary.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2),encoding='utf-8')
print(tests.to_string(index=False));print('\nDIRECT COUNTS\n'+pd.DataFrame(summary).query('metric=="high_count_10"').to_string(index=False));print('\nSUPPORT\n'+support.to_string(index=False))
