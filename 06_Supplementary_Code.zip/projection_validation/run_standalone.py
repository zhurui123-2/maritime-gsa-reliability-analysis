from run_validation import *
from standalone_trajectory import standalone_trajectory

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,nargs='+',required=True);p.add_argument('--out',required=True);args=p.parse_args()
    plan=json.loads((ROOT/'standalone_plan_frozen.json').read_text(encoding='utf-8'))
    for n,digest in plan['source_fingerprints'].items():assert sha(ROOT/n)==digest
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    B.ROOT=ROOT;df=B.dataset();out=ROOT/args.out;assert not out.exists();out.mkdir(parents=True)
    dump(out/'execution.json',{'started':time.time(),'seeds':args.seeds,'plan':plan})
    rows=[];done=0;begin=time.perf_counter()
    for seed in args.seeds:
        oldroot=next(w for w in (ROOT/'results').glob('worker_*') if (w/f'primary_s{seed}').exists())
        tr,va,te,thresholds,y=B.split_data(df,seed)
        for regime in ['primary','no_annual']:
            arrays,enabled,ledger=B.features(df,tr,regime)
            runroot=out/f'{regime}_s{seed}';runroot.mkdir()
            clean={m:pd.read_csv(oldroot/f'{regime}_s{seed}'/('clean_'+ref)/'metrics.csv') for m,ref in [('FedAvg','DelayWeighting'),('ProjectorGSAOnly','ProjectorGSA')]}
            dump(runroot/'split_and_features.json',{'train':tr.tolist(),'validation':va.tolist(),'test':te.tolist(),'thresholds':thresholds.tolist(),'enabled':enabled,'features':ledger,'clean_references':str(oldroot/f'{regime}_s{seed}')})
            for severity in (['moderate','severe'] if regime=='primary' else ['moderate']):
                for rotation in range(5):
                    lags=np.roll(B.LAGS[severity],rotation).tolist()
                    for method in ['FedAvg','ProjectorGSAOnly']:
                        curve=standalone_trajectory(df,arrays,enabled,y,tr,va,te,seed,method,lags,runroot/f'{severity}_r{rotation}_{method}')
                        ref=clean[method];assert np.max(np.abs(curve.nll.iloc[:10]-ref.nll.iloc[:10]))<1e-10
                        for _,r in curve.iterrows():
                            rr=int(r['round']);c=ref.iloc[rr-1]
                            rows.append({'regime':regime,'severity':severity,'rotation':rotation,'seed':seed,'method':method,**r.to_dict(),**{f'clean_{k}':float(c[k]) for k in ['recall_10','emission_coverage_10','regret_10','nll','high_count_10','selected_tonnes_10']}})
                        done+=1;print(json.dumps({'event':'stress_done','seed':seed,'regime':regime,'severity':severity,'rotation':rotation,'method':method,'completed':done,'elapsed_seconds':round(time.perf_counter()-begin,1)}),flush=True)
                        pd.DataFrame(rows).to_csv(out/'all_curves.csv',index=False)
    dump(out/'completion.json',{'status':'completed','stress_runs':done,'elapsed_seconds':time.perf_counter()-begin})
