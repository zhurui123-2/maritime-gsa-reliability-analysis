from pathlib import Path
import json,subprocess,sys,time,hashlib
R=Path(__file__).resolve().parent
plan=json.loads((R/'standalone_plan_frozen.json').read_text(encoding='utf-8'))
for n,h in plan['source_fingerprints'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h
assert not (R/'standalone_results').exists()
groups={'worker_a':[2001,2002,2003,2004],'worker_b':[2005,2006,2007],'worker_c':[2008,2009,2010]}
procs={};handles={};start=time.time();last=0
for n,seeds in groups.items():
    log=open(R/('standalone_'+n+'.log'),'w',encoding='utf-8');handles[n]=log
    procs[n]=subprocess.Popen([sys.executable,'-X','utf8',str(R/'run_standalone.py'),'--seeds',*map(str,seeds),'--out','standalone_results/'+n],cwd=R,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
print(json.dumps({'event':'started','pids':{n:p.pid for n,p in procs.items()}}),flush=True)
while True:
    elapsed=time.time()-start
    if elapsed-last>=30 or all(p.poll() is not None for p in procs.values()):
        progress={}
        for n,p in procs.items():
            ls=(R/('standalone_'+n+'.log')).read_text(encoding='utf-8',errors='replace').splitlines();ln=next((x for x in reversed(ls) if 'stress_done' in x),None)
            progress[n]={'exit':p.poll(),'progress':json.loads(ln) if ln else None}
        print(json.dumps({'event':'progress','elapsed':round(elapsed),'workers':progress}),flush=True);last=elapsed
    if all(p.poll() is not None for p in procs.values()):break
    if elapsed>1800:
        print('Hard timeout reached; stopping unfinished workers.',flush=True)
        for p in procs.values():
            if p.poll() is None:p.terminate()
        sys.exit(124)
    time.sleep(2)
for h in handles.values():h.close()
sys.exit(0 if all(p.returncode==0 for p in procs.values()) else 1)
