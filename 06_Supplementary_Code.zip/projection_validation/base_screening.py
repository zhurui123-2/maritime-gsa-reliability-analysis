"""Independent exploratory audit; never overwrites manuscript experiments.

Uses the user's 1,172-vessel derived table. No claim of exact reproduction of
the absent primary 57--66 stress-recovery executable is made.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import itertools
import json
import math
import os
import platform
import random
import re
import sys
import time
from pathlib import Path

os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, log_loss, average_precision_score
from sklearn.model_selection import train_test_split
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parent
CLIENTS = ['bulk', 'container', 'general_cargo', 'passenger', 'tanker']
AIS = ['traj_points','avg_speed','max_speed','speed_std','avg_cog','avg_lat','avg_lon']
WEATHER = ['temperature_2m','relative_humidity_2m','surface_pressure',
           'u_wind_10m','v_wind_10m','weather_time_diff_hours']
REGCAT = ['ShipType','PortOfRegistry','vessel_type_ais']
ANNUAL = ['time_at_sea_hours','average_cargo_density']
BUDGETS = [.05,.10,.20]
LAGS = {'moderate':[0,1,2,3,4], 'severe':[0,2,4,6,8]}
METHODS = ['FedAvg','StalenessAware','Combined']
ROUNDS = 60
PRED_ROUNDS = [10,20,30,60]

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str),encoding='utf-8')

def seeds(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)

def dataset():
    df = pd.read_csv(ROOT/'data'/'vessels.csv')
    assert len(df)==1172 and df.MMSI.nunique()==1172 and df.IMO.nunique()==1172
    assert set(df.federated_node)==set(CLIENTS)
    assert df.total_co2_emissions_tonnes.notna().all()
    def efficiency(value):
        match = re.search(r'\(([0-9.]+)',str(value))
        return float(match.group(1)) if match else np.nan
    df['technical_efficiency_numeric'] = df.TechnicalEfficiency.map(efficiency)
    return df

def split_data(df, seed):
    ids = np.arange(len(df))
    tv, test = train_test_split(ids,test_size=.20,random_state=seed,stratify=df.federated_node)
    train, val = train_test_split(tv,test_size=.1875,random_state=seed+10000,
                                  stratify=df.federated_node.iloc[tv])
    train,val,test = [np.sort(x) for x in (train,val,test)]
    thresholds = np.quantile(df.total_co2_emissions_tonnes.iloc[train],[.2,.4,.6,.8])
    y = np.digitize(df.total_co2_emissions_tonnes,thresholds).astype(np.int64)
    return train,val,test,thresholds,y

def features(df, train, regime):
    # All fitting statistics and category vocabularies come from training only.
    arrays={}; ledger={}
    groups={'ais':AIS,'weather':WEATHER,'registry':['technical_efficiency_numeric'],
            'annual':ANNUAL}
    for name,cols in groups.items():
        block=df[cols].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
        med=block.iloc[train].median().fillna(0)
        block=block.fillna(med)
        scaler=StandardScaler().fit(block.iloc[train])
        arrays[name]=np.clip(scaler.transform(block),-10,10).astype('float32')
        ledger[name]={'columns':cols,'train_medians':med.to_dict(),'means':scaler.mean_.tolist(),
                      'scales':scaler.scale_.tolist()}
    enc=OneHotEncoder(handle_unknown='ignore',sparse_output=False,dtype=np.float32)
    cat=df[REGCAT].fillna('MISSING').astype(str)
    enc.fit(cat.iloc[train]); arrays['registry']=np.concatenate([arrays['registry'],enc.transform(cat)],axis=1)
    ledger['registry']['categorical_columns']=REGCAT
    ledger['registry']['categories']=[x.tolist() for x in enc.categories_]
    enabled={'primary':[1,1,1,1],'no_annual':[1,1,1,0],
             'registry_only':[0,0,1,0],'ais_weather':[1,1,0,0]}[regime]
    for name,flag in zip(groups,enabled):
        if not flag: arrays[name]=np.zeros((len(df),1),dtype='float32')
    # The architecture is held constant; disabled modalities are also gate-masked.
    return {k:torch.from_numpy(v) for k,v in arrays.items()},enabled,ledger

class Model(nn.Module):
    def __init__(self,arrays,enabled):
        super().__init__();self.names=list(arrays)
        self.encoders=nn.ModuleDict({name:nn.Sequential(nn.Linear(x.shape[1],32),nn.ReLU(),nn.Linear(32,16))
                                    for name,x in arrays.items()})
        self.gate=nn.Linear(64,4);self.head=nn.Linear(16,5)
        self.register_buffer('enabled',torch.tensor(enabled,dtype=torch.bool))
    def forward(self,arrays,idx):
        encoded=[self.encoders[n](arrays[n][idx]) for n in self.names]
        weights=torch.softmax(self.gate(torch.cat(encoded,1)).masked_fill(~self.enabled,-1e9),1)
        return self.head(sum(weights[:,j:j+1]*x for j,x in enumerate(encoded)))

def state(model):return {k:v.detach().clone() for k,v in model.state_dict().items()}

def local_fit(model,arrays,y,idx,seed,epochs=1):
    rng=np.random.default_rng(seed)
    opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.0001)
    model.train()
    for epoch in range(epochs):
        order=rng.permutation(idx)
        for start in range(0,len(order),64):
            batch=order[start:start+64];opt.zero_grad(set_to_none=True)
            loss=nn.functional.cross_entropy(model(arrays,batch),y[batch]);loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(),5.0);opt.step()

@torch.no_grad()
def predict(model,arrays,idx):
    model.eval();p=torch.softmax(model(arrays,idx),1).numpy().astype(float)
    return np.clip(p,1e-10,1)/np.clip(p,1e-10,1).sum(1,keepdims=True)

def screening(y,co2,score,tiekey,budget):
    n=len(y);k=int(np.ceil(budget*n));order=np.lexsort((tiekey,-score));chosen=order[:k]
    high=(y==4);oracle=np.sort(co2)[-k:].sum();selected=co2[chosen].sum()
    return {'recall':float(high[chosen].sum()/max(high.sum(),1)),
            'precision':float(high[chosen].mean()),'emission_coverage':float(selected/co2.sum()),
            'regret':float((oracle-selected)/max(oracle,1e-12)),'selected_n':k,
            'average_precision':float(average_precision_score(high,score))}

def metrics(y,co2,p,ids,nodes):
    result={'nll':float(log_loss(y,p,labels=np.arange(5))),
            'macro_f1':float(f1_score(y,p.argmax(1),labels=np.arange(5),average='macro',zero_division=0))}
    for budget in BUDGETS:
        values=screening(y,co2,p[:,4],ids,budget)
        result.update({f'{k}_{int(budget*100)}':v for k,v in values.items()})
    fs=[]
    for client in CLIENTS:
        m=nodes==client
        if m.any():
            fs.append(float(f1_score(y[m],p[m].argmax(1),labels=np.arange(5),average='macro',zero_division=0)))
    result['worst_client_f1']=min(fs)
    return result

def align(deltas,ema):
    out=[{k:v.clone() for k,v in d.items()} for d in deltas]
    before=[];after=[]
    keys=[k for k,v in deltas[0].items() if v.ndim==2 and ('.2.weight' in k or k in ['gate.weight','head.weight'])]
    for key in keys:
        svds=[torch.linalg.svd(d[key],full_matrices=False) for d in deltas]
        powers=torch.stack([s.square()/(s.square().sum()+1e-12) for u,s,v in svds])
        consensus=torch.median(powers,dim=0).values;consensus=consensus/(consensus.sum()+1e-12)
        ref=.8*ema[key]+.2*consensus if key in ema else consensus
        ref=ref/(ref.sum()+1e-12);ema[key]=ref.clone()
        for i,(u,s,v) in enumerate(svds):
            original=deltas[i][key];original_norm=torch.linalg.vector_norm(original)
            alpha=.35;candidate=original
            while alpha>=.35/16:
                target=(1-alpha)*powers[i]+alpha*ref
                new=(u*torch.sqrt(torch.clamp(target,min=0)).unsqueeze(0))@v
                new*=original_norm/(torch.linalg.vector_norm(new)+1e-12)
                cosine=nn.functional.cosine_similarity(original.flatten(),new.flatten(),dim=0)
                if float(cosine)>=.90:candidate=new;break
                alpha*=.5
            out[i][key]=candidate
            newpower=torch.linalg.svdvals(candidate).square();newpower/=newpower.sum()+1e-12
            before.append(float(torch.abs(powers[i]-ref).sum()))
            after.append(float(torch.abs(newpower-ref).sum()))
            assert abs(float(torch.linalg.vector_norm(candidate)-original_norm))<1e-5
    return out,ema,float(np.mean(before)),float(np.mean(after))

def trajectory(df,arrays,enabled,y,train,val,test,seed,method,lag_vector,out):
    if (out/'metrics.csv').exists():
        return pd.read_csv(out/'metrics.csv')
    seeds(seed);model=Model(arrays,enabled);history=[state(model)];ema={}
    clientids=[train[df.federated_node.iloc[train].to_numpy()==c] for c in CLIENTS]
    sizes=np.array([len(x) for x in clientids]);ids=df.MMSI.iloc[test].to_numpy()
    co2=df.total_co2_emissions_tonnes.iloc[test].to_numpy(float);nodes=df.federated_node.iloc[test].to_numpy(dtype=str)
    yt=torch.tensor(y,dtype=torch.long);rows=[];pr=[];weightrows=[]
    begin=time.perf_counter()
    floatkeys=[k for k,v in history[0].items() if v.is_floating_point()]
    for r in range(1,ROUNDS+1):
        current=history[-1];lags=np.asarray(lag_vector if 11<=r<=20 else [0]*5)
        deltas=[]
        for j,idx in enumerate(clientids):
            local=copy.deepcopy(model);local.load_state_dict(history[max(0,len(history)-1-int(lags[j]))])
            local_fit(local,arrays,yt,idx,seed*100000+r*10+j)
            ls=state(local);deltas.append({k:ls[k]-current[k] for k in floatkeys})
        pre=post=float('nan')
        if method=='Combined':deltas,ema,pre,post=align(deltas,ema)
        w=sizes*np.exp(-.7*lags) if method!='FedAvg' else sizes.astype(float)
        w=w/w.sum()
        updated={k:current[k]+sum(float(a)*d[k] for a,d in zip(w,deltas)) if k in floatkeys else current[k]
                 for k in current}
        model.load_state_dict(updated);history.append(state(model))
        vp=predict(model,arrays,val);tp=predict(model,arrays,test)
        row={'round':r,'val_nll':float(log_loss(y[val],vp,labels=np.arange(5))),
             'spectral_pre':pre,'spectral_post':post,**metrics(y[test],co2,tp,ids,nodes)}
        rows.append(row)
        if r in PRED_ROUNDS:pr.append(tp)
        if r==11:
            weightrows=[{'client':c,'train_n':int(s),'lag':int(l),'weight':float(a)}
                        for c,s,l,a in zip(CLIENTS,sizes,lags,w)]
    out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out/'predictions.npz',probabilities=np.stack(pr),rounds=PRED_ROUNDS,
                        ids=ids,labels=y[test],co2=co2,nodes=nodes)
    pd.DataFrame(weightrows).to_csv(out/'client_weights.csv',index=False)
    result=pd.DataFrame(rows);result.to_csv(out/'metrics.csv',index=False)
    dump(out/'run.json',{'seed':seed,'method':method,'lags':list(lag_vector),
                         'runtime_seconds':time.perf_counter()-begin})
    return result

def baselines(df,arrays,enabled,y,train,val,test,seed,regime,clean,results):
    target=results/f'{regime}_s{seed}'/'baseline_metrics.csv'
    if target.exists():return
    ids=df.MMSI.iloc[test].to_numpy();co2=df.total_co2_emissions_tonnes.iloc[test].to_numpy(float)
    nodes=df.federated_node.iloc[test].to_numpy(dtype=str);yt=torch.tensor(y,dtype=torch.long)
    records=[];predictions={}
    seeds(seed);central=Model(arrays,enabled)
    # One epoch per round; optimizer reset schedule matches the federated clients.
    for r in range(1,ROUNDS+1):local_fit(central,arrays,yt,train,seed*100000+r*10+9)
    predictions['CentralMLP']=predict(central,arrays,test)
    localprob=np.empty((len(test),5))
    for j,c in enumerate(CLIENTS):
        seeds(seed);model=Model(arrays,enabled);ix=train[df.federated_node.iloc[train].to_numpy()==c]
        for r in range(1,ROUNDS+1):local_fit(model,arrays,yt,ix,seed*100000+r*10+j)
        mask=nodes==c;localprob[mask]=predict(model,arrays,test[mask])
    predictions['LocalPersonalized']=localprob
    x=np.concatenate([v.numpy() for v in arrays.values()],1)
    classifiers={'RandomForest':RandomForestClassifier(n_estimators=300,min_samples_leaf=3,
                                                      random_state=seed,n_jobs=1),
                 'Logistic':OneVsRestClassifier(LogisticRegression(solver='liblinear',max_iter=3000,C=1.0,random_state=seed))}
    for name,clf in classifiers.items():
        clf.fit(x[train],y[train]);prob=np.zeros((len(test),5));prob[:,clf.classes_]=clf.predict_proba(x[test]);predictions[name]=prob
    bytype={c:np.bincount(y[train[df.federated_node.iloc[train].to_numpy()==c]],minlength=5).astype(float)
            for c in CLIENTS}
    predictions['ShipTypeRule']=np.stack([(bytype[c]+1)/(bytype[c].sum()+5) for c in nodes])
    for name,p in predictions.items():records.append({'regime':regime,'seed':seed,'method':name,
                                                    **metrics(y[test],co2,p,ids,nodes)})
    row=clean.iloc[-1].to_dict();row.update(regime=regime,seed=seed,method='FedAvg');records.append(row)
    pd.DataFrame(records).to_csv(target,index=False)
    np.savez_compressed(target.parent/'baseline_predictions.npz',**predictions,ids=ids,labels=y[test],co2=co2,nodes=nodes)

def run(args):
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    df=dataset();results=ROOT/args.out;results.mkdir(parents=True,exist_ok=True)
    plan={'status':'exploratory; fixed before this run; not preregistered',
          'seeds':args.seeds,'rounds':60,'stress_rounds':[11,20],'recovery_rounds':[21,60],
          'primary_comparisons':['StalenessAware-FedAvg','Combined-StalenessAware'],
          'primary_outcomes':['stress_test_NLL_difference','stress_recall10_loss'],
          'additional_outcomes':['regret10','coverage10','per-client NLL','recovery30','recovery60'],
          'regimes':['primary','no_annual'],'regime_definition':{'primary':'annual time at sea and cargo density retained',
                         'no_annual':'all annual MRV predictors disabled; only AIS/weather/registry remain'},
          'forbidden_predictors':['all emissions','all fuel','emissions/fuel normalized rates','MMSI','IMO','ShipName'],
          'split':'65/15/20; stratified by ship type; thresholds and preprocess fitted only on train',
          'budgets':BUDGETS,'severity':LAGS,'rotations':args.rotations,
          'no_annual_stress':'moderate; all five rotations; same three methods',
          'methods':METHODS,'lambda':.7,'gsa_alpha':.35,'gsa_ema':.8,'gsa_direction_floor':.9,
          'architecture':'4 encoders 32/16; disabled annual encoder masked; gated 16D representation',
          'stale_semantics':'local trained from theta[t-lag]; model difference relative to current theta[t]',
          'protocol_boundary':'independent implementation; differs from supplementary fuel-rich and missing primary code',
          'dataset_sha256':hashlib.sha256((ROOT/'data'/'vessels.csv').read_bytes()).hexdigest(),
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'environment':{'python':sys.version,'torch':torch.__version__,'pandas':pd.__version__,
                         'numpy':np.__version__,'platform':platform.platform(),'processor':platform.processor(),
                         'device':'cpu','threads':1}}
    dump(results/'protocol.json',plan)
    dump(results/'data_audit.json',{'rows':len(df),'unique_mmsi':df.MMSI.nunique(),'unique_imo':df.IMO.nunique(),
                                  'clients':df.federated_node.value_counts().to_dict(),
                                  'missing_annual':df[ANNUAL].isna().sum().to_dict()})
    done=0;allsummary=[];start=time.perf_counter()
    for seed in args.seeds:
        print(json.dumps({'event':'seed_start','seed':seed}),flush=True)
        tr,va,te,thresholds,y=split_data(df,seed)
        for regime in ['primary','no_annual']:
            arrays,enabled,ledger=features(df,tr,regime)
            runroot=results/f'{regime}_s{seed}';runroot.mkdir(exist_ok=True)
            dump(runroot/'split_and_features.json',{'train':tr.tolist(),'validation':va.tolist(),'test':te.tolist(),
                  'thresholds':thresholds.tolist(),'features':ledger,'enabled':enabled})
            clean={}
            for method in ['FedAvg','Combined']:
                clean[method]=trajectory(df,arrays,enabled,y,tr,va,te,seed,method,[0]*5,runroot/f'clean_{method}')
            if not args.smoke:
                print(json.dumps({'event':'baseline_start','seed':seed,'regime':regime}),flush=True)
                baselines(df,arrays,enabled,y,tr,va,te,seed,regime,clean['FedAvg'],results)
                print(json.dumps({'event':'baseline_complete','seed':seed,'regime':regime}),flush=True)
            severities=['moderate'] if regime=='no_annual' or args.smoke else ['moderate','severe']
            for severity in severities:
                for rotation in args.rotations:
                    lags=np.roll(LAGS[severity],rotation).tolist()
                    for method in METHODS:
                        out=runroot/f'{severity}_r{rotation}_{method}'
                        curve=trajectory(df,arrays,enabled,y,tr,va,te,seed,method,lags,out)
                        ref=clean['Combined' if method=='Combined' else 'FedAvg']
                        assert np.max(np.abs(curve.val_nll.iloc[:10]-ref.val_nll.iloc[:10]))<1e-8
                        stress=slice(10,20);recover=slice(20,30);late=slice(50,60)
                        diff=curve.nll.to_numpy()-ref.nll.to_numpy()
                        delta_recall=ref.recall_10.to_numpy()-curve.recall_10.to_numpy()
                        s={'regime':regime,'seed':seed,'severity':severity,'rotation':rotation,'method':method,
                           'stress_nll_damage':float(diff[stress].sum()),
                           'stress_nll_positive':float(np.maximum(diff[stress],0).sum()),
                           'recovery10_nll_residual':float(diff[recover].sum()),
                           'recovery_late_nll_residual':float(diff[late].sum()),
                           'stress_recall10_loss':float(delta_recall[stress].mean()),
                           'stress_regret10_increase':float((curve.regret_10-ref.regret_10).iloc[stress].mean()),
                           'stress_coverage10_loss':float((ref.emission_coverage_10-curve.emission_coverage_10).iloc[stress].mean()),
                           'nll_at30':float(curve.nll.iloc[29]),'nll_at60':float(curve.nll.iloc[-1]),
                           'nll_at20':float(curve.nll.iloc[19]),'stress_absolute_nll':float(curve.nll.iloc[stress].mean()),
                           'stress_absolute_recall10':float(curve.recall_10.iloc[stress].mean()),
                           'recall10_at20':float(curve.recall_10.iloc[19]),'recall10_at60':float(curve.recall_10.iloc[-1]),
                           'macro_f1_at60':float(curve.macro_f1.iloc[-1])}
                        # Group evidence at the end of stress, before observing test outcomes.
                        payload=np.load(out/'predictions.npz');p=payload['probabilities'][1]
                        for client in CLIENTS:
                            mask=payload['nodes']==client
                            s[f'client_nll_{client}']=float(log_loss(payload['labels'][mask],p[mask],labels=np.arange(5)))
                        allsummary.append(s);done+=1
                        pd.DataFrame(allsummary).to_csv(results/'run_summary.csv',index=False)
                        print(json.dumps({'completed_stress_runs':done,'seed':seed,'regime':regime,
                              'severity':severity,'rotation':rotation,'method':method,
                              'elapsed_seconds':round(time.perf_counter()-start,1)}),flush=True)
    dump(results/'completion.json',{'status':'completed','stress_runs':done,'elapsed_seconds':time.perf_counter()-start})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--seeds',type=int,nargs='+',default=list(range(1001,1011)))
    parser.add_argument('--rotations',type=int,nargs='+',default=list(range(5)))
    parser.add_argument('--out',default='results');parser.add_argument('--smoke',action='store_true')
    run(parser.parse_args())
