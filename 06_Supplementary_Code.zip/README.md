# Current manuscript code and evidence

Companion article: **Delayed model updates in collaborative maritime assessment: reliability, recovery and vessel-screening implications**.

## New execution and archived extensions

The missing historical seed57–66 outputs have not been recovered. The current primary estimates use the explicitly identified 24 October2026 new execution, not a restoration of those old files. All180 trajectories and5400 rounds are distributed under current/new_primary/results/. New development and ablation evidence uses only the30-round55-job execution; a superseded60-round work directory is excluded.

| Component | Seeds and implementation | Distributed evidence |
| --- | --- | --- |
| new_primary |57–66;24/16 primary backbone;rank8/eight bins;reciprocal |180 trajectories,5400 rounds;source/config/environment/splits;60 sequential timing runs |
| fixed_backbone |4001–4020;same primary backbone;noGSA;reciprocal/three exponential strengths/buffered local changes |520 trajectories,15600 rounds;all40 tests;initial10-seed plan and documented20-seed amendment |
| quality |57–66;weather mask0 and offset0;1172 and full-year1155 cohorts |160 trajectories,4800 rounds;all8NLL comparisons |
| quality_screening |same80full-year quality trajectories re-executed with read-only test measurement |all2400state checks,7200budget-round rows,anonymous probabilities;all8screening tests |
| development |42–46;30rounds;fixedPYTHONHASHSEED0;post-trainingMIA disabled |55jobs;1500non-local rounds;original local routing outputs;6ablation configurations |

The preceding screening(1001–1010), learned projection(2001–2010), and recovery(3001–3010) sources and numerical outputs remain in their original archive layout. Main and Supplementary text distinguish all implementations.

## Regenerate numerical analyses without raw vessel records

Extract the code ZIP into code/ and data ZIP into data/ under one parent folder. Run from code/:

    python tools/reanalyze_current.py --data ../data --out ../reanalysis

This creates a fresh working layout, copies the archived executed sources and derived numerical outputs, then runs the primary, development, fixed-backbone, quality and corrected-screening analyzers. It performs no training. Requires Python, numpy, pandas, scipy and matplotlib. It compares regenerated key tables with the distributed references. Earlier extensions retain their documented reanalysis entry points.

If the main Python environment has incompatible native BLAS/DLL search paths, use a second interpreter with NumPy and pandas for the fixed-backbone exact enumeration:

    python tools/reanalyze_current.py --data ../data --out ../reanalysis --sensitivity-python C:/path/to/compatible/python.exe

The quality statistics use the unchanged saved-output statements of the archived analyzer. Its separate weather-perturbation model check needs the non-distributed raw cohort and is not rerun by this statistics-only entry point; the original execution audit is retained and the regeneration scope is recorded explicitly. On Windows, activate the main Conda environment before invoking Python so that its native library directory is available.

## Training and source integrity

Executed training sources are archived unchanged, including author-machine paths. new_primary/run_primary_reexecution.py accepts --data and --output; use --full-historical for all180. Other archived scripts expect the authorized hashed cohort at their documented data/vessels.csv locations and, for measurement auditing, the corresponding quality-results path. These path dependencies are stated rather than replaced inside the frozen source. No learned method parameters were selected during packaging. Training requires PyTorch and the recorded original dependencies. file_fingerprints.json verifies distributed files; per-run manifests additionally identify original execution-source hashes.

## Data access and scope

Raw AIS and linked covariates are not redistributed. Split files use row indices. The corrected-screening NPZ files remove MMSI and contain a within-test tie-order rank, labels, reporting-periodCO2, fleet group and predictions; they are explicitly derived distribution copies, while original NPZ files remain in the author audit folder. Fixed-backbone identifier-bearing NPZ files are excluded; complete per-round records support the registered analyses. Original source and original-result hashes are kept separately from distribution hashes. The raw seven-day AIS provider and access conditions have not yet been established from the recovered provenance and require author confirmation before submission.

The application is a retrospective information-masking benchmark. Public MRV totals can be ranked directly when known. High annual volume is not noncompliance; coverage is represented reported emissions, not avoided emissions. Buffered local changes are a fixed-arrival adaptation of an aggregation reference, not a full FedBuff asynchronous/privacy implementation.
