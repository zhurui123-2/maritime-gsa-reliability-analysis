"""New recovery extension using recovered historical code without retuning GSA."""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import os
import shutil
import sys
import time

os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
ROOT = Path(__file__).resolve().parent
SOURCE = Path(r'D:\ASC投稿\OCM运行来源核对_20261021\recovered_project\experiments\gsa_reliability_rebuild')
SNAPSHOT = ROOT / 'historical_core'
if not SNAPSHOT.exists():
    shutil.copytree(SOURCE, SNAPSHOT)
sys.path.insert(0, str(SNAPSHOT))
import numpy as np
import pandas as pd
import torch
import run_rebuilt_experiments as base
import run_sa_gsa_confirmatory as historic

DATA = Path(r'D:\ASC投稿\OCM补充实验_20261019\data\vessels.csv')
METHODS = ['fedavg', 'gsa', 'staleness_decay', 'sa_gsa']
PATTERNS = ['single', 'repeated']

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    frame = pd.read_csv(DATA)
    assert len(frame) == 1172 and frame.MMSI.nunique() == 1172
    cfg = base.load_config()
    cfg['rounds'] = 60
    cfg['local_epochs'] = 1
    assert cfg['gsa'] == {'descriptor_bins':8,'rank_cap':8,'alpha':0.35,'tau':0.9,'ema_beta':0.8,'interval':1,'min_alpha':0.021875,'consensus':'coordinate_median'}
    seed_list = [3000] if args.smoke else list(range(3001, 3011))
    output = ROOT / ('smoke' if args.smoke else 'results')
    jobs = []
    for seed in seed_list:
        jobs += [(seed,'clean',method) for method in ['fedavg','gsa']]
        jobs += [(seed,pattern,method) for pattern in PATTERNS for method in METHODS]
    source_manifest = {p.name:sha(p) for p in sorted(SNAPSHOT.iterdir()) if p.is_file()}
    protocol = {
        'status':'RUNNING','started_at_utc':pd.Timestamp.now('UTC').isoformat(),
        'design':'Independent recovery extension, not restoration of original seed57-66 outputs',
        'seeds':seed_list,'n_runs':len(jobs),'device':'cpu','torch_threads':1,
        'data_path':str(DATA),'data_sha256':sha(DATA),'script_sha256':sha(__file__),
        'historical_core_sha256':source_manifest,'config':cfg,
        'client_order':['container','tanker','bulk','general_cargo','passenger'],
        'lag_profile':[0,2,4,6,8],
        'rotations':'(seed-3001) modulo 5, balanced twice across ten seeds; same assignment within each paired contrast',
        'single_stress_rounds':[11,20],'repeated_stress_rounds':[[11,20],[31,40]],
        'matching':'Clean FedAvg reused for weighting at zero lag; clean GSA reused for GSA plus weighting',
        'primary_endpoint':'Sum of positive matched-clean validation NLL excess over first20 rounds after final stress',
        'primary_contrasts':['gsa minus fedavg','sa_gsa minus staleness_decay'],
        'multiple_testing':'Holm over four primary contrasts, two methods contrasts times two patterns',
        'secondary_endpoints':['positive cumulative stress NLL excess','recovery by NLL excess <=0.01 for three consecutive rounds','spectral discrepancy reduction','runtime','final held-out NLL and macro-F1'],
        'recovery_threshold':'0.01 NLL engineering tolerance, not empirically elicited management threshold',
        'inference':'10 seed pairs; 10000 paired seed bootstrap samples; 1024 exact sign-flip assignments; no parameter tuning',
        'notes':['All outcomes retained regardless of sign. No claim of actual organizations or emissions avoided.',
                 'Balanced assignment varies across seeds; no claim of independent evidence for all fleet assignments.',
                 'Smoke seed3000 excluded from scientific results.'],
    }
    output.mkdir(parents=True, exist_ok=True)
    write(output/'protocol.json', protocol)
    historic.MEASUREMENT_ROUNDS = {10,11,15,20,21,25,30,31,35,40,41,45,50,60}
    started=time.monotonic()
    records=[]
    for index,(seed,pattern,method) in enumerate(jobs,1):
        rotation = (seed-3001)%5
        lag = np.roll(np.array([0,2,4,6,8]), rotation).tolist()
        def schedule(round_idx, scenario):
            active = pattern!='clean' and (11<=round_idx<=20 or (pattern=='repeated' and 31<=round_idx<=40))
            return lag if active else [0]*5
        def phase(round_idx,scenario):
            return 'stress' if any(schedule(round_idx,scenario)) else ('clean' if round_idx<=10 or pattern=='clean' else 'recovery')
        historic.delays_for=schedule
        historic.phase_for=phase
        stem=f'{pattern}__{method}__seed{seed}'
        rp=output/'runs'/(stem+'.rounds.csv')
        jp=output/'runs'/(stem+'.result.json')
        if rp.exists() or jp.exists():
            raise RuntimeError('Refusing automatic restart or overwrite: '+stem)
        t0=time.monotonic()
        prepared=base.prepare_data(frame,seed)
        assert all(np.isfinite(x).all() for x in prepared.arrays.values())
        if method=='fedavg' and pattern=='clean':
            write(output/'splits'/f'seed{seed}.json',{'train':prepared.train_idx.tolist(),'validation':prepared.anchor_idx.tolist(),'test':prepared.test_idx.tolist(),'cutpoints':prepared.train_cutpoints,'features':prepared.feature_names,'dims':prepared.dims})
        rounds,result=historic.run_one(prepared,pattern,method,seed,copy.deepcopy(cfg),torch.device('cpu'))
        rounds['rotation']=rotation
        result['rotation']=rotation
        assert len(rounds)==60 and rounds.validation_nll.notna().all()
        rp.parent.mkdir(exist_ok=True)
        rounds.to_csv(rp,index=False)
        write(jp,result)
        records.append({'index':index,'seed':seed,'pattern':pattern,'method':method,'seconds':time.monotonic()-t0})
        write(output/'progress.json',{'completed':index,'total':len(jobs),'elapsed_seconds':time.monotonic()-started,'last':records[-1]})
        print(f'{index}/{len(jobs)} {stem} seconds={time.monotonic()-t0:.2f}',flush=True)
    all_rounds=pd.concat([pd.read_csv(p) for p in sorted((output/'runs').glob('*.rounds.csv'))],ignore_index=True)
    all_rounds.to_csv(output/'all_rounds.csv',index=False)
    all_results=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((output/'runs').glob('*.result.json'))]
    pd.DataFrame(all_results).to_csv(output/'all_test_results.csv',index=False)
    protocol['status']='COMPLETED'
    protocol['completed_at_utc']=pd.Timestamp.now('UTC').isoformat()
    protocol['elapsed_seconds']=time.monotonic()-started
    protocol['row_count']=len(all_rounds)
    write(output/'protocol.json',protocol)
    write(output/'execution_times.json',records)

if __name__=='__main__':main()
