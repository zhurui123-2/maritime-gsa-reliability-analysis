# Independent recovery extension

Main Sections4.10 and5.10; Main Table11; Supplementary SectionS8 and TableS13. The extension uses the primary parameter-block GSA with unchanged parameters and new seeds3001–3010. It is independent of the original seed57–66 results.

Use tools/reanalyze_recovery.py from the archive root to regenerate the statistics from the distributed round records. Use tools/run_recovery.py with an authorized cohort for a fresh training run. See root README and DATA_ACCESS.md for exact paths and commands. Archived run_recovery_validation.py and historical_core sources are unchanged; file_fingerprints.json and the executed protocol distinguish source from packaging helpers.
