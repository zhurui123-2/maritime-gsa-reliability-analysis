from pathlib import Path
import itertools
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
R=ROOT/'results'
OUT=ROOT/'analysis'
OUT.mkdir(exist_ok=True)
def write(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    protocol=json.loads((R/'protocol.json').read_text(encoding='utf-8'))
    assert protocol['status']=='COMPLETED'
    d=pd.read_csv(R/'all_rounds.csv')
    assert len(d)==6000 and not d[['seed','scenario','method','round']].duplicated().any()
    assert set(d.seed)==set(range(3001,3011))
    tests=pd.read_csv(R/'all_test_results.csv')
    allrows=[];checks=[];curves=[]
    for (seed,scenario,method),g in d[d.scenario!='clean'].groupby(['seed','scenario','method']):
        cleanmethod='gsa' if method in ['gsa','sa_gsa'] else 'fedavg'
        clean=d[(d.seed==seed)&(d.scenario=='clean')&(d.method==cleanmethod)]
        g=g.merge(clean[['round','validation_nll']],on='round',suffixes=('','_clean')).sort_values('round')
        g['excess']=g.validation_nll-g.validation_nll_clean
        checks.append({'seed':int(seed),'scenario':scenario,'method':method,'pre_stress_max_abs_diff':float(g.loc[g['round']<=10,'excess'].abs().max())})
        assert checks[-1]['pre_stress_max_abs_diff']<=1e-12
        end=20 if scenario=='single' else 40
        recovery=g[(g['round']>end)&(g['round']<=end+20)]
        crossing=None
        for start in range(end+1,end+19):
            x=recovery.loc[recovery['round'].between(start,start+2),'excess']
            if len(x)==3 and (x<=0.01).all():crossing=start-end;break
        stress=g[g.phase=='stress']
        tr=tests[(tests.seed==seed)&(tests.scenario==scenario)&(tests.method==method)].iloc[0]
        meanpre=float(stress.d_spec_before.mean());meanpost=float(stress.d_spec_after.mean())
        allrows.append({'seed':int(seed),'pattern':scenario,'method':method,
            'recovery_positive_auc':float(np.maximum(recovery.excess,0).sum()),
            'recovery_signed_auc':float(recovery.excess.sum()),
            'stress_positive_auc':float(np.maximum(stress.excess,0).sum()),
            'recovered_by20':crossing is not None,
            'first_recovery_round':crossing if crossing is not None else np.nan,
            'spectral_reduction_pct':100*(1-meanpost/meanpre) if meanpre>0 else np.nan,
            'spectral_before':meanpre,'spectral_after':meanpost,
            'wall_seconds':float(tr.wall_seconds),'test_nll':float(tr.nll),'test_macro_f1':float(tr.macro_f1)})
        for _,row in g.iterrows():curves.append({'seed':int(seed),'pattern':scenario,'method':method,'round':int(row['round']),'excess_nll':float(row.excess)})
    m=pd.DataFrame(allrows);m.to_csv(OUT/'per_seed_outcomes.csv',index=False)
    pd.DataFrame(curves).to_csv(OUT/'matched_recovery_curves.csv',index=False)
    write('trajectory_checks.json',checks)
    paired=[];secondary=[]
    for pattern in ['single','repeated']:
        for proposed,reference in [('gsa','fedavg'),('sa_gsa','staleness_decay')]:
            a=m[(m.pattern==pattern)&(m.method==proposed)].sort_values('seed')
            b=m[(m.pattern==pattern)&(m.method==reference)].sort_values('seed')
            delta=a.recovery_positive_auc.to_numpy()-b.recovery_positive_auc.to_numpy()
            rng=np.random.default_rng(41503)
            boot=delta[rng.integers(0,10,size=(10000,10))].mean(axis=1)
            null=(np.array(list(itertools.product([-1,1],repeat=10)))*delta).mean(axis=1)
            p=float((abs(null)>=abs(delta.mean())-1e-15).mean())
            paired.append({'pattern':pattern,'contrast':proposed+' minus '+reference,'mean_difference':float(delta.mean()),
                'ci_low':float(np.quantile(boot,.025)),'ci_high':float(np.quantile(boot,.975)),
                'p_exact':p,'mean_proposed':float(a.recovery_positive_auc.mean()),'mean_reference':float(b.recovery_positive_auc.mean()),
                'seeds_improved':int((delta<0).sum()),'n_seeds':10})
            for seed,x in zip(a.seed,delta):secondary.append({'seed':int(seed),'pattern':pattern,'contrast':proposed+' minus '+reference,'recovery_auc_difference':float(x)})
    order=sorted(range(4),key=lambda i:paired[i]['p_exact']);running=0
    for rank,i in enumerate(order):
        running=max(running,min(1.,paired[i]['p_exact']*(4-rank)))
        paired[i]['p_holm']=running
        paired[i]['supports_lower_recovery_damage']=bool(paired[i]['mean_difference']<0 and paired[i]['ci_high']<0 and running<.05)
    pd.DataFrame(paired).to_csv(OUT/'primary_paired_tests.csv',index=False)
    pd.DataFrame(secondary).to_csv(OUT/'paired_seed_differences.csv',index=False)
    summary=m.groupby(['pattern','method']).agg(
        recovery_positive_auc=('recovery_positive_auc','mean'),stress_positive_auc=('stress_positive_auc','mean'),
        recovered_seeds=('recovered_by20','sum'),spectral_reduction_pct=('spectral_reduction_pct','mean'),
        wall_seconds=('wall_seconds','mean'),test_nll=('test_nll','mean'),test_macro_f1=('test_macro_f1','mean')).reset_index()
    summary.to_csv(OUT/'method_summary.csv',index=False)
    write('summary.json',{'runs':100,'round_rows':6000,'seed_pairs':10,'all_pre_stress_pairs_equal':True,
                          'primary_tests':paired,'methods':summary.to_dict('records'),
                          'notes':'New independent extension using recovered core; does not restore original raw primary outputs.'})
    print(pd.DataFrame(paired).to_string(index=False))
    print(summary.to_string(index=False))

if __name__=='__main__':main()
