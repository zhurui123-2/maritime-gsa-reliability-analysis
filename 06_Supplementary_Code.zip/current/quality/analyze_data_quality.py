"""All frozen quality contrasts, with one Holm family of eight."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'historical_core'))
import analyze_sa_gsa_confirmatory as stats

def main():
    out=ROOT/'results';dest=ROOT/'analysis';dest.mkdir(exist_ok=True)
    rounds=pd.read_csv(out/'all_rounds.csv');results=pd.read_csv(out/'all_test_results.csv')
    per=[];audits=[];clean_all=[]
    for regime,g in rounds.groupby('regime'):
        t=results[results.regime==regime]
        p=stats.per_seed_summary(g,t);p['regime']=regime;per.append(p)
        cs,ct=stats.clean_noninferiority(g,t);ct['regime']=regime;clean_all.append(ct)
        for (scenario,method,seed),x in g[g.scenario!='clean'].groupby(['scenario','method','seed']):
            ref=stats.reference_method(method)
            c=g[(g.scenario=='clean')&(g.method==ref)&(g.seed==seed)]
            z=x[x['round']<=10].merge(c[c['round']<=10],on='round',suffixes=('_stress','_clean'))
            delta=float(np.abs(z.validation_nll_stress-z.validation_nll_clean).max());assert delta==0
            audits.append({'regime':regime,'scenario':scenario,'method':method,'seed':int(seed),'pre_stress_max_abs_NLL_difference':delta})
    per=pd.concat(per,ignore_index=True);per.to_csv(dest/'per_seed_outcomes.csv',index=False)
    rows=[];diffs=[]
    for regime,g in per.groupby('regime'):
        for scenario in ['stale_moderate','stale_severe']:
            for method,comparator in [('staleness_decay','fedavg'),('sa_gsa','staleness_decay')]:
                a=g[(g.scenario==scenario)&(g.method==method)].set_index('seed')
                b=g[(g.scenario==scenario)&(g.method==comparator)].set_index('seed')
                delta=(a.stress_excess_nll_auc-b.stress_excess_nll_auc).to_numpy()
                label=f'{regime}:{scenario}:{method}:{comparator}'
                lo,hi=stats.bootstrap_ci(delta,label)
                rows.append({'label':label,'regime':regime,'scenario':scenario,'method':method,'comparator':comparator,
                  'method_mean':float(a.stress_excess_nll_auc.mean()),'comparator_mean':float(b.stress_excess_nll_auc.mean()),
                  'difference':float(delta.mean()),'ci95_low_unadjusted':lo,'ci95_high_unadjusted':hi,
                  'exact_sign_flip_p':stats.exact_sign_flip_p(delta),'relative_reduction':float(-delta.mean()/b.stress_excess_nll_auc.mean()),
                  'improved_seeds':int(np.sum(delta<0)),'n_pairs':len(delta)})
                diffs.extend([{'label':label,'seed':int(seed),'difference':float(v)} for seed,v in zip(a.index,delta)])
    tests=pd.DataFrame(rows);adj=stats.holm(dict(zip(tests.label,tests.exact_sign_flip_p)))
    tests['holm_p']=tests.label.map(adj);tests.to_csv(dest/'primary_tests_eight.csv',index=False)
    pd.DataFrame(diffs).to_csv(dest/'paired_seed_differences.csv',index=False)
    pd.DataFrame(audits).to_csv(dest/'pre_stress_matching.csv',index=False)
    pd.concat(clean_all,ignore_index=True).to_csv(dest/'clean_noninferiority.csv',index=False)
    per.groupby(['regime','scenario','method']).agg(
      n=('seed','size'),stress_damage_mean=('stress_excess_nll_auc','mean'),recovery_residual_mean=('recovery_excess_nll_auc','mean'),
      spectral_after_mean=('stress_d_spec_after','mean'),test_nll_mean=('test_nll','mean'),macro_f1_mean=('test_macro_f1','mean')).reset_index().to_csv(dest/'method_summary.csv',index=False)
    # Test that environmental-value perturbations cannot alter predictions in the frozen class.
    import run_data_quality as experiment
    import torch
    original=pd.read_csv(ROOT/'data'/'vessels.csv');original['weather_time_diff_hours']=0.0
    prepared=experiment.base.prepare_data(original,57)
    model=experiment.WeatherFreeNet(prepared.dims,24,16,.1);model.eval()
    x={k:torch.from_numpy(v[prepared.anchor_idx[:8]]) for k,v in prepared.arrays.items()}
    other={k:v.clone() for k,v in x.items()};other['weather']=other['weather']*100+777
    with torch.no_grad():
        p,_=model(x,torch.ones(8,4));q,_=model(other,torch.ones(8,4))
    assert torch.equal(p,q)
    checks={'trajectories':len(results),'round_rows':len(rounds),'all_pre_stress_exactly_match':True,'pre_stress_pairs':len(audits),
      'holm_family_size':len(tests),'weather_value_perturbation_prediction_difference':float(torch.max(torch.abs(p-q))),
      'missing_NLL':int(rounds.validation_nll.isna().sum()),
      'scope':'Conditional quality sensitivity on the same cohort; no independent geographical or annual validation.'}
    (dest/'audit.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    print(tests.to_string(index=False));print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
