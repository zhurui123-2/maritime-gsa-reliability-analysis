"""Frozen weather-free sensitivity; new calculations, no changes to historical source."""
from pathlib import Path
import argparse, copy, hashlib, json, os, platform, sys, time
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ.setdefault(key,'1')
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'historical_core'))
import numpy as np
import pandas as pd
import torch
import scipy,sklearn
import run_rebuilt_experiments as base
import run_sa_gsa_confirmatory as primary

OriginalNet=base.MultiModalNet
class WeatherFreeNet(OriginalNet):
    def forward(self,x,mask):
        assert self.modalities==['ais','weather','operations','registry']
        return super().forward(x,mask*mask.new_tensor([1.,0.,1.,1.]))
base.MultiModalNet=WeatherFreeNet

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),encoding='utf-8');tmp.replace(p)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--shards',type=int,default=1);ap.add_argument('--shard',type=int,default=0)
    ap.add_argument('--inventory',action='store_true');ap.add_argument('--combine',action='store_true');args=ap.parse_args()
    assert 0<=args.shard<args.shards
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    data=ROOT/'data'/'vessels.csv';assert sha(data)=='03ddbf7bdb9364c0dd07ffdee5be8248a747a8f8ecfbfc13bbec66c3ac4ef0eb'
    original=pd.read_csv(data);assert len(original)==1172 and original.MMSI.nunique()==1172
    frames={
      'all1172_weather_free':original.copy(),
      'full2024_weather_free':original[original.ReportingPeriod.astype(str).str.strip().eq('2024')].copy().reset_index(drop=True)}
    assert len(frames['full2024_weather_free'])==1155
    for f in frames.values():f['weather_time_diff_hours']=0.0
    cfg=base.load_config();cfg.update(rounds=30,local_epochs=1,data_path=str(data))
    seed_list=list(range(57,67));shard_seeds=[int(s) for s in np.array_split(seed_list,args.shards)[args.shard]]
    jobs=[]
    for regime in frames:
        for seed in seed_list:
            jobs +=[(regime,seed,'clean',m) for m in ['fedavg','gsa']]
            jobs +=[(regime,seed,s,m) for s in ['stale_moderate','stale_severe'] for m in ['fedavg','staleness_decay','sa_gsa']]
    selected=[j for j in jobs if j[1] in shard_seeds]
    out=ROOT/'results';out.mkdir(exist_ok=True)
    manifest={
      'execution_date':'2026-10-24','status':'RUNNING','design':'Weather-free information sensitivity of recovered primary implementation',
      'started_at_utc':pd.Timestamp.now('UTC').isoformat(),'seeds':seed_list,'n_trajectories':len(jobs),
      'regimes':{'all1172_weather_free':1172,'full2024_weather_free':1155},'shard_seeds':shard_seeds,
      'weather_control':'Weather encoder mask forced to zero in forward for training, validation, testing, and mechanism measurement; weather_time_diff_hours set to zero before preprocessing',
      'reporting_filter':"ReportingPeriod.astype(str).str.strip().eq('2024')",'config':cfg,
      'data_sha256':sha(data),'wrapper_sha256':sha(__file__),
      'historical_sources_sha256':{p.name:sha(p) for p in sorted((ROOT/'historical_core').iterdir()) if p.is_file()},
      'environment':{'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'device':'cpu','torch_threads':1},
      'client_order':['container','tanker','bulk','general_cargo','passenger'],
      'lag_profiles':{'stale_moderate':[0,1,2,3,4],'stale_severe':[0,2,4,6,8]},
      'primary_endpoint':'Signed cumulative matched-clean validation NLL excess over stress rounds11-20',
      'primary_comparisons':['staleness_decay minus fedavg','sa_gsa minus staleness_decay'],
      'inference':'Within-regime seed-paired contrasts; unadjusted 20000 seed bootstrap; exact 1024 sign flips; Holm across 8 contrasts (2regimes*2severities*2method contrasts)',
      'scope':'Filtering and weather removal jointly audited; no causal decomposition of their separate effects. Repeated training/splits on the same vessel cohort are not independent fleet replications.'}
    write(out/f'manifest_shard{args.shard}.json',manifest)
    if args.inventory:print(json.dumps(manifest,ensure_ascii=False,indent=2));return
    if args.combine:
        rr=[];tt=[]
        for regime,seed,scenario,method in jobs:
            stem=f'{regime}__{scenario}__{method}__seed{seed}'
            x=pd.read_csv(out/'runs'/(stem+'.rounds.csv'));assert len(x)==30
            rr.append(x);tt.append(json.loads((out/'runs'/(stem+'.result.json')).read_text(encoding='utf-8')))
        r=pd.concat(rr,ignore_index=True);t=pd.DataFrame(tt)
        assert not r[['regime','scenario','method','seed','round']].duplicated().any() and r.validation_nll.notna().all()
        r.to_csv(out/'all_rounds.csv',index=False);t.to_csv(out/'all_test_results.csv',index=False)
        manifest.update(status='COMPLETED',round_rows=len(r),completed_trajectories=len(t));write(out/'protocol.json',manifest)
        print('COMPLETED',len(t),len(r));return
    start=time.monotonic()
    for i,(regime,seed,scenario,method) in enumerate(selected,1):
        stem=f'{regime}__{scenario}__{method}__seed{seed}'
        rp=out/'runs'/(stem+'.rounds.csv');jp=out/'runs'/(stem+'.result.json')
        if rp.exists() or jp.exists():raise RuntimeError('Refusing overwrite or partial restart: '+stem)
        prepared=base.prepare_data(frames[regime],seed)
        sp=out/'splits'/regime/f'seed{seed}.json'
        if not sp.exists():write(sp,{'train':prepared.train_idx.tolist(),'validation':prepared.anchor_idx.tolist(),'test':prepared.test_idx.tolist(),
          'train_MMSI':frames[regime].MMSI.iloc[prepared.train_idx].tolist(),'validation_MMSI':frames[regime].MMSI.iloc[prepared.anchor_idx].tolist(),
          'test_MMSI':frames[regime].MMSI.iloc[prepared.test_idx].tolist(),'train_cutpoints':prepared.train_cutpoints,'features':prepared.feature_names,'dims':prepared.dims})
        t0=time.monotonic();r,result=primary.run_one(prepared,scenario,method,seed,copy.deepcopy(cfg),torch.device('cpu'))
        assert len(r)==30 and r.validation_nll.notna().all()
        r['regime']=regime;result.update(regime=regime,execution='data_quality_20261024',cohort_size=len(frames[regime]))
        rp.parent.mkdir(exist_ok=True);r.to_csv(rp,index=False);write(jp,result)
        progress={'completed':i,'total':len(selected),'elapsed_seconds':time.monotonic()-start,'last':stem,'run_seconds':time.monotonic()-t0}
        write(out/f'progress_shard{args.shard}.json',progress)
        print(f'{i}/{len(selected)} {stem} seconds={progress["run_seconds"]:.2f}',flush=True)
    manifest.update(status='COMPLETED',elapsed_seconds=time.monotonic()-start,completed_at_utc=pd.Timestamp.now('UTC').isoformat())
    write(out/f'manifest_shard{args.shard}.json',manifest)

if __name__=='__main__':main()
