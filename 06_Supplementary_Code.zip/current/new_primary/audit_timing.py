from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parent;out=ROOT/'exclusive_timing'
df=pd.read_csv(out/'all_timing_runs.csv');assert len(df)==60
wide=df.pivot(index=['scenario','seed'],columns='method',values='wall_seconds').rename(columns={m:m+'_seconds' for m in ['fedavg','staleness_decay','sa_gsa']}).reset_index()
wide.to_csv(out/'timing_seed_pairs_wide.csv',index=False)
checks=[]
for p in sorted((out/'runs').glob('*.json')):
    r=json.loads(p.read_text(encoding='utf-8'));old=json.loads((ROOT/'results'/'runs'/(p.stem+'.result.json')).read_text(encoding='utf-8'))
    checks.append({'scenario':r['scenario'],'method':r['method'],'seed':r['seed'],
      'test_NLL_identical':r['nll']==old['nll'],'test_macro_F1_identical':r['macro_f1']==old['macro_f1'],
      'test_NLL_difference':r['nll']-old['nll']})
pd.DataFrame(checks).to_csv(out/'same_pipeline_outcome_checks.csv',index=False)
report={'measured_trajectories':60,'seed_pairs_per_severity':10,'warmup_trajectories_excluded':3,
  'all_test_NLL_identical_to_primary':all(x['test_NLL_identical'] for x in checks),'all_test_macro_F1_identical_to_primary':all(x['test_macro_F1_identical'] for x in checks),
  'input_data_path':str(ROOT/'data'/'vessels.csv'),'config_data_path_note':'Historical config data_path retains the original E drive metadata; prepared arrays are explicitly loaded from local same-hash CSV, not that unused field.',
  'other_experiment_workers':'All primary, data-quality, screening, development, and weight-sensitivity training/statistics completed before this sequential benchmark began.',
  'scope':'Complete original-primary 30-round pipeline including seven diagnostic rounds; no inference about staff costs or practical budget thresholds.'}
(out/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2));print(pd.read_csv(out/'paired_timing_summary.csv').to_string(index=False))
