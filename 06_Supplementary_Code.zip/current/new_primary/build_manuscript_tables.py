"""Machine-readable primary tables and limited old-versus-new comparison."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
out=ROOT/'results';dest=ROOT/'analysis'
per=pd.read_csv(out/'sa_gsa_per_seed.csv');effects=pd.read_csv(out/'sa_gsa_paired_effects.csv');primary=pd.read_csv(out/'sa_gsa_primary_outcomes.csv')
summary=per.groupby(['scenario','method'],as_index=False).agg(
    stress_damage=('stress_excess_nll_auc','mean'),recovery_residual=('recovery_excess_nll_auc','mean'),
    spectral_before=('stress_d_spec_before','mean'),spectral_after=('stress_d_spec_after','mean'),
    test_nll=('test_nll','mean'),test_macro_f1=('test_macro_f1','mean'))
summary.to_csv(dest/'all_five_methods_summary.csv',index=False)
t6=summary[summary.method.isin(['fedavg','staleness_decay','sa_gsa'])].copy()
t6['severity']=t6.scenario.map({'stale_mild':'Mild','stale_moderate':'Moderate','stale_severe':'Severe'})
t6.to_csv(dest/'table6_new_execution.csv',index=False)
old={
('stale_mild','fedavg'):[.259,.518,.029],('stale_mild','staleness_decay'):[.121,.215,.028],('stale_mild','sa_gsa'):[.121,.212,.012],
('stale_moderate','fedavg'):[.504,.997,.028],('stale_moderate','staleness_decay'):[.416,.823,.027],('stale_moderate','sa_gsa'):[.411,.813,.011],
('stale_severe','fedavg'):[.722,1.321,.030],('stale_severe','staleness_decay'):[.585,1.089,.027],('stale_severe','sa_gsa'):[.580,1.076,.011]}
comparison=[]
for _,r in t6.iterrows():
    for index,metric in enumerate(['stress_damage','recovery_residual','spectral_after']):
        value=old[(r.scenario,r.method)][index]
        comparison.append({'scenario':r.scenario,'method':r.method,'metric':metric,'old_displayed_value_3dp':value,'new_full_precision':r[metric],'new_display_3dp':round(r[metric],3),'difference_from_rounded_old':r[metric]-value})
pd.DataFrame(comparison).to_csv(dest/'old_table6_vs_new.csv',index=False)
rows=[]
for s in ['stale_moderate','stale_severe']:
    g=primary[primary.scenario==s].iloc[0]
    f=effects[(effects.scenario==s)&(effects.comparator=='fedavg')&(effects.metric=='stress_excess_nll_auc')].iloc[0]
    rows +=[{'comparison':'combined minus FedAvg','scenario':s,'difference':f.sa_gsa_minus_comparator_mean,
       'relative_reduction':-f.sa_gsa_minus_comparator_mean/f.comparator_mean,'ci95_low_unadjusted':f.ci95_low,'ci95_high_unadjusted':f.ci95_high,
       'raw_exact_p':f.exact_sign_flip_p,'holm_p':None,'better_seeds':int(f.sa_gsa_better_seeds)},
       {'comparison':'combined minus weighting','scenario':s,'difference':g.sa_gsa_minus_comparator_mean,
       'relative_reduction':g.relative_damage_reduction,'ci95_low_unadjusted':g.ci95_low,'ci95_high_unadjusted':g.ci95_high,
       'raw_exact_p':g.exact_sign_flip_p,'holm_p':g.holm_p,'better_seeds':int(g.sa_gsa_better_seeds)}]
    # Use the original table's between-method post-calibration discrepancy definition.
    e=effects[(effects.scenario==s)&(effects.comparator=='staleness_decay')&(effects.metric=='stress_d_spec_after')].iloc[0]
    rows.append({'comparison':'post-spectrum reduction combined versus weighting','scenario':s,'relative_reduction':-e.sa_gsa_minus_comparator_mean/e.comparator_mean,
       'difference':e.sa_gsa_minus_comparator_mean,'ci95_low_unadjusted':e.ci95_low,'ci95_high_unadjusted':e.ci95_high,'raw_exact_p':e.exact_sign_flip_p})
pd.DataFrame(rows).to_csv(dest/'table7_new_execution_scientific_rows.csv',index=False)
source=Path(r'D:\ASC投稿\OCM运行来源核对_20261021\recovered_project\experiments\gsa_reliability_rebuild')
checks=[]
for p in sorted((ROOT/'historical_core').iterdir()):
    if p.is_file():
        other=source/p.name
        checks.append({'file':p.name,'new_snapshot_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
            'recovered_source_exists':other.exists(),'identical_to_recovered_source':other.exists() and p.read_bytes()==other.read_bytes()})
report={'source_comparisons':checks,'all_source_files_identical_to_recovered_project':all(x['identical_to_recovered_source'] for x in checks),
  'effective_parameter_changes':['data_path routes to current same-hash F/D table; rounds=30 and local_epochs=1 follow original primary main() overrides'],
  'confirmed_data_equivalence':'Current F:/航运实验/1/final_four_modal_dataset.csv and current D:/ASC投稿/OCM补充实验_20261019/data/vessels.csv are byte-identical',
  'not_confirmed':['Hash of E:/航运实验/final_four_modal_dataset.csv actually used in August execution','Actual original device, Torch/sklearn versions, CPU thread setting','Exact original per-seed trajectories and unrounded table values'],
  'cause_of_old_new_numeric_differences':'Cannot isolate from available records; do not attribute to runtime, data change, or source change without evidence.',
  'interpretation':'New output replaces missing-output primary claims as a dated re-execution, not a recovery or exact numerical reproduction of original trajectories.'}
(dest/'source_and_difference_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(t6.to_string(index=False));print(pd.DataFrame(rows).to_string(index=False));print('All recovered sources identical:',report['all_source_files_identical_to_recovered_project'])
