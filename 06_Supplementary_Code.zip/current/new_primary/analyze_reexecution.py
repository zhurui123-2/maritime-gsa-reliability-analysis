"""Analyze newly executed primary trajectories without replacing historical data."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'historical_core'))
import analyze_sa_gsa_confirmatory as historic

def main():
    out=ROOT/'results';dest=ROOT/'analysis';dest.mkdir(exist_ok=True)
    rounds=pd.read_csv(out/'sa_gsa_round_metrics.csv')
    results=pd.read_csv(out/'sa_gsa_test_results.csv')
    per=historic.per_seed_summary(rounds,results)
    per.to_csv(dest/'per_seed_summary.csv',index=False)
    clean_seed,clean_summary=historic.clean_noninferiority(rounds,results)
    clean_seed.to_csv(dest/'clean_per_seed.csv',index=False)
    clean_summary.to_csv(dest/'clean_noninferiority.csv',index=False)
    rows=[]
    for scenario in historic.STRESS_SCENARIOS:
        for method,comparator in [('sa_gsa','staleness_decay'),('staleness_decay','fedavg'),('sa_gsa','fedavg')]:
            a=per[(per.scenario==scenario)&(per.method==method)].set_index('seed')
            b=per[(per.scenario==scenario)&(per.method==comparator)].set_index('seed')
            assert list(a.index)==list(b.index)==list(range(57,67))
            for metric in ['stress_excess_nll_auc','recovery_excess_nll_auc','stress_d_spec_after','test_nll','test_macro_f1','wall_seconds']:
                delta=(a[metric]-b[metric]).to_numpy()
                # Original primary comparison uses this exact deterministic bootstrap label.
                label=f'{scenario}:{comparator}:{metric}' if method=='sa_gsa' else f'{scenario}:{method}:{comparator}:{metric}'
                lo,hi=historic.bootstrap_ci(delta,label)
                rows.append({'scenario':scenario,'method':method,'comparator':comparator,'metric':metric,
                  'method_mean':float(a[metric].mean()),'comparator_mean':float(b[metric].mean()),
                  'difference':float(delta.mean()),'ci95_low_unadjusted':lo,'ci95_high_unadjusted':hi,
                  'exact_sign_flip_p':historic.exact_sign_flip_p(delta),'n_pairs':10,
                  'relative_reduction':float(-delta.mean()/b[metric].mean()) if abs(b[metric].mean())>1e-12 else None})
    effects=pd.DataFrame(rows)
    primary=effects[(effects.method=='sa_gsa')&(effects.comparator=='staleness_decay')&(effects.metric=='stress_excess_nll_auc')&effects.scenario.isin(historic.PRIMARY_SCENARIOS)].copy()
    adj=historic.holm(dict(zip(primary.scenario,primary.exact_sign_flip_p)))
    primary['holm_p']=primary.scenario.map(adj)
    primary['confirmed']=(primary.difference<0)&(primary.ci95_high_unadjusted<0)&(primary.holm_p<.05)
    primary.to_csv(dest/'primary_outcomes.csv',index=False)
    effects.to_csv(dest/'paired_effects.csv',index=False)
    per.groupby(['scenario','method']).agg(['mean','std']).to_csv(dest/'all_metric_summary.csv')
    audit=[]
    for (scenario,method,seed),g in rounds[rounds.scenario!='clean'].groupby(['scenario','method','seed']):
        reference=historic.reference_method(method)
        r=rounds[(rounds.scenario=='clean')&(rounds.method==reference)&(rounds.seed==seed)]
        x=g[g['round']<=10].merge(r[r['round']<=10],on='round',suffixes=('_stress','_clean'),validate='one_to_one')
        maximum=float(np.abs(x.validation_nll_stress-x.validation_nll_clean).max())
        assert maximum==0.0
        audit.append({'scenario':scenario,'method':method,'seed':int(seed),'pre_stress_max_abs_NLL_difference':maximum})
    spectrum=[]
    for s,g in per[per.method=='sa_gsa'].groupby('scenario'):
        spectrum.append({'scenario':s,'mean_before':float(g.stress_d_spec_before.mean()),'mean_after':float(g.stress_d_spec_after.mean()),
             'relative_reduction':float(1-g.stress_d_spec_after.mean()/g.stress_d_spec_before.mean())})
    pd.DataFrame(spectrum).to_csv(dest/'spectral_reduction.csv',index=False)
    checks={'n_trajectories':len(results),'n_rounds':len(rounds),'n_pre_stress_checks':len(audit),
        'all_pre_stress_exactly_match':True,'duplicate_round_keys':int(rounds[['scenario','method','seed','round']].duplicated().sum()),
        'missing_primary_round_NLL':int(rounds.validation_nll.isna().sum()),'primary_confirmed':int(primary.confirmed.sum()),
        'primary_total':len(primary),'clean_noninferiority_all_passed':bool(clean_summary.passed.all()),
        'runtime_caution':'Three independent seed shards ran concurrently; elapsed wall times describe this execution, not a dedicated-hardware benchmark.',
        'scientific_scope':'Same vessel cohort and recovered parameters, newly generated trajectories; not recovered 20260804 output.',
        'methods_present':sorted(results.method.unique().tolist())}
    (dest/'audit.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    pd.DataFrame(audit).to_csv(dest/'pre_stress_matching_checks.csv',index=False)
    print(primary.to_string(index=False));print(clean_summary.to_string(index=False));print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
