"""Sequential same-machine timing; start only after all other training finishes."""
from pathlib import Path
import copy,hashlib,json,os,platform,sys,time
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ.setdefault(key,'1')
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'historical_core'))
import numpy as np
import pandas as pd
import torch
import run_rebuilt_experiments as base
import run_sa_gsa_confirmatory as primary

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')

def main():
    out=ROOT/'exclusive_timing'
    if out.exists():raise RuntimeError('Refusing benchmark restart/overwrite; inspect existing output first')
    out.mkdir();torch.set_num_threads(1);torch.set_num_interop_threads(1)
    frame=pd.read_csv(ROOT/'data'/'vessels.csv');cfg=base.load_config();cfg.update(rounds=30,local_epochs=1)
    methods=['fedavg','staleness_decay','sa_gsa'];seeds=list(range(57,67));scenarios=['stale_moderate','stale_severe']
    jobs=[]
    for i,seed in enumerate(seeds):
        for j,scenario in enumerate(scenarios):
            order=methods[(i+j)%3:]+methods[:(i+j)%3]
            jobs.extend([(seed,scenario,m) for m in order])
    protocol={'status':'RUNNING','execution_date':'2026-10-24','started_at_utc':pd.Timestamp.now('UTC').isoformat(),
      'purpose':'Dedicated sequential timing after other experiment workers finish; same process and CPU thread cap for all methods',
      'seeds':seeds,'scenarios':scenarios,'methods':methods,'n_measured_runs':60,'warmups':3,
      'order':'Cyclic method order shifted by seed index plus severity index',
      'timed_scope':'Historical run_one wall_seconds: 30 rounds of local training, diagnostics, validation and final held-out evaluation; excludes imports and data preparation.',
      'config':cfg,'wrapper_sha256':sha(__file__),'data_sha256':sha(ROOT/'data'/'vessels.csv'),
      'historical_sources_sha256':{p.name:sha(p) for p in sorted((ROOT/'historical_core').iterdir()) if p.is_file()},
      'environment':{'python':sys.version,'platform':platform.platform(),'processor':platform.processor(),'torch':torch.__version__,'device':'cpu','torch_threads':1},
      'interpretation':'Measured computational cost on this machine, not staffing cost or a management benefit-cost threshold.'}
    write(out/'protocol.json',protocol)
    warm=[]
    for method in methods:
        prepared=base.prepare_data(frame,56)
        _,r=primary.run_one(prepared,'stale_moderate',method,56,copy.deepcopy(cfg),torch.device('cpu'))
        warm.append(r)
    write(out/'warmup_results_excluded.json',warm)
    records=[];start=time.monotonic()
    for i,(seed,scenario,method) in enumerate(jobs,1):
        prepared=base.prepare_data(frame,seed);cpu0=time.process_time();wall0=time.perf_counter()
        _,r=primary.run_one(prepared,scenario,method,seed,copy.deepcopy(cfg),torch.device('cpu'))
        r.update(order=i,outer_wall_seconds=time.perf_counter()-wall0,process_cpu_seconds=time.process_time()-cpu0)
        records.append(r);write(out/'runs'/f'{scenario}__{method}__seed{seed}.json',r)
        pd.DataFrame(records).to_csv(out/'all_timing_runs.csv',index=False)
        print(f'{i}/60 {scenario} {method} seed{seed} wall={r["wall_seconds"]:.4f}',flush=True)
    df=pd.DataFrame(records);df.groupby(['scenario','method']).wall_seconds.agg(['mean','std','min','max']).reset_index().to_csv(out/'timing_summary.csv',index=False)
    import analyze_sa_gsa_confirmatory as stats
    comparisons=[];paired=[]
    for scenario in scenarios:
        a=df[(df.scenario==scenario)&(df.method=='sa_gsa')].set_index('seed')
        for comparator in ['fedavg','staleness_decay']:
            b=df[(df.scenario==scenario)&(df.method==comparator)].set_index('seed')
            delta=a.wall_seconds-b.wall_seconds
            lo,hi=stats.bootstrap_ci(delta.to_numpy(),f'timing:{scenario}:{comparator}')
            comparisons.append({'scenario':scenario,'method':'sa_gsa','comparator':comparator,'n_pairs':10,
              'method_mean_seconds':float(a.wall_seconds.mean()),'comparator_mean_seconds':float(b.wall_seconds.mean()),
              'mean_difference_seconds':float(delta.mean()),'ci95_low_unadjusted':lo,'ci95_high_unadjusted':hi,
              'relative_mean_time_increase':float(a.wall_seconds.mean()/b.wall_seconds.mean()-1)})
            paired.extend([{'scenario':scenario,'comparator':comparator,'seed':int(s),'wall_seconds_difference':float(v)} for s,v in delta.items()])
    pd.DataFrame(comparisons).to_csv(out/'paired_timing_summary.csv',index=False)
    pd.DataFrame(paired).to_csv(out/'paired_seed_timing.csv',index=False)
    protocol.update(status='COMPLETED',completed_at_utc=pd.Timestamp.now('UTC').isoformat(),elapsed_seconds=time.monotonic()-start)
    write(out/'protocol.json',protocol)
    print(pd.DataFrame(comparisons).to_string(index=False))

if __name__=='__main__':main()
