"""New execution of recovered primary code; never masquerades as old output.

Default: 110 trajectories (two clean references, three methods x three severities).
--full-historical: all 180 trajectories of the recovered 57--66 protocol.
Parallel processes must use distinct --shard values with the same --shards count.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import os
import platform
import sys
import time

for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key, '1')
ROOT = Path(__file__).resolve().parent
CORE = ROOT / 'historical_core'
sys.path.insert(0, str(CORE))
import numpy as np
import pandas as pd
import torch
import scipy
import sklearn
import run_rebuilt_experiments as base
import run_sa_gsa_confirmatory as primary

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    temp.replace(path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', type=Path, default=ROOT/'data'/'vessels.csv')
    ap.add_argument('--output', type=Path, default=ROOT/'results')
    ap.add_argument('--seeds', nargs='+', type=int, default=list(range(57,67)))
    ap.add_argument('--full-historical', action='store_true')
    ap.add_argument('--shards', type=int, default=1)
    ap.add_argument('--shard', type=int, default=0)
    ap.add_argument('--inventory', action='store_true', help='Validate data and configuration without training')
    ap.add_argument('--combine', action='store_true', help='Combine completed runs; no training')
    args = ap.parse_args()
    if not 0 <= args.shard < args.shards:
        raise ValueError('Require 0 <= shard < shards')
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    cfg=base.load_config()
    cfg.update(data_path=str(args.data.resolve()),rounds=30,local_epochs=1)
    expected={'descriptor_bins':8,'rank_cap':8,'alpha':0.35,'tau':0.9,'ema_beta':0.8,'interval':1,'min_alpha':0.021875,'consensus':'coordinate_median'}
    assert cfg['gsa']==expected
    frame=pd.read_csv(args.data)
    assert len(frame)==1172 and frame.MMSI.nunique()==1172
    assert sha(args.data)=='03ddbf7bdb9364c0dd07ffdee5be8248a747a8f8ecfbfc13bbec66c3ac4ef0eb'
    clean=['fedavg','fedprox','gsa'] if args.full_historical else ['fedavg','gsa']
    stress=['fedavg','fedprox','gsa','staleness_decay','sa_gsa'] if args.full_historical else ['fedavg','staleness_decay','sa_gsa']
    all_jobs=[]
    for seed in args.seeds:
        all_jobs += [(seed,'clean',method) for method in clean]
        all_jobs += [(seed,scenario,method) for scenario in ['stale_mild','stale_moderate','stale_severe'] for method in stress]
    shard_seeds=[int(s) for s in np.array_split(args.seeds,args.shards)[args.shard]]
    jobs=[j for j in all_jobs if j[0] in shard_seeds]
    manifest={
        'design':'New execution of recovered historical primary protocol; original per-run files not recovered',
        'execution_date':'2026-10-24','seeds':args.seeds,'rounds':30,'local_epochs':1,
        'full_historical':args.full_historical,'all_jobs':len(all_jobs),'shard':args.shard,'shards':args.shards,'shard_jobs':len(jobs),'shard_seeds':shard_seeds,
        'data_path':str(args.data.resolve()),'data_sha256':sha(args.data),'wrapper_sha256':sha(__file__),
        'historical_sources_sha256':{p.name:sha(p) for p in sorted(CORE.iterdir()) if p.is_file()},
        'config':cfg,'environment':{'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,
             'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,
             'device':'cpu','torch_threads':torch.get_num_threads()},
        'changes_to_historical_algorithm':[],
        'execution_controls':['Path routing, per-run saving, seed sharding, CPU thread cap; no hyperparameter selection'],
        'client_order':['container','tanker','bulk','general_cargo','passenger'],
        'stress_rounds':[11,20],'lag_profiles':{s:primary.delays_for(11,s) for s in primary.SCENARIOS},
        'staleness_weight':'1/(1+delay)','updated_object':'local trained model minus CURRENT server model; floats including BatchNorm statistics',
        'interpretation':'This is stale-model averaging with optional spectral calibration, not arrival-time asynchronous gradient aggregation',
    }
    args.output.mkdir(parents=True, exist_ok=True)
    if args.inventory:
        print(json.dumps(manifest,ensure_ascii=False,indent=2));return
    if args.combine:
        rounds=[];results=[]
        for seed,scenario,method in all_jobs:
            stem=f'{scenario}__{method}__seed{seed}'
            rp=args.output/'runs'/(stem+'.rounds.csv');jp=args.output/'runs'/(stem+'.result.json')
            if not rp.exists() or not jp.exists():raise RuntimeError('Missing '+stem)
            x=pd.read_csv(rp); assert len(x)==30
            rounds.append(x);results.append(json.loads(jp.read_text(encoding='utf-8')))
        rr=pd.concat(rounds,ignore_index=True);tt=pd.DataFrame(results)
        assert not rr[['scenario','method','seed','round']].duplicated().any()
        assert rr.validation_nll.notna().all()
        rr.to_csv(args.output/'sa_gsa_round_metrics.csv',index=False)
        tt.to_csv(args.output/'sa_gsa_test_results.csv',index=False)
        manifest.update(status='COMPLETED',trajectories=len(tt),round_rows=len(rr))
        write(args.output/'protocol.json',manifest)
        print(f'COMPLETE trajectories={len(tt)} round_rows={len(rr)}');return
    manifest.update(status='RUNNING',started_at_utc=pd.Timestamp.now('UTC').isoformat())
    write(args.output/f'manifest_shard{args.shard}.json',manifest)
    start=time.monotonic();times=[]
    for i,(seed,scenario,method) in enumerate(jobs,1):
        stem=f'{scenario}__{method}__seed{seed}'
        rp=args.output/'runs'/(stem+'.rounds.csv');jp=args.output/'runs'/(stem+'.result.json')
        if rp.exists() and jp.exists():
            old=pd.read_csv(rp);assert len(old)==30
            print(f'SKIP {i}/{len(jobs)} {stem}',flush=True);continue
        if rp.exists() or jp.exists(): raise RuntimeError('Partial output requires manual review: '+stem)
        prepared=base.prepare_data(frame,seed)
        sp=args.output/'splits'/f'seed{seed}.json'
        if not sp.exists():write(sp,{'train':prepared.train_idx.tolist(),'validation':prepared.anchor_idx.tolist(),
            'test':prepared.test_idx.tolist(),'train_cutpoints':prepared.train_cutpoints,'features':prepared.feature_names,'dims':prepared.dims})
        t0=time.monotonic()
        rows,result=primary.run_one(prepared,scenario,method,seed,copy.deepcopy(cfg),torch.device('cpu'))
        assert len(rows)==30 and rows.validation_nll.notna().all()
        rp.parent.mkdir(exist_ok=True)
        rows.to_csv(rp,index=False)
        result.update(execution='new_execution_20261024',data_sha256=manifest['data_sha256'])
        write(jp,result)
        times.append({'stem':stem,'seconds':time.monotonic()-t0})
        write(args.output/f'progress_shard{args.shard}.json',{'completed_this_session':i,'total':len(jobs),'elapsed_seconds':time.monotonic()-start,'last':times[-1]})
        write(args.output/f'timings_shard{args.shard}.json',times)
        print(f'{i}/{len(jobs)} {stem} seconds={times[-1]["seconds"]:.2f}',flush=True)
    manifest.update(status='COMPLETED',completed_at_utc=pd.Timestamp.now('UTC').isoformat(),elapsed_seconds=time.monotonic()-start)
    write(args.output/f'manifest_shard{args.shard}.json',manifest)

if __name__=='__main__':main()
