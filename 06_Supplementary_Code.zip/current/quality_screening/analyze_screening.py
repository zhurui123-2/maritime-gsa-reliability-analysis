"""Eight frozen screening comparisons; task counts and fleet diagnostics descriptive."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'historical_core'))
import analyze_sa_gsa_confirmatory as stats
out=ROOT/'results';dest=ROOT/'analysis';dest.mkdir(exist_ok=True)
curve=pd.read_csv(out/'all_screening_rounds.csv');audits=json.loads((out/'all_run_audits.json').read_text(encoding='utf-8'))
assert len(audits)==80 and all(a['all_validation_NLL_exact'] and a['all_statehash_equal'] for a in audits)
rows=[]
for (scenario,method,seed,budget),g in curve[curve.scenario!='clean'].groupby(['scenario','method','seed','budget']):
    ref='gsa' if method=='sa_gsa' else 'fedavg'
    clean=curve[(curve.scenario=='clean')&(curve.method==ref)&(curve.seed==seed)&(curve.budget==budget)]
    merged=g.merge(clean,on='round',suffixes=('_stress','_clean'),validate='one_to_one');s=merged[merged['round'].between(11,20)]
    rows.append({'scenario':scenario,'method':method,'seed':int(seed),'budget':budget,'selected_n':int(s.selected_n_stress.iloc[0]),
      'recall_loss':float((s.recall_clean-s.recall_stress).mean()),'coverage_loss':float((s.coverage_clean-s.coverage_stress).mean()),
      'additional_missed_high':float((s.missed_high_stress-s.missed_high_clean).mean()),
      'absolute_recall_stress':float(s.recall_stress.mean()),'absolute_recall_clean':float(s.recall_clean.mean()),
      'absolute_coverage_stress':float(s.coverage_stress.mean()),'absolute_coverage_clean':float(s.coverage_clean.mean()),
      'mean_selected_high_stress':float(s.hits_stress.mean()),'mean_missed_high_stress':float(s.missed_high_stress.mean()),
      'high_total':int(s.high_total_stress.iloc[0]),'round20_recall':float(s.loc[s['round']==20,'recall_stress'].iloc[0])})
per=pd.DataFrame(rows);per.to_csv(dest/'per_seed_screening.csv',index=False)
tests=[];differences=[]
for scenario in ['stale_moderate','stale_severe']:
    for method,comparator in [('staleness_decay','fedavg'),('sa_gsa','staleness_decay')]:
        a=per[(per.scenario==scenario)&(per.method==method)&np.isclose(per.budget,.1)].set_index('seed')
        b=per[(per.scenario==scenario)&(per.method==comparator)&np.isclose(per.budget,.1)].set_index('seed')
        for metric in ['recall_loss','coverage_loss']:
            delta=(a[metric]-b[metric]).to_numpy();label=f'{scenario}:{method}:{comparator}:{metric}'
            low,high=stats.bootstrap_ci(delta,label)
            tests.append({'label':label,'scenario':scenario,'method':method,'comparator':comparator,'metric':metric,
              'method_mean':float(a[metric].mean()),'comparator_mean':float(b[metric].mean()),'difference':float(delta.mean()),
              'ci95_low_unadjusted':low,'ci95_high_unadjusted':high,'exact_sign_flip_p':stats.exact_sign_flip_p(delta),'n_pairs':10})
            differences.extend([{'label':label,'seed':int(seed),'difference':float(value)} for seed,value in zip(a.index,delta)])
tests=pd.DataFrame(tests);adjusted=stats.holm(dict(zip(tests.label,tests.exact_sign_flip_p)));tests['holm_p']=tests.label.map(adjusted)
tests.to_csv(dest/'screening_primary_tests_eight.csv',index=False);pd.DataFrame(differences).to_csv(dest/'paired_seed_differences.csv',index=False)
metrics=['recall_loss','coverage_loss','additional_missed_high','absolute_recall_stress','absolute_recall_clean','absolute_coverage_stress','absolute_coverage_clean','mean_selected_high_stress','mean_missed_high_stress','high_total','round20_recall']
per.groupby(['scenario','method','budget','selected_n'])[metrics].mean().reset_index().to_csv(dest/'screening_summary.csv',index=False)
curve[(curve.scenario=='clean')&curve['round'].between(11,20)].groupby(['method','budget']).agg(
    recall=('recall','mean'),coverage=('coverage','mean'),hits=('hits','mean'),missed=('missed_high','mean'),high_total=('high_total','mean'),selected_n=('selected_n','first')).reset_index().to_csv(dest/'clean_selection_summary.csv',index=False)
fleet=[]
for path in sorted((out/'runs').glob('*.predictions.npz')):
    name=path.name.removesuffix('.predictions.npz');scenario,method,seedtext=name.split('__');seed=int(seedtext.removeprefix('seed'))
    z=np.load(path);p=z['probabilities'][19];y=z['labels'];nodes=z['nodes'];nll=-np.log(np.clip(p[np.arange(len(y)),y],1e-12,1))
    for client in sorted(set(nodes)):
        mask=nodes==client;fleet.append({'scenario':scenario,'method':method,'seed':seed,'client':client,'n':int(mask.sum()),'nll_round20':float(nll[mask].mean())})
fleet=pd.DataFrame(fleet)
extra=[]
for (scenario,method,seed,client),g in fleet[fleet.scenario!='clean'].groupby(['scenario','method','seed','client']):
    ref='gsa' if method=='sa_gsa' else 'fedavg';r=fleet[(fleet.scenario=='clean')&(fleet.method==ref)&(fleet.seed==seed)&(fleet.client==client)].iloc[0]
    row=g.iloc[0].to_dict();row['matched_clean_nll_round20']=r.nll_round20;row['excess_nll_round20']=row['nll_round20']-r.nll_round20;extra.append(row)
fleet.to_csv(dest/'fleet_round20_absolute.csv',index=False);extra=pd.DataFrame(extra);extra.to_csv(dest/'fleet_round20_matched.csv',index=False)
extra.groupby(['scenario','method','client']).agg(n_mean=('n','mean'),nll_mean=('nll_round20','mean'),excess_mean=('excess_nll_round20','mean')).reset_index().to_csv(dest/'fleet_round20_summary.csv',index=False)
check={'trajectories':80,'screening_rows':len(curve),'statehash_audits':sum(len(a['statehashes']) for a in audits),'all_statehashes_equal':True,'all_original_quality_validation_NLL_exact':True,
       'max_validation_NLL_difference':max(a['max_abs_NLL_difference'] for a in audits),'Holm_family':8,'test_vessels':231,'primary_review_slots':24,
       'selection_counts':'Descriptive task-unit transformation of recall, no separate tests. Fleet round20 descriptive; probabilities retained.',
       'interpretation':'Conditional retrospective ranking on full-year/weather-free inputs. Annual CO2 used only for labels and evaluation; no real intervention or emissions reduction validated.'}
(dest/'audit.json').write_text(json.dumps(check,ensure_ascii=False,indent=2),encoding='utf-8')
print(tests.to_string(index=False));print(json.dumps(check,indent=2))
