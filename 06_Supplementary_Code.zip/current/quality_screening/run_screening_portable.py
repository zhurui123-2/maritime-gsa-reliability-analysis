"""Read-only test measurement added to the frozen full-year weather-free runs."""
from pathlib import Path
import argparse,copy,hashlib,json,os,platform,random,sys,time
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ.setdefault(k,'1')
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'historical_core'))
import numpy as np
import pandas as pd
import torch
import quality_definition as quality
base=quality.base;primary=quality.primary
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def statehash(model):
    h=hashlib.sha256()
    for k,v in model.state_dict().items():h.update(k.encode());h.update(str(v.dtype).encode());h.update(v.detach().cpu().numpy().tobytes())
    return h.hexdigest()
def screen(y,co2,prob,ids,budget):
    k=int(np.ceil(len(y)*budget));chosen=np.lexsort((ids,-prob[:,4]))[:k];high=y==4
    hits=int(high[chosen].sum());selected=float(co2[chosen].sum());oracle=float(np.sort(co2)[-k:].sum())
    return {'selected_n':k,'high_total':int(high.sum()),'hits':hits,'missed_high':int(high.sum())-hits,
       'recall':hits/max(int(high.sum()),1),'precision':hits/k,'coverage':selected/co2.sum(),'regret':(oracle-selected)/oracle}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--shards',type=int,default=1);ap.add_argument('--shard',type=int,default=0);ap.add_argument('--combine',action='store_true');ap.add_argument('--quality-reference',type=Path,required=True,help='Directory containing the prior 160-quality run CSV files');args=ap.parse_args()
    assert 0<=args.shard<args.shards
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    data=ROOT/'data'/'vessels.csv';frame=pd.read_csv(data);frame=frame[frame.ReportingPeriod.astype(str).str.strip().eq('2024')].copy().reset_index(drop=True)
    assert len(frame)==1155;frame['weather_time_diff_hours']=0.0
    cfg=base.load_config();cfg.update(rounds=30,local_epochs=1,data_path=str(data));seeds=list(range(57,67));mine=np.array_split(seeds,args.shards)[args.shard].tolist()
    old=args.quality_reference.resolve()
    jobs=[]
    for s in seeds:
        jobs +=[(s,'clean',m) for m in ['fedavg','gsa']]
        jobs +=[(s,c,m) for c in ['stale_moderate','stale_severe'] for m in ['fedavg','staleness_decay','sa_gsa']]
    out=ROOT/'results';out.mkdir(exist_ok=True)
    protocol={'status':'RUNNING','execution_date':'2026-10-24','started_at_utc':pd.Timestamp.now('UTC').isoformat(),'seeds':seeds,'n_trajectories':80,
       'cohort':1155,'filter':"ReportingPeriod.astype(str).str.strip().eq('2024')",'weather_control':'Forward weather mask0 and weather_time_diff_hours0 before preprocessing',
       'split_sizes':[750,174,231],'budgets':{'primary':{'n_selected':24,'n_test':231},'secondary_proportions':[.05,.10,.20]},
       'prediction':'After each aggregation, highest emission-class probability; stable MMSI tie-break; every test probability saved.',
       'primary_endpoints':['Mean(clean recall - delayed recall), rounds11-20, 24 selected','Mean(clean emission coverage - delayed coverage), rounds11-20, 24 selected'],
       'primary_contrasts':['weighting minus FedAvg','combined minus weighting'],'primary_severities':['stale_moderate','stale_severe'],
       'inference':'Eight fixed comparisons = 2contrasts*2severities*2endpoints, 20000 seed-paired bootstrap, exact1024 sign flips, Holm8. NLL not retested in this family; selected counts descriptive.',
       'audit':'RNG and module train/eval flags restored after extra test prediction; full model state hash unchanged before/after; all30 validation NLL compared exactly against prior quality80.',
       'scope':'Same original-primary model family, reciprocal delay weights, same fixed lag profiles; retrospective ranking, no annual-total inputs; no claim of actual interventions.',
       'config':cfg,'wrapper_sha256':sha(__file__),'data_sha256':sha(data),'quality_definition_sha256':sha(ROOT/'quality_definition.py'),
       'historical_sources_sha256':{p.name:sha(p) for p in sorted((ROOT/'historical_core').iterdir()) if p.is_file()},
       'environment':{'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'device':'cpu','threads':1}}
    write(out/f'manifest_shard{args.shard}.json',protocol)
    if args.combine:
        curves=[];audits=[];rr=[]
        for seed,scenario,method in jobs:
            stem=f'{scenario}__{method}__seed{seed}'
            curves.append(pd.read_csv(out/'runs'/(stem+'.screening.csv')));rr.append(pd.read_csv(out/'runs'/(stem+'.rounds.csv')))
            audits.append(json.loads((out/'runs'/(stem+'.audit.json')).read_text(encoding='utf-8')))
        pd.concat(curves,ignore_index=True).to_csv(out/'all_screening_rounds.csv',index=False)
        pd.concat(rr,ignore_index=True).to_csv(out/'all_validation_rounds.csv',index=False)
        write(out/'all_run_audits.json',audits)
        protocol.update(status='COMPLETED',all_NLL_exact=all(x['all_validation_NLL_exact'] for x in audits),all_statehash_equal=all(x['all_statehash_equal'] for x in audits),screening_rows=sum(len(x) for x in curves));write(out/'protocol.json',protocol)
        assert protocol['all_NLL_exact'] and protocol['all_statehash_equal'];print('COMPLETED all80 exact NLL/state audit');return
    origagg=primary.aggregate_with_trust;orig_eval=base.evaluate_model;start=time.monotonic()
    for i,(seed,scenario,method) in enumerate([x for x in jobs if x[0] in mine],1):
        stem=f'{scenario}__{method}__seed{seed}';prefix=out/'runs'/stem
        if prefix.with_suffix('.rounds.csv').exists():raise RuntimeError('Refusing overwrite '+stem)
        prepared=base.prepare_data(frame,seed);idx=prepared.test_idx;ys=prepared.labels[idx];ids=frame.MMSI.iloc[idx].to_numpy();co2=frame.total_co2_emissions_tonnes.iloc[idx].to_numpy(float);nodes=frame.federated_node.iloc[idx].to_numpy(str)
        payload=[];states=[];curves=[];counter=[0]
        def measured_aggregate(model,updates,counts,trust):
            origagg(model,updates,counts,trust);counter[0]+=1;round_idx=counter[0]
            before=statehash(model);modes=[m.training for m in model.modules()]
            rng_py=random.getstate();rng_np=np.random.get_state();rng_torch=torch.get_rng_state()
            rng_cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None
            try:
                pred=orig_eval(model,prepared,idx,torch.device('cpu'),int(cfg['batch_size']),seed=seed+round_idx)
                assert np.array_equal(pred['indices'],idx)
                p=pred['prob'].copy();payload.append(p)
                for budget in [.05,.10,.20]:curves.append({'seed':seed,'scenario':scenario,'method':method,'round':round_idx,'budget':budget,**screen(ys,co2,p,ids,budget)})
            finally:
                random.setstate(rng_py);np.random.set_state(rng_np);torch.set_rng_state(rng_torch)
                if rng_cuda is not None:torch.cuda.set_rng_state_all(rng_cuda)
                for module,mode in zip(model.modules(),modes):module.training=mode
            after=statehash(model);states.append({'round':round_idx,'before':before,'after':after,'equal':before==after})
            assert before==after
        primary.aggregate_with_trust=measured_aggregate
        try:r,result=primary.run_one(prepared,scenario,method,seed,copy.deepcopy(cfg),torch.device('cpu'))
        finally:primary.aggregate_with_trust=origagg
        prefix.parent.mkdir(exist_ok=True);r.to_csv(prefix.with_suffix('.rounds.csv'),index=False)
        pd.DataFrame(curves).to_csv(prefix.with_suffix('.screening.csv'),index=False)
        np.savez_compressed(prefix.with_suffix('.predictions.npz'),probabilities=np.stack(payload),rounds=np.arange(1,31),MMSI=ids,labels=ys,co2=co2,nodes=nodes)
        oldr=pd.read_csv(old/f'full2024_weather_free__{stem}.rounds.csv',float_precision='round_trip')
        exact=bool(np.array_equal(r.validation_nll.to_numpy(),oldr.validation_nll.to_numpy()))
        audit={'seed':seed,'scenario':scenario,'method':method,'all_validation_NLL_exact':exact,'max_abs_NLL_difference':float(np.max(np.abs(r.validation_nll.to_numpy()-oldr.validation_nll.to_numpy()))),
            'all_statehash_equal':all(x['equal'] for x in states),'statehashes':states,'result':result}
        write(prefix.with_suffix('.audit.json'),audit)
        write(out/f'progress_shard{args.shard}.json',{'completed':i,'last':stem,'elapsed_seconds':time.monotonic()-start,'exact_NLL':exact})
        print(f'{i} {stem} exact_NLL={exact} elapsed={time.monotonic()-start:.1f}',flush=True)
if __name__=='__main__':main()

