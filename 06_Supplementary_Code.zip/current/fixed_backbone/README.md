# Fixed-backbone weighting and aggregation sensitivity

This independent experiment uses the recovered primary model (hidden24, embedding16, dropout0.10, BatchNorm, masked concatenation) and primary SGD schedule. It evaluates weighting law, exponential decay strength and the reference used to construct an uploaded update. GSA is not applied in this experiment.

The final analysis uses20 seeds4001–4020,520 trajectories and15600 round records. It is in `analysis_expanded/`. The original ten-seed plan and results remain separately in `plan_frozen.json` and `analysis/`. After all initial results were known, a documented amendment expanded the design once to20 seeds because the ten-seed exact two-sided test could not resolve the first Holm threshold for40 comparisons. All methods, information conditions, severities and endpoints were retained; no further expansion or result-dependent stopping was allowed. `plan_amendment_20seeds.json` records this sequence. This is amended exploratory sensitivity, not independent confirmation.

## Prespecified design

- Initial seeds4001–4010, expanded to4001–4020 as documented above; seed4000 is a separate smoke run and excluded.
- Two information conditions: all primary predictors; and only the standardized annual time-at-sea column set to zero. The remaining operations predictors are retained. This differs from the old gated-model removal of its annual encoder.
- Moderate `[0,1,2,3,4]` and severe `[0,2,4,6,8]` lag profiles during rounds11–20 of30 rounds. The ten post-stress rounds support short-horizon residual analysis only.
- Client order: bulk, container, general_cargo, passenger, tanker. Rotation `(seed-4001)%5` gives each rotation four times in the final20-seed design. Assignments, splits and training randomness are matched across methods.
- Six methods: sample-weighted stale model averaging (FedAvg); reciprocal weights; exponential weights at lambda0.10,0.35,0.70; and a buffered stale-local-delta reference.
- Forty shared clean trajectories and480 stressed trajectories:520 total;15600 round records. At zero lag all six rules coincide. Every stressed trajectory is checked against its shared clean trajectory during the first ten rounds.

For model averaging, a client trains from an older model but its transmitted difference is measured relative to the current server. Consequently that difference contains both its new local training change and the model-version gap. Without GSA, adding the normalized weighted differences to the current server is algebraically equivalent to weighted averaging of returned models.

## Buffered reference and its source

Nguyen et al. (2022), *Federated Learning with Buffered Asynchronous Aggregation*, AISTATS, PMLR151:3581–3607. [Official paper](https://proceedings.mlr.press/v151/nguyen22b.html), Algorithms1–2 on PDF page4.

Their client sends the difference between its downloaded model and its locally trained model. After collecting K updates the server averages them, applies a server step, and clears its buffer. The present reference uses K=5 fixed arrivals, one return per client per server step, server rate1, and the same sample-size weights as the other methods. Trainable parameters use local-minus-downloaded deltas; BatchNorm floating buffers use the common convex average of returned buffers, while integer buffers stay unchanged. This isolates the update-reference difference while keeping the sample-weighted objective and model state valid. It is a FedBuff-derived reference, not a reproduction of asynchronous arrival scheduling, secure aggregation or queue throughput.

## Reproduce

The executed environment is recorded in `plan_frozen.json`. Place an authorized cohort CSV at the data path declared in `run_sensitivity.py`, retaining the supplied cohort fingerprint, or explicitly adapt that path before freezing a new execution. The original author-machine path remains in the archived source. Historical core sources are unchanged copies.

Initial worker commands:

    python run_sensitivity.py --seeds 4001 4002 4003 4004 4005
    python run_sensitivity.py --seeds 4006 4007 4008 4009 4010

Amended additional worker commands:

    python run_sensitivity.py --seeds 4011 4012 4013 4014 4015
    python run_sensitivity.py --seeds 4016 4017 4018 4019 4020

The executable refuses to overwrite run directories. `results/runs/` retains every formal trajectory and end-point prediction file; `results/splits/` retains indices, feature names and label cutpoints.

Regenerate summaries after all runs finish:

    python analyze_sensitivity_expanded.py
    python format_manuscript_table.py

The primary family comprises40 method-versus-FedAvg tests: five alternative rules, two information conditions, two lag severities and two endpoints. Endpoints are signed cumulative test-NLL excess and mean recall loss against the matched clean trajectory during rounds11–20. Final analysis uses exact two-sided paired sign flips over1048576 assignments in bounded chunks and Holm correction over all40 tests; confidence intervals are unadjusted95% paired percentile bootstrap intervals from20000 samples. Statistical units are20 seeds on the same linked cohort. Vessel counts, coverage, fleet errors and round30 residuals are additional descriptive outputs. All seeds and effect directions are retained. The historical ten-seed executable `analyze_sensitivity.py` and its output remain unchanged; it expects only the original260 runs in its input directory and is not the final520-run analysis command.

`data_linkage_audit.json` records recovered linkage counts and a separate spatial-weather validity issue. The sensitivity keeps the archived cohort and weather predictors unchanged; it does not by itself validate the HRRR spatial linkage.
