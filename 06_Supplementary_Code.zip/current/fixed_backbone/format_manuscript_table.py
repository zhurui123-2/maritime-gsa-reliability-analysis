"""Presentation table; primary p-values copied unchanged from the40-test analysis."""
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'analysis_expanded'

def main():
    d=pd.read_csv(OUT/'per_seed_outcomes.csv');tests=pd.read_csv(OUT/'primary_tests_40.csv')
    rows=[];rng=np.random.default_rng(111024)
    for (info,sev),g in d.groupby(['information','severity'],sort=True):
        ref=g[g.method=='FedAvg'].set_index('seed').sort_index()
        for method,cur in g.groupby('method',sort=True):
            cur=cur.set_index('seed').sort_index()
            r={'information':info,'severity':sev,'method':method,'n_seeds':20,'fedavg_nll_damage':ref.nll_damage.mean(),'method_nll_damage':cur.nll_damage.mean(),
               'stress_nll_mean':cur.stress_absolute_nll.mean(),'stress_recall_percent':100*cur.stress_absolute_recall24.mean(),'recall_loss_pp':100*cur.recall_loss.mean(),
               'selected_high_per24':cur.stress_selected_high_count24.mean(),'selected_high_gain_vs_fedavg':(cur.stress_selected_high_count24-ref.stress_selected_high_count24).mean(),
               'emission_coverage_percent':100*cur.stress_absolute_coverage24.mean(),'coverage_loss_pp':100*cur.coverage_loss.mean(),
               'coverage_loss_difference_pp':100*(cur.coverage_loss-ref.coverage_loss).mean()}
            diff=100*(cur.coverage_loss-ref.coverage_loss).to_numpy();b=diff[rng.integers(0,20,size=(20000,20))].mean(1)
            r['coverage_loss_diff_ci95_low_unadjusted_pp'],r['coverage_loss_diff_ci95_high_unadjusted_pp']=np.quantile(b,[.025,.975])
            if method!='FedAvg':
                for metric,scale in [('nll_damage',1),('recall_loss',100)]:
                    a=tests[(tests.information==info)&(tests.severity==sev)&(tests.method==method)&(tests.endpoint==metric)].iloc[0]
                    for src,dest in [('mean_difference','difference'),('ci95_low_unadjusted','ci95_low_unadjusted'),('ci95_high_unadjusted','ci95_high_unadjusted')]:r[metric+'_'+dest]=scale*a[src]
                    r[metric+'_p_exact']=a.p_exact_two_sided;r[metric+'_p_holm40']=a.p_holm_40
            rows.append(r)
    pd.DataFrame(rows).to_csv(OUT/'manuscript_table_all_methods.csv',index=False)
    p=pd.DataFrame(rows)
    cols=['information','severity','method','method_nll_damage','selected_high_per24','recall_loss_difference','recall_loss_p_holm40','coverage_loss_difference_pp']
    text=['# 统一骨干敏感性：最终20种子结果','',
      '已保留最初10种子的260条轨迹、分析及冻结计划。发现精确双侧检验的离散分辨率不足以达到40项Holm家族首阈值后，记录了已知结果并一次性固定扩增到20种子；全部方法、条件和端点保留，最终520条轨迹、15,600条逐轮记录。此为修订计划后的探索性敏感性，不称独立确认性实验。','',
      '## 可用于正文的发现','',
      '在含年度航行时间的主骨干下，倒数加权相对FedAvg减少累计NLL损伤：中度0.63809→0.50985，重度0.89924→0.68058；对应减少20.10%与24.32%。固定24名额的平均入选高等级船数分别13.810→14.350与13.025→13.880，即每轮增加0.540与0.855艘。召回损失减少1.149与1.748个百分点；40项Holm p分别0.003193与0.045193。该新增结果不支持将旧门控实验的“未确认筛查保护”推广到全部实现。','',
      '仅移除年度航行时间后，倒数与三种指数规则相对FedAvg的NLL损伤差均值变为正向，但区间多跨零；不应概括为所有权重规则均已确认有害。缓冲stale-local-delta参照在有年度输入时损伤更小、筛查保护更大，在无年度输入中度条件下却增加NLL损伤（差+0.03326，Holm p0.01538）。更新参照与可用信息均会改变策略比较。','',
      '## 表格单位','',
      '`manuscript_table_all_methods.csv`完整列出24组合的绝对NLL、24名额内入选高等级船数、召回率、排放覆盖及其匹配clean损失。recall_loss_difference列单位为百分点，负值代表相对FedAvg减少召回损失；coverage_loss_difference_pp亦同。NLL与recall的精确p和Holm p直接复制40项预定检验；coverage作为预定描述性次要端点仅给未校正区间，没有事后另建显著性检验。','',
      '## 24组合概览','',p[cols].to_string(index=False,float_format=lambda x:f'{x:.6f}'),'',
      '所有统计只反映同一链接样本上20个拆分/训练种子的变异。缓冲参照为固定K=5、样本加权及BatchNorm处理的FedBuff借鉴变体，不是异步调度/吞吐或安全聚合验证。']
    (ROOT/'新敏感性结果说明.md').write_text('\n'.join(text),encoding='utf-8')
    print(p[cols].to_string(index=False))

if __name__=='__main__':main()
