"""Regenerate all summaries from every prespecified trajectory; no model training."""
from pathlib import Path
import hashlib,itertools,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
CLIENTS=['bulk','container','general_cargo','passenger','tanker']
METHODS=['FedAvg','Reciprocal','Exponential_010','Exponential_035','Exponential_070','BufferedDelta']

def main():
    paths=sorted((ROOT/'results'/'runs').glob('*/rounds.csv'))
    assert len(paths)==260,len(paths)
    frames=[pd.read_csv(p) for p in paths]
    allrounds=pd.concat(frames,ignore_index=True)
    assert len(allrounds)==7800 and allrounds.isna().sum().sum()==0
    out=ROOT/'analysis';out.mkdir(exist_ok=True)
    allrounds.to_csv(out/'all_7800_rounds.csv',index=False)
    clean={};checks=[]
    for keys,g in allrounds[allrounds.severity=='clean'].groupby(['seed','information']):clean[keys]=g.sort_values('round')
    rows=[]
    for keys,g in allrounds[allrounds.severity!='clean'].groupby(['seed','information','severity','method'],sort=True):
        seed,information,severity,method=keys;g=g.sort_values('round');c=clean[(seed,information)]
        assert len(g)==30 and len(c)==30
        numeric=['test_nll','val_nll','recall24','precision24','emission_coverage24']
        err=float(np.abs(g[numeric].to_numpy()[:10]-c[numeric].to_numpy()[:10]).max())
        assert err<1e-12
        checks.append({'seed':seed,'information':information,'severity':severity,'method':method,'max_pre_stress_difference':err})
        stress=slice(10,20);diff=g.test_nll.to_numpy()-c.test_nll.to_numpy()
        row={'seed':seed,'information':information,'severity':severity,'method':method,'rotation':int(g.rotation.iloc[0]),
             'nll_damage':float(diff[stress].sum()),
             'positive_nll_damage':float(np.maximum(diff[stress],0).sum()),
             'recall_loss':float((c.recall24.to_numpy()-g.recall24.to_numpy())[stress].mean()),
             'selected_high_loss':float((c.selected_high_count24.to_numpy()-g.selected_high_count24.to_numpy())[stress].mean()),
             'coverage_loss':float((c.emission_coverage24.to_numpy()-g.emission_coverage24.to_numpy())[stress].mean()),
             'stress_absolute_nll':float(g.test_nll.iloc[stress].mean()),
             'stress_absolute_recall24':float(g.recall24.iloc[stress].mean()),
             'stress_absolute_precision24':float(g.precision24.iloc[stress].mean()),
             'stress_absolute_coverage24':float(g.emission_coverage24.iloc[stress].mean()),
             'stress_selected_high_count24':float(g.selected_high_count24.iloc[stress].mean()),
             'high_vessels':int(g.high_vessels.iloc[0]),
             'round30_nll_residual':float(diff[-1]),'poststress_signed_damage':float(diff[20:30].sum())}
        for client in CLIENTS:row['end_stress_nll_'+client]=float(g['nll_'+client].iloc[19]);row['stress_weight_'+client]=float(g['weight_'+client].iloc[10])
        rows.append(row)
    d=pd.DataFrame(rows);assert len(d)==240
    d.to_csv(out/'per_seed_outcomes.csv',index=False)
    summary=d.groupby(['information','severity','method']).agg(['mean','std']).reset_index()
    summary.columns=['_'.join(c).strip('_') for c in summary.columns]
    summary.to_csv(out/'method_summary.csv',index=False)
    signs=np.asarray(list(itertools.product([-1.,1.],repeat=10)))
    rng=np.random.default_rng(91024);tests=[];paired=[]
    for (information,severity),g in d.groupby(['information','severity'],sort=True):
        ref=g[g.method=='FedAvg'].set_index('seed').sort_index()
        for method in METHODS[1:]:
            cur=g[g.method==method].set_index('seed').sort_index()
            assert cur.index.equals(ref.index) and len(cur)==10
            for endpoint in ['nll_damage','recall_loss']:
                x=(cur[endpoint]-ref[endpoint]).to_numpy()
                p=float((np.abs((signs*x).mean(axis=1))>=abs(x.mean())-1e-14).mean())
                boot=x[rng.integers(0,10,size=(20000,10))].mean(axis=1)
                lo,hi=np.quantile(boot,[.025,.975])
                tests.append({'information':information,'severity':severity,'method':method,'reference':'FedAvg','endpoint':endpoint,'mean_difference':float(x.mean()),'ci95_low_unadjusted':float(lo),'ci95_high_unadjusted':float(hi),'p_exact_two_sided':p,'n_seeds':10})
                for seed,value in zip(cur.index,x):paired.append({'information':information,'severity':severity,'method':method,'endpoint':endpoint,'seed':int(seed),'difference':float(value)})
    t=pd.DataFrame(tests);assert len(t)==40
    order=np.argsort(t.p_exact_two_sided.to_numpy());adjusted=np.empty(40);running=0.
    for j,k in enumerate(order):
        running=max(running,min(1.,float(t.p_exact_two_sided.iloc[k])*(40-j)));adjusted[k]=running
    t['p_holm_40']=adjusted;t['holm_significant']=adjusted<.05
    t.to_csv(out/'primary_tests_40.csv',index=False)
    pd.DataFrame(paired).to_csv(out/'paired_seed_differences.csv',index=False)
    pd.DataFrame(checks).to_csv(out/'trajectory_checks.csv',index=False)
    fleet=[]
    for (information,severity),g in d.groupby(['information','severity']):
        ref=g[g.method=='FedAvg'].set_index('seed').sort_index()
        for method in METHODS:
            cur=g[g.method==method].set_index('seed').sort_index()
            for client in CLIENTS:fleet.append({'information':information,'severity':severity,'method':method,'client':client,'end_stress_nll':float(cur['end_stress_nll_'+client].mean()),'difference_vs_fedavg':float((cur['end_stress_nll_'+client]-ref['end_stress_nll_'+client]).mean()),'aggregation_weight':float(cur['stress_weight_'+client].mean())})
    pd.DataFrame(fleet).to_csv(out/'fleet_descriptive.csv',index=False)
    manifest={'n_trajectories':260,'n_round_records':7800,'n_stressed_runs':240,'n_clean_runs':20,'primary_tests':40,'seeds':list(range(4001,4011)),
              'max_pre_stress_difference':max(x['max_pre_stress_difference'] for x in checks),
              'rotation_counts':{str(k):v for k,v in d[['seed','rotation']].drop_duplicates().rotation.value_counts().to_dict().items()},
              'holm_significant_tests':t[t.holm_significant].to_dict('records'),
              'files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.glob('*.csv'))},
              'analysis_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (out/'summary.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
