"""Fixed primary-backbone sensitivity. Executed independently of archived runs."""
from __future__ import annotations
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key,'1')
import argparse,copy,hashlib,itertools,json,platform,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
import torch

ROOT=Path(__file__).resolve().parent
CORE=ROOT/'historical_core'
sys.path.insert(0,str(CORE))
import run_rebuilt_experiments as B
from run_reliability_confirmatory import local_train_masked

CLIENTS=['bulk','container','general_cargo','passenger','tanker']
METHODS=['FedAvg','Reciprocal','Exponential_010','Exponential_035','Exponential_070','BufferedDelta']
LAGS={'moderate':[0,1,2,3,4],'severe':[0,2,4,6,8]}
DATA=Path('D:/ASC投稿/OCM补充实验_20261019/data/vessels.csv')
DATA_HASH='03ddbf7bdb9364c0dd07ffdee5be8248a747a8f8ecfbfc13bbec66c3ac4ef0eb'

def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str),encoding='utf-8')

def freeze():
    plan={'purpose':'Fixed-backbone sensitivity to weighting law, decay strength and uploaded-delta reference; no GSA performance claim',
      'status':'analysis plan fixed before formal execution; supplementary unregistered experiment',
      'seeds':list(range(4001,4011)),'rotation':'(seed-4001)%5; each rotation occurs twice; same across information conditions and methods',
      'information':['annual','no_annual_time'],'information_definition':'Both use primary features. no_annual_time zeros only the standardized time_at_sea_hours operations column; imo_observations and weather_time_diff_hours remain. This differs from the earlier gated protocol annual-encoder removal.',
      'methods':METHODS,'lag_profiles':LAGS,'rounds':30,'stress_rounds':[11,20],'poststress_rounds':[21,30],
      'model':'Primary MultiModalNet hidden24 embedding16 dropout0.10, masked concatenation, BatchNorm; unchanged copied source',
      'optimizer':'SGD lr0.03, weight_decay0.0001, clip5, one local epoch, batch32, reset each client-round',
      'weights':'n_k*f(delay)/sum_j n_j*f(delay); FedAvg and BufferedDelta f=1; Reciprocal f=1/(1+delay); Exponential lambda=0.10,0.35,0.70',
      'server':'Model aggregation methods use local-current model delta. BufferedDelta uses local-historical-start delta only for trainable parameters, server rate1; floating BatchNorm buffers use same sample-weighted convex model averaging; integer buffers unchanged.',
      'buffered_reference':'FedBuff-derived sample-weighted fixed-arrival K=5 reference, not a reproduction of asynchronous scheduling or secure aggregation. Nguyen et al.2022 PMLR151 Algorithms1-2 average buffered client updates measured from their downloaded model. https://proceedings.mlr.press/v151/nguyen22b.html',
      'clean':'one zero-lag clean trajectory per seed/information condition; all six rules coincide at zero lag; verify first10 rounds against shared clean',
      'runs':260,'recorded_endpoints':['test_nll','val_nll','recall24','precision24','emission_coverage24','selected_high_count24','selected_emission_tonnes24','fleet_nll','aggregation_weights'],
      'primary_endpoint_definition':{'nll_damage':'sum stressed test NLL minus clean test NLL over rounds11-20 (signed)','recall_loss':'mean clean recall24 minus stressed recall24 over rounds11-20'},
      'inference':'Five non-FedAvg methods minus FedAvg across two information conditions and two lag severities and two primary endpoints: one family40 paired exact sign-flip tests, Holm correction. 95% unadjusted paired percentile bootstrap CI20000 resamples with deterministic analysis seed91024. Units are10 seeds; rotations are not separate replicates.',
      'secondary':'Absolute stress screening, end-stress fleet NLL, round30 residual and effective client contribution are descriptive; all effect directions retained. No general temporal/deployment inference.',
      'failure_policy':'Retain all seeds and directions. Stop worker with explicit failure record on nonfinite trajectory; no seed substitution, no adaptive tuning.',
      'data_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
      'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'core_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(CORE.glob('*.py'))},
      'environment':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'torch':torch.__version__,'platform':platform.platform(),'device':'cpu','threads':1}}
    assert plan['data_sha256']==DATA_HASH
    path=ROOT/'plan_frozen.json'
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'))
        assert old['script_sha256']==plan['script_sha256'],'Frozen source changed'
        assert old['data_sha256']==plan['data_sha256']
    else:dump(path,plan)
    return plan

def predict(model,prepared,idx):
    model.eval()
    with torch.no_grad():
        arrays={k:torch.from_numpy(v[idx]) for k,v in prepared.arrays.items()}
        logits,_=model(arrays,torch.ones(len(idx),len(arrays)))
        p=logits.softmax(1).numpy().astype(float)
    assert np.isfinite(p).all()
    return np.clip(p,1e-12,1)

def evaluation(model,p,df):
    vp=predict(model,p,p.anchor_idx);tp=predict(model,p,p.test_idx)
    y=p.labels[p.test_idx];ids=df.MMSI.iloc[p.test_idx].to_numpy();co2=df.total_co2_emissions_tonnes.iloc[p.test_idx].to_numpy(float)
    order=np.lexsort((ids,-tp[:,4]));chosen=order[:24];high=y==4
    nll=-np.log(tp[np.arange(len(y)),y])
    row={'test_nll':float(nll.mean()),'val_nll':float(-np.log(vp[np.arange(len(vp)),p.labels[p.anchor_idx]]).mean()),
         'recall24':float(high[chosen].sum()/high.sum()),'precision24':float(high[chosen].mean()),
         'emission_coverage24':float(co2[chosen].sum()/co2.sum()),'selected_high_count24':int(high[chosen].sum()),
         'selected_emission_tonnes24':float(co2[chosen].sum()),'high_vessels':int(high.sum()),'test_vessels':len(y),'selected_vessels':24}
    nodes=p.nodes[p.test_idx]
    for c in CLIENTS:row['nll_'+c]=float(nll[nodes==c].mean())
    return row,tp,ids[chosen]

def weights(method,sizes,lags):
    if method=='Reciprocal':f=1/(1+np.asarray(lags,float))
    elif method.startswith('Exponential_'):f=np.exp(-int(method.split('_')[1])/100*np.asarray(lags,float))
    else:f=np.ones(5)
    w=sizes*f
    return w/w.sum()

def train(df,prepared,seed,information,severity,method,out):
    assert not out.exists(),f'Refusing overwrite {out}'
    B.seed_all(seed)
    model=B.MultiModalNet(prepared.dims,24,16,.10)
    history=[B.clone_state(model)]
    named=set(dict(model.named_parameters()))
    parts=[prepared.train_idx[prepared.nodes[prepared.train_idx]==c] for c in CLIENTS]
    sizes=np.asarray([len(idx) for idx in parts],float)
    cfg={'learning_rate':.03,'weight_decay':.0001,'local_epochs':1,'batch_size':32}
    rotation=(seed-4001)%5
    target=np.roll(LAGS.get(severity,[0]*5),rotation)
    rows=[];probs=[];selected=[];start=time.perf_counter()
    for r in range(1,31):
        lags=target if 11<=r<=20 else np.zeros(5,dtype=int)
        current=history[-1];locals_=[];starts=[]
        for j,idx in enumerate(parts):
            original=history[max(0,len(history)-1-int(lags[j]))]
            local=copy.deepcopy(model);local.load_state_dict(original)
            local,_,_=local_train_masked(local,prepared,idx,torch.device('cpu'),cfg,'fedavg',seed+r*100+j,[1.]*4)
            locals_.append(B.clone_state(local));starts.append(original)
        w=weights(method,sizes,lags)
        updated={k:v.clone() for k,v in current.items()}
        for k,v in current.items():
            if not v.is_floating_point():continue
            if method=='BufferedDelta' and k in named:
                updated[k]=v+sum(float(a)*(lo[k]-st[k]) for a,lo,st in zip(w,locals_,starts))
            else:
                updated[k]=v+sum(float(a)*(lo[k]-v) for a,lo in zip(w,locals_))
        assert all(torch.isfinite(v).all() for v in updated.values())
        for k,v in updated.items():
            if k.endswith('running_var'):assert (v>=0).all()
        model.load_state_dict(updated);history.append(B.clone_state(model))
        row,p,chosen=evaluation(model,prepared,df)
        row.update(seed=seed,information=information,severity=severity,method=method,round=r,rotation=rotation)
        for j,c in enumerate(CLIENTS):row['weight_'+c]=float(w[j]);row['lag_'+c]=int(lags[j])
        rows.append(row)
        if r in [10,20,30]:probs.append(p);selected.append(chosen)
    out.mkdir(parents=True)
    pd.DataFrame(rows).to_csv(out/'rounds.csv',index=False)
    np.savez_compressed(out/'predictions.npz',probabilities=np.stack(probs),selected_ids=np.stack(selected),rounds=[10,20,30],test_idx=prepared.test_idx,labels=prepared.labels[prepared.test_idx])
    dump(out/'run.json',{'seed':seed,'information':information,'severity':severity,'method':method,'rotation':rotation,'runtime_seconds':time.perf_counter()-start,'n_rounds':30})
    return pd.DataFrame(rows)

def execute(seeds,smoke=False):
    torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    freeze();df=pd.read_csv(DATA);assert len(df)==1172
    baseout=ROOT/('smoke' if smoke else 'results')
    for seed in seeds:
        for information in ['annual','no_annual_time']:
            prepared=B.prepare_data(df,seed)
            if information=='no_annual_time':
                col=prepared.feature_names['operations'].index('time_at_sea_hours')
                prepared.arrays['operations'][:,col]=0
            dump(baseout/'splits'/f'{information}_s{seed}.json',{'train':prepared.train_idx.tolist(),'validation':prepared.anchor_idx.tolist(),'test':prepared.test_idx.tolist(),'cutpoints':prepared.train_cutpoints,'features':prepared.feature_names,'dims':prepared.dims})
            clean=train(df,prepared,seed,information,'clean','FedAvg',baseout/'runs'/f'{information}__clean__FedAvg__s{seed}')
            severities=['moderate'] if smoke else ['moderate','severe']
            for severity in severities:
                for method in METHODS:
                    out=baseout/'runs'/f'{information}__{severity}__{method}__s{seed}'
                    t=train(df,prepared,seed,information,severity,method,out)
                    numeric=['test_nll','val_nll','recall24','precision24','emission_coverage24']
                    assert np.max(np.abs(t.loc[:9,numeric].to_numpy()-clean.loc[:9,numeric].to_numpy()))<1e-12
                    print(json.dumps({'completed':out.name,'runtime_seconds':json.loads((out/'run.json').read_text())['runtime_seconds']}),flush=True)
        dump(baseout/f'completed_seed{seed}.json',{'seed':seed,'status':'completed_all_conditions'})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',type=int,nargs='+');ap.add_argument('--freeze',action='store_true');ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    if args.freeze:freeze();return
    assert args.seeds
    try:execute(args.seeds,args.smoke)
    except Exception as e:
        dump(ROOT/f'failure_{args.seeds[0]}.json',{'exception':repr(e),'seeds':args.seeds});raise

if __name__=='__main__':main()
