"""Read-only data-quality audit, original HRRR grid and archived vessel table."""
from pathlib import Path
import ctypes as C
import hashlib
import json
import os
import re
from datetime import date
import time
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / 'working'
OUT = ROOT / 'Data_Tables'
COHORT = Path(r'D:\ASC投稿\OCM当前稿_20261020\working\restored_F_evidence\1\final_four_modal_dataset.csv')
ALIGN = COHORT.with_name('align_shipping_data.py')
GRIB = WORK / 'hrrr_3km_2024010100.grib2'
META = GRIB.with_suffix('.json')
BIN = Path(r'D:\anaconda\envs\shipping-align\Library\bin')
R = 6371229.


def haversine(lat1, lon1, lat2, lon2):
    a1, a2 = np.deg2rad(lat1), np.deg2rad(lat2)
    dlat = a2-a1
    dlon = np.deg2rad((np.asarray(lon2)-np.asarray(lon1)+180)%360-180)
    a = np.sin(dlat/2)**2 + np.cos(a1)*np.cos(a2)*np.sin(dlon/2)**2
    return (R/1000)*2*np.arcsin(np.sqrt(np.clip(a,0,1)))


def main():
    start=time.perf_counter()
    d=pd.read_csv(COHORT)
    assert len(d)==1172 and d.MMSI.nunique()==1172
    d['recomputed_weather_time_diff_hours']=(pd.to_datetime(d.ais_time,utc=True)-pd.to_datetime(d.weather_time,utc=True)).abs().dt.total_seconds()/3600
    os.add_dll_directory(str(BIN))
    lib=C.CDLL(str(BIN/'eccodes.dll'))
    ptr=C.POINTER(C.c_double)
    lib.codes_handle_new_from_message_copy.argtypes=[C.c_void_p,C.c_void_p,C.c_size_t]
    lib.codes_handle_new_from_message_copy.restype=C.c_void_p
    lib.codes_get_double.argtypes=[C.c_void_p,C.c_char_p,ptr]
    lib.codes_get_double_array.argtypes=[C.c_void_p,C.c_char_p,ptr,C.POINTER(C.c_size_t)]
    lib.codes_grib_nearest_find_multiple.argtypes=[C.c_void_p,C.c_int,ptr,ptr,C.c_long,ptr,ptr,ptr,ptr,C.POINTER(C.c_int)]
    lib.codes_grib_nearest_find_multiple.restype=C.c_int
    lib.codes_handle_delete.argtypes=[C.c_void_p]
    b=GRIB.read_bytes();first=b[:int.from_bytes(b[8:16],'big')]
    buf=C.create_string_buffer(first)
    handle=lib.codes_handle_new_from_message_copy(None,buf,len(first))
    assert handle
    parameters={}
    for key in ['Nx','Ny','latitudeOfFirstGridPointInDegrees','longitudeOfFirstGridPointInDegrees',
                'radius','LoVInDegrees','LaDInDegrees','Latin1InDegrees','Latin2InDegrees',
                'DxInMetres','DyInMetres','scanningMode']:
        v=C.c_double();assert lib.codes_get_double(handle,key.encode(),C.byref(v))==0
        parameters[key]=v.value
    nx,ny=int(parameters['Nx']),int(parameters['Ny'])
    assert (nx,ny)==(1799,1059) and parameters['scanningMode']==64
    assert parameters['radius']==R
    arrays={}
    for key in ['latitudes','longitudes','values']:
        a=np.empty(nx*ny,dtype=np.float64);ln=C.c_size_t(len(a))
        assert lib.codes_get_double_array(handle,key.encode(),a.ctypes.data_as(ptr),C.byref(ln))==0
        arrays[key]=a
    la=arrays['latitudes'];lo=(arrays['longitudes']+180)%360-180
    n=np.sin(np.deg2rad(parameters['Latin1InDegrees']))
    f=np.cos(np.deg2rad(parameters['Latin1InDegrees']))*np.tan(np.pi/4+np.deg2rad(parameters['Latin1InDegrees'])/2)**n/n
    def xy(lat,lon):
        rr=R*f/np.tan(np.pi/4+np.deg2rad(lat)/2)**n
        theta=n*np.deg2rad((np.asarray(lon)-parameters['LoVInDegrees']+180)%360-180)
        return rr*np.sin(theta),-rr*np.cos(theta)
    x0,y0=xy(parameters['latitudeOfFirstGridPointInDegrees'],parameters['longitudeOfFirstGridPointInDegrees'])
    x,y=xy(d.sample_lat.to_numpy(),d.sample_lon.to_numpy())
    i=(x-x0)/parameters['DxInMetres'];j=(y-y0)/parameters['DyInMetres']
    d['hrrr_grid_x_index_fractional']=i;d['hrrr_grid_y_index_fractional']=j
    d['inside_hrrr_grid_node_domain']=(i>=0)&(i<=nx-1)&(j>=0)&(j<=ny-1)
    d['inside_hrrr_half_cell_footprint']=(i>=-.5)&(i<=nx-.5)&(j>=-.5)&(j<=ny-.5)
    check=np.arange(0,len(la),300);xx,yy=xy(la[check],lo[check])
    projection_error=max(np.max(abs((xx-x0)/3000-check%nx)),np.max(abs((yy-y0)/3000-check//nx)))
    assert projection_error<1e-7
    d['original_group_longitude_scale']=d.groupby('weather_time').sample_lat.transform('mean').apply(lambda z:max(.2,float(np.cos(np.deg2rad(z)))))
    # Reproduce the original nearest-neighbour criterion by exhaustive comparison
    # against every decoded node. No rectangular geographic bounding box is used.
    index=np.empty(len(d),dtype=int);tmp=np.empty(len(la));tmp2=np.empty(len(la))
    for row,(lat,lon,scale) in enumerate(zip(d.sample_lat,d.sample_lon,d.original_group_longitude_scale)):
        np.subtract(la,lat,out=tmp);np.square(tmp,out=tmp)
        np.subtract(lo,lon,out=tmp2);np.square(tmp2,out=tmp2);np.multiply(tmp2,scale*scale,out=tmp2)
        np.add(tmp,tmp2,out=tmp);index[row]=int(np.argmin(tmp))
    d['original_nearest_grid_flat_index']=index
    d['original_nearest_grid_lat']=la[index];d['original_nearest_grid_lon']=lo[index]
    d['original_match_distance_km']=haversine(d.sample_lat,d.sample_lon,la[index],lo[index])
    print('Exact original metric replay completed',flush=True)
    # Geographic-nearest comparison is diagnostic only for positive-longitude
    # records, where the original non-periodic longitude metric is problematic.
    diagnostic=d.sample_lon.gt(0)
    inlat=np.ascontiguousarray(d.loc[diagnostic,'sample_lat'].to_numpy(),dtype=np.float64)
    inlon=np.ascontiguousarray(d.loc[diagnostic,'sample_lon'].to_numpy(),dtype=np.float64)
    outputs=[np.empty(len(inlat),dtype=np.float64) for _ in range(4)]
    indexes=np.empty(len(inlat),dtype=np.int32)
    result=lib.codes_grib_nearest_find_multiple(handle,0,inlat.ctypes.data_as(ptr),inlon.ctypes.data_as(ptr),len(inlat),
        *[a.ctypes.data_as(ptr) for a in outputs],indexes.ctypes.data_as(C.POINTER(C.c_int)))
    assert result==0
    d['geodesic_nearest_grid_lat']=np.nan
    d['geodesic_nearest_grid_lon']=np.nan
    d['geodesic_nearest_distance_km']=np.nan
    d.loc[diagnostic,'geodesic_nearest_grid_lat']=outputs[0]
    d.loc[diagnostic,'geodesic_nearest_grid_lon']=(outputs[1]+180)%360-180
    d.loc[diagnostic,'geodesic_nearest_distance_km']=outputs[3]
    d['nearest_longitude_wrap_penalty_km']=d.original_match_distance_km-d.geodesic_nearest_distance_km
    firsthour=d.weather_time.eq('2024-01-01 00:00:00+00:00')
    error=np.abs(arrays['values'][index[firsthour]]-d.loc[firsthour,'surface_pressure'].to_numpy())
    assert firsthour.sum()==50 and error.max()<.011
    d['partial_reporting_period']=d.ReportingPeriod.astype(str).ne('2024')
    d['reporting_days_inclusive']=366
    for row,s in d.loc[d.partial_reporting_period,'ReportingPeriod'].items():
        m=re.fullmatch(r'2024 \((\d+)/(\d+) - (\d+)/(\d+)\)',s)
        assert m,s
        sd,sm,ed,em=map(int,m.groups())
        d.loc[row,'reporting_days_inclusive']=(date(2024,em,ed)-date(2024,sm,sd)).days+1
    # This descriptive cohort rank is not a replacement for train-fitted labels.
    thresholds=np.quantile(d.total_co2_emissions_tonnes,[.2,.4,.6,.8])
    d['descriptive_whole_cohort_co2_quintile']=np.searchsorted(thresholds,d.total_co2_emissions_tonnes,side='right')+1
    keep=['MMSI','IMO','ShipName','ShipType','federated_node','ReportingPeriod','MRVSheet',
          'total_co2_emissions_tonnes','time_at_sea_hours','sample_lat','sample_lon','ais_time','weather_time',
          'weather_time_diff_hours','recomputed_weather_time_diff_hours','weather_within_tolerance','partial_reporting_period','reporting_days_inclusive',
          'descriptive_whole_cohort_co2_quintile','hrrr_grid_x_index_fractional','hrrr_grid_y_index_fractional',
          'inside_hrrr_grid_node_domain','inside_hrrr_half_cell_footprint','original_group_longitude_scale',
          'original_nearest_grid_flat_index','original_nearest_grid_lat','original_nearest_grid_lon',
          'original_match_distance_km','geodesic_nearest_grid_lat','geodesic_nearest_grid_lon',
          'geodesic_nearest_distance_km','nearest_longitude_wrap_penalty_km']
    d[keep].to_csv(OUT/'data_linkage_quality_audit.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    partial=d.loc[d.partial_reporting_period,keep]
    assert len(partial)==17
    partial.to_csv(OUT/'data_linkage_partial_reporting_records.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    groups=[]
    for name,sel in [('full_year',~d.partial_reporting_period),('partial_period',d.partial_reporting_period),
                     ('inside_grid',d.inside_hrrr_grid_node_domain),('outside_grid',~d.inside_hrrr_grid_node_domain)]:
        a=d.loc[sel]
        groups.append(dict(group=name,n=len(a),co2_min=a.total_co2_emissions_tonnes.min(),
                           co2_q25=a.total_co2_emissions_tonnes.quantile(.25),co2_median=a.total_co2_emissions_tonnes.median(),
                           co2_q75=a.total_co2_emissions_tonnes.quantile(.75),co2_max=a.total_co2_emissions_tonnes.max(),
                           time_at_sea_median=a.time_at_sea_hours.median(),reporting_days_min=a.reporting_days_inclusive.min(),
                           reporting_days_max=a.reporting_days_inclusive.max(),
                           match_distance_median_km=a.original_match_distance_km.median(),
                           match_distance_max_km=a.original_match_distance_km.max()))
    pd.DataFrame(groups).to_csv(OUT/'data_linkage_group_summary.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    header_audit=json.loads((WORK/'hrrr_source_grid_headers.json').read_text(encoding='utf-8'))
    assert header_audit['files_count']==168 and header_audit['distinct_grid_headers']==1
    within=d.inside_hrrr_grid_node_domain
    summary=dict(cohort_rows=len(d),inside_grid_nodes=int(within.sum()),outside_grid_nodes=int((~within).sum()),
                 inside_halfcell_footprint=int(d.inside_hrrr_half_cell_footprint.sum()),
                 projection_crosscheck_max_error_grid_cells=float(projection_error),
                 original_nearest_distance_km_quantiles={str(q):float(d.original_match_distance_km.quantile(q)) for q in [0,.5,.9,.95,.99,1]},
                 original_nearest_distance_threshold_counts={str(t):int(d.original_match_distance_km.gt(t).sum()) for t in [3,10,25,50,100,250,500,1000,5000]},
                 geodesic_nearest_diagnostic_checked_rows=int(diagnostic.sum()),
                 geodesic_nearest_diagnostic_scope='positive-longitude records only; uncomputed records are missing, not zero',
                 original_matching_algorithm='exhaustive exact squared latitude plus squared longitude scaled by group-mean-latitude cosine, matching source cKDTree metric',
                 original_matching_has_spatial_distance_threshold=False,
                 original_matching_tolerance_field='temporal only',
                 recomputed_weather_time_diff_hours_mean=float(d.recomputed_weather_time_diff_hours.mean()),
                 recomputed_weather_time_diff_hours_median=float(d.recomputed_weather_time_diff_hours.median()),
                 recomputed_weather_time_diff_hours_max=float(d.recomputed_weather_time_diff_hours.max()),
                 recomputed_temporal_greater_than_1h=int(d.recomputed_weather_time_diff_hours.gt(1).sum()),
                 stored_temporal_hours_multiplier_to_correct=1000,
                 positive_longitudes=int(d.sample_lon.gt(0).sum()),
                 firsthour_pressure_check_rows=int(firsthour.sum()),firsthour_max_pressure_difference_pa=float(error.max()),
                 partial_reporting_rows=17,full_year_rows=1155,
                 partial_reporting_by_fleet=partial.federated_node.value_counts().to_dict(),
                 partial_reporting_by_descriptive_cohort_quintile=partial.descriptive_whole_cohort_co2_quintile.value_counts().sort_index().to_dict(),
                 partial_reporting_days_min=int(partial.reporting_days_inclusive.min()),partial_reporting_days_max=int(partial.reporting_days_inclusive.max()),
                 all_grid_headers_identical=True,n_grid_files_checked=168,n_fields_firstfile_checked=5,
                 hrrr_parameters=parameters,metadata=json.loads(META.read_text()),
                 elapsed_seconds=time.perf_counter()-start)
    source_files=[COHORT,ALIGN,GRIB,META,WORK/'hrrr_source_grid_headers.json']
    fingerprints=[dict(path=str(p),size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in source_files]
    summary['source_fingerprints']=fingerprints
    (WORK/'data_linkage_quality_audit_checks.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'data_linkage_source_fingerprints.json').write_text(json.dumps(fingerprints,ensure_ascii=False,indent=2),encoding='utf-8')
    lib.codes_handle_delete(handle)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['hrrr_parameters','metadata','source_fingerprints']},ensure_ascii=False,indent=2))
    print(pd.DataFrame(groups).to_string(index=False))


if __name__=='__main__':main()
