"""Publication figures6--9 from the new complete primary execution.

Original artwork is never overwritten. Requires exclusive timing summaries for Fig8.
"""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator,FuncFormatter,FixedLocator

ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('D:/ASC投稿/OCM核心主实验新执行_20261024/results')
OUT=ROOT/'Figures'
BLUE='#2C698D';TEAL='#238B83';ORANGE='#C47A28';DARK='#263238';GRAY='#6E7781'
SCENARIOS=['stale_mild','stale_moderate','stale_severe']
LABELS=['Mild','Moderate','Severe']
METHODS=['fedavg','staleness_decay','sa_gsa']
METHOD_LABELS=['FedAvg','Delay weighting','Weighting + GSA']
COLORS=[BLUE,TEAL,ORANGE]
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,'xtick.labelsize':9,'ytick.labelsize':9,
 'axes.edgecolor':DARK,'axes.linewidth':.8,'text.color':DARK,'axes.labelcolor':DARK,'xtick.color':DARK,'ytick.color':DARK,
 'pdf.fonttype':42,'ps.fonttype':42,'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white'})
records=[]
DEVELOPMENT=Path('D:/ASC投稿/OCM开发与消融30轮新执行_20261024/analysis')

def style(ax,axis='y'):
    ax.spines[['top','right']].set_visible(False)
    ax.tick_params(direction='out',length=3,width=.7)
    ax.grid(axis=axis,color='#E6E9EB',linewidth=.6,zorder=0)
    ax.set_axisbelow(True)

def panel(ax,label,title,y=-.30):
    ax.text(.5,y,f'({label}) {title}',ha='center',va='top',transform=ax.transAxes,fontsize=10,fontweight='bold')

def ci(x,seed=71024):
    x=np.asarray(x,float);rng=np.random.default_rng(seed)
    vals=x[rng.integers(0,len(x),size=(20000,len(x)))].mean(axis=1)
    return float(x.mean()),*np.quantile(vals,[.025,.975])

def save(fig,name,inputs):
    OUT.mkdir(parents=True,exist_ok=True)
    for ext in ['png','pdf']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=600,bbox_inches='tight',pad_inches=.06)
    records.append({'figure':name,'inputs':{str(p):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in inputs}})
    plt.close(fig)

def fig5():
    task=pd.read_csv(DEVELOPMENT/'table4_new_execution.csv').set_index('method')
    abl=pd.read_csv(DEVELOPMENT/'table5_new_execution.csv').set_index('variant')
    assert (task.n==5).all() and (abl.n==5).all()
    f,axs=plt.subplots(1,3,figsize=(8.3,3.7),gridspec_kw={'width_ratios':[1.15,1,1]})
    f.subplots_adjust(left=.11,right=.985,top=.95,bottom=.25,wspace=.85)
    methods=['local','fedavg','fedprox','fedbn','scaffold','gsa']
    labels=['Local-only','FedAvg','FedProx','FedBN','SCAFFOLD','GSA']
    variants=['gsa','no_ema','no_direction_bound','random_consensus','nonhomologous','norm_only']
    vlabs=['Full GSA','No EMA','No direction','Random target','Nonhomologous','Norm only']
    data=[]
    for j,m in enumerate(methods):
        r=task.loc[m];mean=r.macro_f1_mean;lo=r.macro_f1_ci95_low;hi=r.macro_f1_ci95_high
        axs[0].errorbar(mean,j,xerr=[[mean-lo],[hi-mean]],fmt='o',mfc='white',color=ORANGE if m=='gsa' else BLUE,mew=1.2,ms=4.5,lw=1.2,capsize=2.3)
        data.append({'panel':'a','method':m,'metric':'macro_f1','mean':mean,'ci95_low':lo,'ci95_high':hi})
    axs[0].set_yticks(range(6),labels);axs[0].set_xlim(0,.70);axs[0].set_xlabel('Test macro-F1');panel(axs[0],'a','Task performance',y=-.22)
    for a,metric in [(1,'d_spec_after'),(2,'macro_f1')]:
        for j,v in enumerate(variants):
            r=abl.loc[v];mean=r[metric+'_mean'];lo=r[metric+'_ci95_low'];hi=r[metric+'_ci95_high']
            axs[a].errorbar(mean,j,xerr=[[mean-lo],[hi-mean]],fmt='o',mfc='white',color=ORANGE if v=='gsa' else BLUE,mew=1.2,ms=4.5,lw=1.2,capsize=2.3)
            data.append({'panel':chr(97+a),'variant':v,'metric':metric,'mean':mean,'ci95_low':lo,'ci95_high':hi})
        axs[a].set_yticks(range(6),vlabs if a==1 else [])
    axs[1].set_xlim(0,.037);axs[1].set_xlabel(r'Post-calibration $D_{spec}$');panel(axs[1],'b','Spectral response',y=-.22)
    axs[2].set_xlim(.32,.45);axs[2].set_xlabel('Test macro-F1');panel(axs[2],'c','Task response',y=-.22)
    for ax in axs:ax.set_ylim(5.65,-.65);style(ax,'x')
    pd.DataFrame(data).to_csv(OUT/'Fig05_data.csv',index=False)
    save(f,'Fig05_task_and_ablation',[DEVELOPMENT/'table4_new_execution.csv',DEVELOPMENT/'table5_new_execution.csv'])

def fig6(per):
    base=per[per.method=='fedavg']
    f,axs=plt.subplots(1,2,figsize=(7.35,3.25),gridspec_kw={'width_ratios':[1.12,1]})
    f.subplots_adjust(left=.09,right=.985,top=.80,bottom=.27,wspace=.42)
    names=['stress_excess_nll_auc','recovery_excess_nll_auc'];colors=[BLUE,TEAL];markers=['o','s'];labs=['Stress-period damage','Recovery residual']
    data=[]
    for j,(name,col,mk,lab) in enumerate(zip(names,colors,markers,labs)):
        means=[];lo=[];hi=[]
        for s in SCENARIOS:
            x=base[base.scenario==s].sort_values('seed')[name].to_numpy();mean,l,h=ci(x)
            means.append(mean);lo.append(l);hi.append(h);data.append({'panel':'a','metric':name,'scenario':s,'mean':mean,'ci95_low':l,'ci95_high':h})
        axs[0].errorbar(np.arange(3),means,yerr=[np.array(means)-lo,np.array(hi)-means],color=col,marker=mk,mfc='white',mew=1.4,ms=5,lw=1.5,capsize=2.5,label=lab)
        reference=base[base.scenario=='stale_mild'].set_index('seed')[name].sort_index()
        for i,s in enumerate(SCENARIOS[1:]):
            x=base[base.scenario==s].set_index('seed')[name].sort_index()-reference
            mean,l,h=ci(x);y=i+(j-.5)*.21
            axs[1].errorbar(mean,y,xerr=[[mean-l],[h-mean]],fmt=mk,color=col,mfc='white',mew=1.3,ms=5,capsize=2.5,lw=1.3)
            data.append({'panel':'b','metric':name,'scenario':s,'mean':mean,'ci95_low':l,'ci95_high':h})
    axs[0].set_xticks(range(3),LABELS);axs[0].set_ylim(bottom=0);axs[0].set_ylabel('Cumulative NLL excess');style(axs[0]);panel(axs[0],'a','Absolute dose response')
    axs[1].set_yticks(range(2),LABELS[1:]);axs[1].invert_yaxis();axs[1].set_xlabel('Increase relative to mild lag');axs[1].axvline(0,color=GRAY,lw=.7);style(axs[1],'x');panel(axs[1],'b','Additional burden')
    f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.52,.995),fontsize=9,handlelength=2)
    pd.DataFrame(data).to_csv(OUT/'Fig06_data.csv',index=False)
    save(f,'Fig06_dose_response',[SOURCE/'sa_gsa_per_seed.csv'])

def fig7(per):
    f,axs=plt.subplots(1,2,figsize=(7.35,3.25));f.subplots_adjust(left=.09,right=.985,top=.80,bottom=.27,wspace=.32)
    data=[];x=np.arange(3);width=.21
    for a,(metric,subtitle) in enumerate([('stress_excess_nll_auc','Stress-period damage'),('recovery_excess_nll_auc','Recovery residual')]):
        for j,(method,label,color) in enumerate(zip(METHODS,METHOD_LABELS,COLORS)):
            means=[];lower=[];upper=[]
            for s in SCENARIOS:
                vals=per[(per.method==method)&(per.scenario==s)].sort_values('seed')[metric]
                mean,lo,hi=ci(vals);means.append(mean);lower.append(mean-lo);upper.append(hi-mean)
                data.append({'panel':a,'metric':metric,'method':method,'scenario':s,'mean':mean,'ci95_low':lo,'ci95_high':hi})
            axs[a].bar(x+(j-1)*width,means,width,color=color,alpha=.9,label=label,zorder=3)
            axs[a].errorbar(x+(j-1)*width,means,yerr=[lower,upper],fmt='none',ecolor=DARK,elinewidth=.8,capsize=2,capthick=.8,zorder=4)
        axs[a].set_xticks(x,LABELS);axs[a].set_ylim(bottom=0);axs[a].set_ylabel('Cumulative NLL excess');style(axs[a]);panel(axs[a],chr(97+a),subtitle)
    f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=3,frameon=False,bbox_to_anchor=(.52,.995),fontsize=9,columnspacing=1.3,handlelength=1.5)
    pd.DataFrame(data).to_csv(OUT/'Fig07_data.csv',index=False)
    save(f,'Fig07_weighting_mitigation',[SOURCE/'sa_gsa_per_seed.csv'])

def fig8(per,primary,timing_path):
    timing=pd.read_csv(timing_path)
    if {'scenario','seed','method','wall_seconds'}.issubset(timing.columns):
        timing=timing.pivot(index=['scenario','seed'],columns='method',values='wall_seconds').reset_index()
        timing=timing.rename(columns={'staleness_decay':'staleness_decay_seconds','sa_gsa':'sa_gsa_seconds'})
    # Expect one paired row per seed/scenario with actual isolated durations.
    needed={'scenario','seed','staleness_decay_seconds','sa_gsa_seconds'}
    if not needed.issubset(timing.columns):raise ValueError(f'Timing needs {needed}; got {timing.columns.tolist()}')
    f,axs=plt.subplots(1,3,figsize=(7.35,3.4));f.subplots_adjust(left=.09,right=.985,top=.96,bottom=.37,wspace=.67)
    data=[]
    for i,s in enumerate(SCENARIOS[1:]):
        ref=per[(per.method=='staleness_decay')&(per.scenario==s)].set_index('seed').sort_index()
        gsa=per[(per.method=='sa_gsa')&(per.scenario==s)].set_index('seed').sort_index()
        # Same received updates before/after GSA, within the combined trajectory.
        mean=100*(1-gsa.stress_d_spec_after.mean()/gsa.stress_d_spec_before.mean())
        rng=np.random.default_rng(81024+i);idx=rng.integers(0,10,size=(20000,10))
        boot=100*(1-gsa.stress_d_spec_after.to_numpy()[idx].mean(1)/gsa.stress_d_spec_before.to_numpy()[idx].mean(1));lo,hi=np.quantile(boot,[.025,.975])
        axs[0].barh(i,mean,height=.5,color=ORANGE,alpha=.9,zorder=3);axs[0].errorbar(mean,i,xerr=[[mean-lo],[hi-mean]],fmt='none',ecolor=DARK,capsize=2.5,lw=.8,zorder=4)
        data.append({'panel':'a','scenario':s,'mean':mean,'ci95_low':lo,'ci95_high':hi})
        row=primary[primary.scenario==s].iloc[0];m=float(row.sa_gsa_minus_comparator_mean);l=float(row.ci95_low);h=float(row.ci95_high)
        axs[1].errorbar(m,i,xerr=[[m-l],[h-m]],fmt='o',color=ORANGE,ms=5,mew=1.2,mfc='white',capsize=2.5,lw=1.4)
        data.append({'panel':'b','scenario':s,'mean':m,'ci95_low':l,'ci95_high':h,'holm_p':row.holm_p})
        q=timing[timing.scenario==s].sort_values('seed');assert len(q)==10
        ref_t=q.staleness_decay_seconds.to_numpy();gsa_t=q.sa_gsa_seconds.to_numpy()
        mean=100*(gsa_t.mean()/ref_t.mean()-1)
        idx=np.random.default_rng(82024+i).integers(0,10,size=(20000,10));boot=100*(gsa_t[idx].mean(1)/ref_t[idx].mean(1)-1);lo,hi=np.quantile(boot,[.025,.975])
        axs[2].barh(i,mean,height=.5,color=ORANGE,alpha=.9,zorder=3);axs[2].errorbar(mean,i,xerr=[[mean-lo],[hi-mean]],fmt='none',ecolor=DARK,capsize=2.5,lw=.8,zorder=4)
        data.append({'panel':'c','scenario':s,'mean':mean,'ci95_low':lo,'ci95_high':hi})
    for j,ax in enumerate(axs):
        ax.set_yticks(range(2),LABELS[1:] if j==0 else []);ax.set_ylim(1.65,-.65);style(ax,'x')
        ax.axvline(0,color=GRAY,lw=.7,ls='--' if j==1 else '-')
    axs[0].set_xlim(0,70);axs[0].set_xlabel('Before–after reduction (%)');panel(axs[0],'a','Spectral discrepancy',y=-.43)
    axs[1].set_xlabel('GSA − weighting\n'+r'($10^{-3}$ cumulative NLL)');axs[1].xaxis.set_major_locator(FixedLocator([-.008,-.004,0]));axs[1].xaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'{x*1000:g}'));panel(axs[1],'b','Incremental task effect',y=-.43)
    axs[2].set_xlim(left=0);axs[2].set_xlabel('Runtime increase (%)');panel(axs[2],'c','Additional computation',y=-.43)
    pd.DataFrame(data).to_csv(OUT/'Fig08_data.csv',index=False)
    save(f,'Fig08_gsa_increment',[SOURCE/'sa_gsa_per_seed.csv',SOURCE/'sa_gsa_primary_outcomes.csv',timing_path])

def fig9(clean):
    f,axs=plt.subplots(1,2,figsize=(7.35,3.0),gridspec_kw={'width_ratios':[1.25,1]});f.subplots_adjust(left=.20,right=.985,top=.96,bottom=.36,wspace=.55)
    names=['validation_nll_last10_diff','test_nll_diff'];labels=['Validation NLL','Test NLL'];data=[]
    for i,n in enumerate(names):
        r=clean[clean.metric==n].iloc[0];m=r.mean_difference;lo=r.ci95_low;hi=r.ci95_high
        axs[0].errorbar(m,i,xerr=[[m-lo],[hi-m]],fmt='o',color=ORANGE,mfc='white',mew=1.2,ms=5,capsize=3,lw=1.4)
        data.append(r.to_dict())
    axs[0].set_yticks(range(2),labels);axs[0].set_ylim(1.65,-.65);axs[0].set_xlim(-.001,.0115);axs[0].axvspan(-.001,.01,color='#F0F3F4',zorder=0);axs[0].axvline(.01,color=DARK,ls='--',lw=1);axs[0].axvline(0,color=GRAY,ls=':',lw=.8);axs[0].set_xlabel('GSA − FedAvg (NLL)');style(axs[0],'x');panel(axs[0],'a','Loss tolerance: +0.01',y=-.40)
    r=clean[clean.metric=='test_macro_f1_diff'].iloc[0];m=r.mean_difference*100;lo=r.ci95_low*100;hi=r.ci95_high*100
    axs[1].set_xlim(-1.15,.60);axs[1].axvspan(-1,.60,color='#F0F3F4',zorder=0);axs[1].axvline(-1,color=DARK,ls='--',lw=1);axs[1].axvline(0,color=GRAY,ls=':',lw=.8);axs[1].errorbar(m,0,xerr=[[m-lo],[hi-m]],fmt='o',color=ORANGE,mfc='white',mew=1.2,ms=5,capsize=3,lw=1.4);axs[1].set_ylim(-.7,.7);axs[1].set_yticks([0],['Macro-F1']);axs[1].set_xlabel('GSA − FedAvg\n(percentage points)');style(axs[1],'x');panel(axs[1],'b','F1 tolerance: −1 pp',y=-.40);data.append(r.to_dict())
    pd.DataFrame(data).to_csv(OUT/'Fig09_data.csv',index=False)
    save(f,'Fig09_clean_tolerances',[SOURCE/'sa_gsa_clean_noninferiority.csv'])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--timing',type=Path);ap.add_argument('--without-timing',action='store_true');args=ap.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    per=pd.read_csv(SOURCE/'sa_gsa_per_seed.csv');primary=pd.read_csv(SOURCE/'sa_gsa_primary_outcomes.csv');clean=pd.read_csv(SOURCE/'sa_gsa_clean_noninferiority.csv')
    assert len(per)==150 and len(primary)==2 and len(clean)==3
    fig5();fig6(per);fig7(per);fig9(clean)
    if args.timing:fig8(per,primary,args.timing)
    elif not args.without_timing:raise ValueError('Provide final exclusive timing CSV or --without-timing')
    (OUT/'figure_provenance.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(records,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
