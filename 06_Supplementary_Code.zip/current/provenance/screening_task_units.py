"""Descriptive task-unit summaries from archived screening outputs.

No model fitting or new significance tests. The percentile seed bootstrap
matches working/management_analysis.py in the submitted code archive.
"""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import io
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'Data_Tables'
SOURCE = Path(r'D:\ASC投稿\OCM提交前核查稿_20261024\05_Supplementary_Data.zip')
CELLS = [('primary', 'moderate'), ('primary', 'severe'), ('no_annual', 'moderate')]
METHODS = ['FedAvg', 'LocalPersonalized', 'CentralMLP', 'RandomForest', 'Logistic', 'ShipTypeRule']
CONTRASTS = [('Combined', 'StalenessAware'), ('StalenessAware', 'FedAvg')]


def ci(values):
    values = np.asarray(values, float)
    assert len(values) == 10 and np.isfinite(values).all()
    means = np.random.default_rng(90210).choice(values, (10000, len(values)), replace=True).mean(1)
    return float(values.mean()), float(np.quantile(means, .025)), float(np.quantile(means, .975))


def save(frame, name):
    frame.to_csv(OUT / name, index=False, encoding='utf-8-sig', float_format='%.12g')


def main():
    OUT.mkdir(exist_ok=True)
    with ZipFile(SOURCE) as archive:
        def read(name):
            return pd.read_csv(io.BytesIO(archive.read('Data_Tables/' + name)))
        baseline = read('baseline_by_seed.csv')
        runs = read('all_450_runs.csv')
        original_s6 = read('clean_management_outcomes.csv')
        source_fingerprints = {
            name: hashlib.sha256(archive.read('Data_Tables/' + name)).hexdigest()
            for name in ['baseline_by_seed.csv', 'all_450_runs.csv', 'clean_management_outcomes.csv']
        }
    assert len(baseline) == 120 and len(runs) == 450
    assert baseline.groupby(['regime', 'method']).size().eq(10).all()
    assert baseline.selected_n_10.eq(24).all()
    baseline['high_count_10'] = baseline.precision_10 * baseline.selected_n_10
    assert np.max(np.abs(baseline.high_count_10 - baseline.high_count_10.round())) < 1e-8
    baseline['high_count_10'] = baseline.high_count_10.round().astype(int)
    baseline['test_high_count'] = baseline.high_count_10 / baseline.recall_10
    assert np.max(np.abs(baseline.test_high_count - baseline.test_high_count.round())) < 1e-8
    baseline['test_high_count'] = baseline.test_high_count.round().astype(int)
    assert baseline.groupby(['regime', 'seed']).test_high_count.nunique().eq(1).all()
    assert baseline.groupby('seed').test_high_count.nunique().eq(1).all()
    summary = []
    max_coverage_discrepancy = 0.0
    for regime in ['primary', 'no_annual']:
        for method in METHODS:
            g = baseline[(baseline.regime == regime) & (baseline.method == method)].sort_values('seed')
            row = dict(regime=regime, method=method, n_seeds=10, test_vessels=235, selected_vessels=24,
                       highest_class_test_vessels_mean=float(g.test_high_count.mean()),
                       highest_class_test_vessels_min=int(g.test_high_count.min()),
                       highest_class_test_vessels_max=int(g.test_high_count.max()))
            for values, label in [(g.high_count_10, 'selected_high_vessels'),
                                  (100 * g.recall_10, 'recall_pct'),
                                  (100 * g.emission_coverage_10, 'emission_coverage_pct')]:
                mean, low, high = ci(values)
                row[label + '_mean'] = mean
                row[label + '_ci_low'] = low
                row[label + '_ci_high'] = high
                if label == 'emission_coverage_pct':
                    prior = original_s6[(original_s6.regime == regime) & (original_s6.method == method)
                                        & (original_s6.metric == 'emission_coverage_10')].iloc[0]
                    discrepancy = np.max(np.abs(np.array([mean, low, high]) - prior[['mean', 'ci_low', 'ci_high']].to_numpy(float)))
                    max_coverage_discrepancy = max(max_coverage_discrepancy, float(discrepancy))
            summary.append(row)
    assert max_coverage_discrepancy < 1e-9
    summary = pd.DataFrame(summary)
    save(summary, 'screening_reference_task_units.csv')
    save(baseline[['regime', 'method', 'seed', 'selected_n_10', 'high_count_10', 'test_high_count',
                   'recall_10', 'emission_coverage_10']], 'screening_reference_task_units_by_seed.csv')

    totals = baseline[baseline.method == 'FedAvg'][['regime', 'seed', 'test_high_count']]
    runs = runs.merge(totals, on=['regime', 'seed'], validate='many_to_one')
    runs['stress_high_count'] = runs.stress_absolute_recall10 * runs.test_high_count
    runs['matched_clean_count_loss'] = runs.stress_recall10_loss * runs.test_high_count
    runs['clean_stress_window_high_count'] = runs.stress_high_count + runs.matched_clean_count_loss
    assert runs[['regime', 'severity', 'seed', 'rotation', 'method']].drop_duplicates().shape[0] == 450
    assert runs.groupby(['regime', 'severity', 'seed', 'method']).size().eq(5).all()
    seed_means = runs.groupby(['regime', 'severity', 'seed', 'method'])[
        ['matched_clean_count_loss', 'stress_high_count', 'clean_stress_window_high_count']].mean().reset_index()
    seed_rows, contrast_rows = [], []
    for regime, severity in CELLS:
        g = seed_means[(seed_means.regime == regime) & (seed_means.severity == severity)]
        p = g.pivot(index='seed', columns='method', values='matched_clean_count_loss').sort_index()
        assert p.shape == (10, 3)
        for left, right in CONTRASTS:
            differences = p[left] - p[right]
            mean, low, high = ci(differences)
            contrast_rows.append(dict(
                regime=regime, severity=severity, contrast=left + ' - ' + right,
                left_method=left, right_method=right, n_seeds=10, rotations_per_seed=5,
                stress_rounds_per_rotation=10, selected_vessels=24,
                left_matched_clean_count_loss_mean=float(p[left].mean()),
                right_matched_clean_count_loss_mean=float(p[right].mean()),
                count_loss_difference_mean=mean, count_loss_difference_ci_low=low, count_loss_difference_ci_high=high,
                fewer_missed_vessels_mean=-mean, fewer_missed_vessels_ci_low=-high, fewer_missed_vessels_ci_high=-low,
                inference='descriptive_seed_bootstrap', bootstrap_resamples=10000, bootstrap_seed=90210))
            for seed, difference in differences.items():
                seed_rows.append(dict(
                    regime=regime, severity=severity, contrast=left + ' - ' + right, seed=int(seed),
                    test_high_count=int(totals[(totals.regime == regime) & (totals.seed == seed)].test_high_count.iloc[0]),
                    left_matched_clean_count_loss=float(p.loc[seed, left]),
                    right_matched_clean_count_loss=float(p.loc[seed, right]),
                    count_loss_difference=float(difference), fewer_missed_vessels=-float(difference),
                    rotations_averaged=5, stress_rounds_averaged=10, selected_vessels=24))
    contrasts, seed_differences = pd.DataFrame(contrast_rows), pd.DataFrame(seed_rows)
    assert len(contrasts) == 6 and len(seed_differences) == 60
    save(contrasts, 'screening_task_count_contrasts.csv')
    save(seed_differences, 'screening_task_count_seed_differences.csv')
    metadata = dict(
        source_archive=str(SOURCE), source_archive_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        source_member_sha256=source_fingerprints, source_protocol='screening extension, seeds 1001-1010; gated backbone; full-rank spectral variant; exp(-0.7*lag)',
        baseline_round=60, stress_rounds='11-20', bootstrap_resamples=10000, bootstrap_seed=90210,
        interval='unadjusted descriptive percentile seed bootstrap, 2.5% and 97.5%',
        baseline_count_formula='precision_10 * selected_n_10',
        highest_class_total_formula='selected_high_count / recall_10, verified integer and identical across methods within seed',
        stress_count_loss_formula='stress_recall10_loss * test_high_count; loss is clean minus stressed',
        contrast_formula='left count loss - right count loss; negative favors left',
        fewer_missed_formula='right count loss - left count loss; positive favors left',
        rotation_handling='average five rotations within seed before bootstrap',
        seed_order='ascending 1001-1010', n_reference_rows=12, n_contrast_rows=6, n_seed_contrast_rows=60,
        new_model_training=False, new_significance_tests=False,
        max_discrepancy_from_original_S6_coverage_intervals=max_coverage_discrepancy,
        distinction='not the separate learned-projection protocol in Supplementary Table S12')
    (ROOT / 'working' / 'screening_task_units_checks.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    print(summary.to_string(index=False))
    print(contrasts[['regime', 'severity', 'contrast', 'count_loss_difference_mean',
                     'count_loss_difference_ci_low', 'count_loss_difference_ci_high']].to_string(index=False))


if __name__ == '__main__':
    main()
