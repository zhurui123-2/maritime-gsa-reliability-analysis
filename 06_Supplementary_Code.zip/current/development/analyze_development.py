from pathlib import Path
import json,sys
import pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'historical_core'))
import analyze_results as stats
out=ROOT/'results';dest=ROOT/'analysis';dest.mkdir(exist_ok=True)
results=pd.read_csv(out/'all_results.csv');rounds=pd.read_csv(out/'all_rounds.csv')
main=results[results.phase=='main'].copy()
summary=stats.summarize(main,['method'],['macro_f1','nll','worst_client_macro_f1','balanced_accuracy'])
summary.to_csv(dest/'table4_new_execution.csv',index=False)
ab=results[(results.phase=='ablation')|((results.phase=='main')&(results.method=='gsa'))].copy()
mechanism=rounds[(rounds.phase=='ablation')|((rounds.phase=='main')&(rounds.method=='gsa'))].groupby(['variant','seed'],as_index=False).agg(
    d_spec_after=('d_spec_after','mean'),d_repr=('d_repr','mean'),direction_cosine=('direction_cosine','mean'),
    actual_alpha=('actual_alpha','mean'),fallback_rate=('fallback_rate','mean'))
ab=ab.merge(mechanism,on=['variant','seed'],validate='one_to_one')
ab.to_csv(dest/'ablation_per_seed.csv',index=False)
summary_ab=stats.summarize(ab,['variant'],['macro_f1','nll','d_spec_after','d_repr','direction_cosine','actual_alpha','fallback_rate'])
summary_ab.to_csv(dest/'table5_new_execution.csv',index=False)
tests=pd.DataFrame([stats.paired_test(main,metric) for metric in ['macro_f1','nll','worst_client_macro_f1']]);tests['holm_p']=stats.holm(tests.p_exact_sign)
tests.to_csv(dest/'development_three_comparisons.csv',index=False)
checks={'n_main_final_rows':len(main),'n_unique_development_and_ablation_jobs':len(results),'n_ablation_configurations_including_reused_complete':ab.variant.nunique(),
    'n_nonlocal_round_rows':len(rounds),'rounds_per_nonlocal_job':30,'local_jobs':int((results.method=='local').sum()),
    'missing_NLL':int(rounds.validation_nll.isna().sum()),'PYTHONHASHSEED':'0','MIA_executed':False,
    'bootstrap':'Recovered 2000-resample seed-bootstrap routine; unadjusted confidence intervals; n=5 development seeds.',
    'timing':'Concurrent execution; omit wall times from substantive table comparison.',
    'random_consensus':'Original process hash seed not available; frozen0 in this new execution. New random-consensus values replace old untraceable figures.'}
(dest/'audit.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(summary.to_string(index=False));print(summary_ab.to_string(index=False));print(json.dumps(checks,indent=2))

