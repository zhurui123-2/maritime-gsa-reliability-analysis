import csv
from pathlib import Path


PATH = Path(r"E:\航运实验\experiments\results\gsa_reliability_rebuild_20260803\main_results.csv")
BASE = [
    "setting", "method", "variant", "seed", "rounds", "participation",
    "macro_f1", "balanced_accuracy", "nll", "brier", "ece",
    "worst_client_macro_f1", "client_macro_f1_variance",
]
TAIL = ["wall_seconds", "svd_seconds", "svd_share", "per_round_communication_mb", "client_macro_f1"]
ATTACK = ["mia_auroc", "mia_advantage", "mia_matched_samples"]
HEADER = BASE + ATTACK + TAIL[:-1] + ["missing_rate", TAIL[-1]]


with PATH.open("r", encoding="utf-8-sig", newline="") as f:
    rows = list(csv.reader(f))

old_header = rows[0]
if len(old_header) != 18:
    raise RuntimeError(f"Unexpected old header width: {len(old_header)}")

fixed = []
for line_no, row in enumerate(rows[1:], start=2):
    if len(row) == 18:
        values = row[:13] + ["", "", ""] + row[13:17] + [""] + [row[17]]
    elif len(row) == 21:
        values = row[:13] + row[13:16] + row[16:20] + [""] + [row[20]]
    else:
        raise RuntimeError(f"Unexpected width {len(row)} at line {line_no}")
    if len(values) != len(HEADER):
        raise RuntimeError((line_no, len(values), len(HEADER)))
    fixed.append(values)

backup = PATH.with_suffix(".pre_repair.csv")
backup.write_bytes(PATH.read_bytes())
with PATH.open("w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(HEADER)
    writer.writerows(fixed)
print(f"repaired_rows={len(fixed)} columns={len(HEADER)} backup={backup}")
