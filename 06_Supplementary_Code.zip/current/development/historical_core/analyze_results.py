from __future__ import annotations

import itertools
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr


OUT = Path(r"E:\航运实验\experiments\results\gsa_reliability_rebuild_20260803")
RNG = np.random.default_rng(20260803)


def bootstrap_ci(values, n=2000, alpha=0.05):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return (math.nan, math.nan)
    samples = RNG.choice(x, size=(n, len(x)), replace=True).mean(axis=1)
    return tuple(np.quantile(samples, [alpha / 2, 1 - alpha / 2]))


def exact_sign_permutation_p(values):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return math.nan
    observed = abs(x.mean())
    stats = []
    for signs in itertools.product([-1, 1], repeat=len(x)):
        stats.append(abs(np.mean(x * np.asarray(signs))))
    return float(np.mean(np.asarray(stats) >= observed - 1e-12))


def cohen_dz(values):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) < 2 or np.std(x, ddof=1) <= 1e-12:
        return math.nan
    return float(np.mean(x) / np.std(x, ddof=1))


def holm(p_values):
    p = np.asarray(p_values, float)
    adjusted = np.full(len(p), np.nan)
    valid = np.where(np.isfinite(p))[0]
    order = valid[np.argsort(p[valid])]
    running = 0.0
    m = len(order)
    for rank, idx in enumerate(order):
        value = min(1.0, (m - rank) * p[idx])
        running = max(running, value)
        adjusted[idx] = running
    return adjusted


def paired_test(frame, metric, treatment="gsa", control="fedavg", setting="natural_ship_type"):
    sub = frame[frame.setting.eq(setting) & frame.method.isin([treatment, control])]
    pivot = sub.pivot_table(index="seed", columns="method", values=metric, aggfunc="first").dropna()
    diff = pivot[treatment] - pivot[control]
    lo, hi = bootstrap_ci(diff)
    return {
        "setting": setting, "metric": metric, "treatment": treatment, "control": control,
        "n_pairs": len(diff), "control_mean": float(pivot[control].mean()), "treatment_mean": float(pivot[treatment].mean()),
        "mean_difference": float(diff.mean()), "ci95_low": float(lo), "ci95_high": float(hi),
        "cohen_dz": cohen_dz(diff), "p_exact_sign": exact_sign_permutation_p(diff),
    }


def summarize(frame, group_cols, metrics):
    rows = []
    for keys, group in frame.groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        row = dict(zip(group_cols, keys))
        row["n"] = len(group)
        for metric in metrics:
            values = pd.to_numeric(group[metric], errors="coerce").dropna().to_numpy()
            if len(values):
                lo, hi = bootstrap_ci(values)
                row.update({f"{metric}_mean": float(np.mean(values)), f"{metric}_std": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
                            f"{metric}_ci95_low": float(lo), f"{metric}_ci95_high": float(hi)})
        rows.append(row)
    return pd.DataFrame(rows)


def lag_correlations(rounds):
    rows = []
    selected = rounds[rounds.variant.isin(["none", "gsa"]) & rounds.setting.eq("natural_ship_type")]
    for (method, variant, seed), group in selected.groupby(["method", "variant", "seed"]):
        g = group.sort_values("round").copy()
        g["next_d_repr"] = g.d_repr.shift(-1)
        g["next_nll_change"] = g.validation_nll.diff().abs().shift(-1)
        x_col = "d_spec_after" if method == "gsa" else "d_spec_before"
        for outcome in ("next_d_repr", "next_nll_change"):
            pair = g[[x_col, outcome]].dropna()
            rho, p = spearmanr(pair[x_col], pair[outcome]) if len(pair) >= 5 else (math.nan, math.nan)
            rows.append({"method": method, "variant": variant, "seed": seed, "predictor": x_col, "outcome": outcome,
                         "n_round_pairs": len(pair), "spearman_rho": float(rho), "p_value": float(p)})
    return pd.DataFrame(rows)


def main():
    main = pd.read_csv(OUT / "main_results.csv")
    rounds = pd.read_csv(OUT / "round_metrics.csv")
    ablation = pd.read_csv(OUT / "ablation_results.csv")
    robustness = pd.read_csv(OUT / "robustness_results.csv")

    summary_main = summarize(
        main[main.setting.eq("natural_ship_type")], ["method"],
        ["macro_f1", "balanced_accuracy", "nll", "brier", "ece", "worst_client_macro_f1", "client_macro_f1_variance", "mia_auroc", "wall_seconds", "svd_share"],
    )
    summary_main.to_csv(OUT / "summary_main.csv", index=False, encoding="utf-8-sig")

    tests = []
    for setting in ["iid", "dirichlet_1.0", "dirichlet_0.3", "dirichlet_0.1", "natural_ship_type"]:
        for metric in ["macro_f1", "balanced_accuracy", "nll", "brier", "worst_client_macro_f1"]:
            tests.append(paired_test(main, metric, setting=setting))
    tests.append(paired_test(main, "mia_auroc", setting="natural_ship_type"))
    tests.append(paired_test(main, "wall_seconds", setting="natural_ship_type"))
    tests_df = pd.DataFrame(tests)
    tests_df["p_holm"] = holm(tests_df.p_exact_sign)
    tests_df.to_csv(OUT / "paired_method_tests.csv", index=False, encoding="utf-8-sig")

    mech = rounds[rounds.method.isin(["fedavg", "gsa"]) & rounds.variant.isin(["none", "gsa"])].groupby(
        ["setting", "method", "variant", "seed"], as_index=False
    ).agg(d_spec_before=("d_spec_before", "mean"), d_spec_after=("d_spec_after", "mean"),
          d_repr=("d_repr", "mean"), validation_nll=("validation_nll", "mean"),
          validation_nll_std=("validation_nll", "std"), actual_alpha=("actual_alpha", "mean"),
          direction_cosine=("direction_cosine", "mean"), fallback_rate=("fallback_rate", "mean"))
    mech_summary = summarize(mech, ["setting", "method", "variant"], ["d_spec_before", "d_spec_after", "d_repr", "validation_nll_std", "actual_alpha", "direction_cosine", "fallback_rate"])
    mech_summary.to_csv(OUT / "mechanism_summary.csv", index=False, encoding="utf-8-sig")

    severity = {"iid": 0, "dirichlet_1.0": 1, "dirichlet_0.3": 2, "dirichlet_0.1": 3}
    h1_rows = []
    fedavg_mech = mech[mech.method.eq("fedavg") & mech.setting.isin(severity)]
    for seed, group in fedavg_mech.groupby("seed"):
        x = group.setting.map(severity).to_numpy()
        rho, p = spearmanr(x, group.d_spec_before.to_numpy())
        h1_rows.append({"seed": seed, "spearman_severity_dspec": float(rho), "p_value": float(p)})
    h1 = pd.DataFrame(h1_rows)
    h1.to_csv(OUT / "heterogeneity_gradient_association.csv", index=False, encoding="utf-8-sig")

    lag = lag_correlations(rounds)
    lag.to_csv(OUT / "lag_associations.csv", index=False, encoding="utf-8-sig")

    full = main[main.setting.eq("natural_ship_type") & main.method.eq("gsa")].copy()
    full["variant"] = "gsa"
    ab_all = pd.concat([full, ablation], ignore_index=True, sort=False)
    ab_summary = summarize(ab_all, ["variant"], ["macro_f1", "balanced_accuracy", "nll", "worst_client_macro_f1", "wall_seconds"])
    ab_mech = rounds[rounds.setting.eq("natural_ship_type") & rounds.method.eq("gsa")].groupby(["variant", "seed"], as_index=False).agg(
        d_spec_before=("d_spec_before", "mean"), d_spec_after=("d_spec_after", "mean"), d_repr=("d_repr", "mean"),
        actual_alpha=("actual_alpha", "mean"), direction_cosine=("direction_cosine", "mean"), fallback_rate=("fallback_rate", "mean"))
    ab_mech_summary = summarize(ab_mech, ["variant"], ["d_spec_before", "d_spec_after", "d_repr", "actual_alpha", "direction_cosine", "fallback_rate"])
    ab_summary = ab_summary.merge(ab_mech_summary, on=["variant", "n"], how="outer", suffixes=("", "_mechanism"))
    ab_summary.to_csv(OUT / "ablation_summary.csv", index=False, encoding="utf-8-sig")

    rob_summary = summarize(robustness, ["method", "participation", "missing_rate"], ["macro_f1", "nll", "worst_client_macro_f1", "wall_seconds"])
    rob_summary.to_csv(OUT / "robustness_summary.csv", index=False, encoding="utf-8-sig")

    natural_test = tests_df[tests_df.setting.eq("natural_ship_type")].set_index("metric")
    dspec_pivot = mech[mech.setting.eq("natural_ship_type")].pivot_table(index="seed", columns="method", values="d_spec_after")
    dspec_diff = dspec_pivot["gsa"] - dspec_pivot["fedavg"]
    dspec_ci = bootstrap_ci(dspec_diff)
    drepr_pivot = mech[mech.setting.eq("natural_ship_type")].pivot_table(index="seed", columns="method", values="d_repr")
    drepr_diff = drepr_pivot["gsa"] - drepr_pivot["fedavg"]
    drepr_ci = bootstrap_ci(drepr_diff)
    h1_mean_rho = float(h1.spearman_severity_dspec.mean())
    lag_summary = lag.groupby(["method", "outcome"]).spearman_rho.agg(["mean", "std"]).reset_index()
    fedavg_lag_repr = float(lag_summary[(lag_summary.method == "fedavg") & (lag_summary.outcome == "next_d_repr")]["mean"].iloc[0])
    fedavg_lag_nll = float(lag_summary[(lag_summary.method == "fedavg") & (lag_summary.outcome == "next_nll_change")]["mean"].iloc[0])

    macro_row = natural_test.loc["macro_f1"]
    mia_row = natural_test.loc["mia_auroc"]
    wall_row = natural_test.loc["wall_seconds"]
    h1_status = "有限支持" if h1_mean_rho > 0 else "不支持"
    h2_status = "不支持" if fedavg_lag_nll <= 0 else ("有限支持" if fedavg_lag_repr > 0 else "不支持")
    h3_status = "机制层支持、系统层不支持" if dspec_ci[1] < 0 and macro_row.ci95_low <= 0 <= macro_row.ci95_high else ("支持" if dspec_ci[1] < 0 and macro_row.ci95_low > 0 else "不支持")
    h4_status = "工程代价支持、安全差异不支持" if wall_row.mean_difference > 0 else "不支持"

    verdicts = {
        "H1": {"status": h1_status, "mean_seed_spearman": h1_mean_rho,
               "interpretation": "受控异构严重度与FedAvg平均D_spec的单调关系。"},
        "H2": {"status": h2_status, "fedavg_lag_rho_drepr": fedavg_lag_repr, "fedavg_lag_rho_nll_change": fedavg_lag_nll,
               "interpretation": "时序关联为描述性证据，不构成因果中介。"},
        "H3": {"status": h3_status, "natural_dspec_difference": float(dspec_diff.mean()), "natural_dspec_ci95": list(map(float, dspec_ci)),
               "natural_drepr_difference": float(drepr_diff.mean()), "natural_drepr_ci95": list(map(float, drepr_ci)),
               "natural_macro_f1_difference": float(macro_row.mean_difference), "natural_macro_f1_ci95": [float(macro_row.ci95_low), float(macro_row.ci95_high)],
               "interpretation": "若仅D_spec稳定下降而任务收益不可分辨，应称机制层缓解，不称性能提升。"},
        "H4": {"status": h4_status, "mia_difference": float(mia_row.mean_difference), "mia_ci95": [float(mia_row.ci95_low), float(mia_row.ci95_high)],
               "wall_seconds_difference": float(wall_row.mean_difference), "wall_ci95": [float(wall_row.ci95_low), float(wall_row.ci95_high)],
               "interpretation": "MIA无可分辨差异，但存在明确计算开销。"},
    }
    (OUT / "hypothesis_verdicts.json").write_text(json.dumps(verdicts, ensure_ascii=False, indent=2), encoding="utf-8")

    report = {
        "status": "ANALYZED", "n_core_runs": int(len(main)), "n_ablation_runs": int(len(ablation)), "n_robustness_rows": int(len(robustness)),
        "n_round_rows": int(len(rounds)), "hypotheses": verdicts,
        "warnings": [
            "样本量为1,172艘，五种子精确符号置换检验的最小双侧p值为0.0625；应重视置信区间和效应方向。",
            "Local-only总体macro-F1较高，表明自然船型客户端具有强专属性；不能把联邦共享写成普遍收益。",
            "主任务是排放五分类知识融合，不是事故或险情预测。",
            "成员推断只适用于匹配黑盒攻击，不构成隐私保证。",
        ],
    }
    (OUT / "analysis_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
