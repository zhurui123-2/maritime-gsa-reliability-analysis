import json
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1] / "results" / "gsa_reliability_rebuild_20260803"
OUT = ROOT / "verification_report.json"


def require(condition, message, checks):
    checks.append({"check": message, "passed": bool(condition)})
    if not condition:
        raise AssertionError(message)


def main():
    checks = []
    main_df = pd.read_csv(ROOT / "main_results.csv")
    ablation_df = pd.read_csv(ROOT / "ablation_results.csv")
    robustness_df = pd.read_csv(ROOT / "robustness_results.csv")
    rounds_df = pd.read_csv(ROOT / "round_metrics.csv")
    manifest = json.loads((ROOT / "run_manifest.json").read_text(encoding="utf-8"))

    require(len(main_df) == 70, "核心实验应为70行", checks)
    require(len(ablation_df) == 25, "消融实验应为25行", checks)
    require(len(robustness_df) == 40, "鲁棒性结果应为40行", checks)
    require(len(rounds_df) == 2250, "逐轮记录应为2250行", checks)
    require(manifest.get("status") == "COMPLETED", "运行清单状态应为COMPLETED", checks)

    core_key = ["setting", "method", "seed"]
    require(main_df.duplicated(core_key).sum() == 0, "核心实验键必须唯一", checks)
    require(ablation_df.duplicated(["variant", "seed"]).sum() == 0, "消融实验键必须唯一", checks)
    require(
        robustness_df.duplicated(["method", "seed", "participation", "missing_rate"]).sum() == 0,
        "鲁棒性实验键必须唯一",
        checks,
    )

    required_metrics = ["macro_f1", "balanced_accuracy", "nll", "brier", "worst_client_macro_f1"]
    require(main_df[required_metrics].notna().all().all(), "核心任务指标不得缺失", checks)
    require(ablation_df[required_metrics].notna().all().all(), "消融任务指标不得缺失", checks)
    require(robustness_df[["macro_f1", "nll", "worst_client_macro_f1"]].notna().all().all(), "鲁棒性指标不得缺失", checks)

    checkpoints = list((ROOT / "checkpoints").glob("*.pt"))
    require(len(checkpoints) == 10, "自然船型FedAvg/GSA检查点应为10个", checks)

    analysis_files = [
        "summary_main.csv",
        "paired_method_tests.csv",
        "mechanism_summary.csv",
        "heterogeneity_gradient_association.csv",
        "lag_associations.csv",
        "ablation_summary.csv",
        "robustness_summary.csv",
        "hypothesis_verdicts.json",
        "analysis_report.json",
    ]
    require(all((ROOT / name).exists() for name in analysis_files), "统计分析文件必须齐全", checks)

    report = {
        "status": "VERIFIED",
        "root": str(ROOT),
        "counts": {
            "core_runs": len(main_df),
            "ablation_runs": len(ablation_df),
            "robustness_rows": len(robustness_df),
            "round_rows": len(rounds_df),
            "checkpoints": len(checkpoints),
        },
        "checks": checks,
    }
    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
