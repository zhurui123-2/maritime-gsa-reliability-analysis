# GSA可靠性机制投稿实验重构（2026-08-03）

本目录对应《8.1GSA_航运可靠性机制论文》的新实验设计。它与旧版“跨模态投影器GSA”实验分开保存，避免把两种机制混为一谈。

## 研究边界

- 真实数据为1,172艘完成实体关联的船舶。
- 主任务是多模态知识融合：预测由训练集阈值定义的总CO2排放五分类。
- 所有直接燃料、CO2、CO2eq及其派生字段均从输入中移除。
- 船型客户端只是分布异构代理，不代表真实跨公司部署。
- 不使用未经领域确认的“安全风险代理标签”作为主结果。
- GSA是优化层协调机制，不是可学习潜在空间。

## 交付文件

- `config.json`：冻结的实验参数。
- `run_rebuilt_experiments.py`：训练、机制指标、鲁棒性、消融、MIA和开销实验入口。
- `analyze_results.py`：配对统计、置信区间、效应量、机制链分析。
- `verify_experiment_outputs.py`：核验行数、唯一键、缺失指标、检查点和统计文件。
- `build_experiment_plan_docx.py`：生成实验重构方案Word。
- `build_results_docx.py`：根据真实CSV/JSON输出生成结果Word。

所有结果写入 `E:/航运实验/experiments/results/gsa_reliability_rebuild_20260803`。

## 完成状态

- 运行状态：`COMPLETED`；完整性状态：`VERIFIED`。
- 已完成70个核心运行、25个消融运行、40行鲁棒性结果和2,250行逐轮记录。
- 正式结论：GSA稳定降低梯度谱差异，但当前实验未验证下游可靠性或任务收益。
- 两份Word位于 `E:/航运实验/投稿实验重构_20260803`。

## 可靠性逐步修订实验

- `run_reliability_v2.py`：协调前后测量、陈旧更新冲击—恢复、可靠性门控和剂量实验。
- `analyze_reliability_v2.py`：清洁反事实配对、剂量效应、bootstrap区间和结论边界。
- 新结果目录：`E:/航运实验/experiments/results/gsa_reliability_v2_20260803`。
- 当前结果：陈旧度与NLL退化存在剂量关系；原GSA在中重度条件下呈小幅缓解；门控版未优于原GSA。
