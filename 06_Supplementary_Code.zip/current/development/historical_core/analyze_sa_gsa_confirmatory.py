from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / "experiments" / "results" / "sa_gsa_confirmatory_20260804"
STRESS_SCENARIOS = ["stale_mild", "stale_moderate", "stale_severe"]
PRIMARY_SCENARIOS = ["stale_moderate", "stale_severe"]


def stable_seed(label: str) -> int:
    return int(hashlib.sha256(label.encode("utf-8")).hexdigest()[:8], 16)


def bootstrap_ci(values: np.ndarray, label: str, reps: int = 20000) -> tuple[float, float]:
    rng = np.random.default_rng(stable_seed(label))
    draws = rng.choice(values, size=(reps, len(values)), replace=True).mean(axis=1)
    return float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def exact_sign_flip_p(values: np.ndarray) -> float:
    observed = abs(float(np.mean(values)))
    signs = np.asarray(list(itertools.product([-1.0, 1.0], repeat=len(values))))
    permuted = np.abs((signs * values[None, :]).mean(axis=1))
    return float(np.mean(permuted >= observed - 1e-15))


def holm(p_values: dict[str, float]) -> dict[str, float]:
    ordered = sorted(p_values.items(), key=lambda item: item[1])
    adjusted = {}
    running = 0.0
    total = len(ordered)
    for rank, (name, value) in enumerate(ordered):
        running = max(running, min(1.0, (total - rank) * value))
        adjusted[name] = running
    return adjusted


def reference_method(method: str) -> str:
    if method in {"fedavg", "staleness_decay"}:
        return "fedavg"
    if method == "fedprox":
        return "fedprox"
    return "gsa"


def per_seed_summary(rounds: pd.DataFrame, results: pd.DataFrame) -> pd.DataFrame:
    clean = rounds[rounds.scenario == "clean"]
    rows: list[dict[str, Any]] = []
    for (scenario, method, seed), group in rounds[rounds.scenario != "clean"].groupby(
        ["scenario", "method", "seed"]
    ):
        ref = clean[(clean.method == reference_method(method)) & (clean.seed == seed)]
        merged = group.merge(
            ref[
                [
                    "round",
                    "validation_nll",
                    "validation_brier",
                    "validation_ece",
                    "validation_macro_f1",
                    "d_repr_post",
                    "d_pred_post",
                ]
            ],
            on="round",
            suffixes=("_stress", "_clean"),
            validate="one_to_one",
        )
        for metric in ["nll", "brier", "ece"]:
            merged[f"excess_{metric}"] = (
                merged[f"validation_{metric}_stress"] - merged[f"validation_{metric}_clean"]
            )
        merged["macro_f1_delta"] = merged.validation_macro_f1_stress - merged.validation_macro_f1_clean
        merged["excess_d_repr"] = merged.d_repr_post_stress - merged.d_repr_post_clean
        merged["excess_d_pred"] = merged.d_pred_post_stress - merged.d_pred_post_clean
        stress = merged[merged.phase == "stress"]
        recovery = merged[merged.phase == "recovery"]
        task = results[
            (results.scenario == scenario) & (results.method == method) & (results.seed == seed)
        ].iloc[0]
        rows.append(
            {
                "scenario": scenario,
                "method": method,
                "seed": int(seed),
                "stress_excess_nll_auc": stress.excess_nll.sum(),
                "stress_peak_excess_nll": stress.excess_nll.max(),
                "recovery_excess_nll_auc": recovery.excess_nll.sum(),
                "stress_excess_brier_auc": stress.excess_brier.sum(),
                "stress_excess_ece_auc": stress.excess_ece.sum(),
                "stress_macro_f1_delta_auc": stress.macro_f1_delta.sum(),
                "stress_d_spec_before": stress.d_spec_before.mean(),
                "stress_d_spec_after": stress.d_spec_after.mean(),
                "stress_excess_d_repr": stress.excess_d_repr.mean(),
                "stress_excess_d_pred": stress.excess_d_pred.mean(),
                "test_macro_f1": task.macro_f1,
                "test_nll": task.nll,
                "worst_client_macro_f1": task.worst_client_macro_f1,
                "wall_seconds": task.wall_seconds,
            }
        )
    return pd.DataFrame(rows)


def paired_effects(per_seed: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "stress_excess_nll_auc",
        "stress_peak_excess_nll",
        "recovery_excess_nll_auc",
        "stress_excess_brier_auc",
        "stress_excess_ece_auc",
        "stress_macro_f1_delta_auc",
        "stress_d_spec_after",
        "stress_excess_d_repr",
        "stress_excess_d_pred",
        "test_macro_f1",
        "test_nll",
        "worst_client_macro_f1",
        "wall_seconds",
    ]
    rows = []
    for scenario in STRESS_SCENARIOS:
        subset = per_seed[per_seed.scenario == scenario]
        sa = subset[subset.method == "sa_gsa"].set_index("seed")
        for comparator in ["fedavg", "fedprox", "gsa", "staleness_decay"]:
            baseline = subset[subset.method == comparator].set_index("seed")
            common = sa.index.intersection(baseline.index)
            for metric in metrics:
                difference = (sa.loc[common, metric] - baseline.loc[common, metric]).to_numpy(float)
                low, high = bootstrap_ci(difference, f"{scenario}:{comparator}:{metric}")
                rows.append(
                    {
                        "scenario": scenario,
                        "comparator": comparator,
                        "metric": metric,
                        "comparator_mean": baseline.loc[common, metric].mean(),
                        "sa_gsa_mean": sa.loc[common, metric].mean(),
                        "sa_gsa_minus_comparator_mean": difference.mean(),
                        "ci95_low": low,
                        "ci95_high": high,
                        "exact_sign_flip_p": exact_sign_flip_p(difference),
                        "sa_gsa_better_seeds": int(np.sum(difference < 0)) if "f1" not in metric else int(np.sum(difference > 0)),
                        "n_pairs": len(difference),
                    }
                )
    return pd.DataFrame(rows)


def clean_noninferiority(rounds: pd.DataFrame, results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for seed in sorted(rounds.seed.unique()):
        fed = rounds[(rounds.scenario == "clean") & (rounds.method == "fedavg") & (rounds.seed == seed)].tail(10)
        gsa = rounds[(rounds.scenario == "clean") & (rounds.method == "gsa") & (rounds.seed == seed)].tail(10)
        fed_test = results[(results.scenario == "clean") & (results.method == "fedavg") & (results.seed == seed)].iloc[0]
        gsa_test = results[(results.scenario == "clean") & (results.method == "gsa") & (results.seed == seed)].iloc[0]
        rows.append(
            {
                "seed": int(seed),
                "validation_nll_last10_diff": gsa.validation_nll.mean() - fed.validation_nll.mean(),
                "test_nll_diff": gsa_test.nll - fed_test.nll,
                "test_macro_f1_diff": gsa_test.macro_f1 - fed_test.macro_f1,
            }
        )
    per_seed = pd.DataFrame(rows)
    summary_rows = []
    for metric, boundary, margin in [
        ("validation_nll_last10_diff", "upper", 0.01),
        ("test_nll_diff", "upper", 0.01),
        ("test_macro_f1_diff", "lower", -0.01),
    ]:
        values = per_seed[metric].to_numpy(float)
        low, high = bootstrap_ci(values, f"clean:{metric}")
        passed = high <= margin if boundary == "upper" else low >= margin
        summary_rows.append(
            {
                "metric": metric,
                "mean_difference": values.mean(),
                "ci95_low": low,
                "ci95_high": high,
                "boundary": boundary,
                "margin": margin,
                "passed": bool(passed),
            }
        )
    return per_seed, pd.DataFrame(summary_rows)


def main() -> int:
    rounds = pd.read_csv(OUT / "sa_gsa_round_metrics.csv")
    results = pd.read_csv(OUT / "sa_gsa_test_results.csv")
    if rounds[["scenario", "method", "seed", "round"]].duplicated().any():
        raise RuntimeError("duplicate round rows")
    if not (rounds.groupby(["scenario", "method", "seed"]).size() == 30).all():
        raise RuntimeError("incomplete run")
    if rounds[["validation_nll", "validation_brier", "validation_ece"]].isna().any().any():
        raise RuntimeError("missing primary outcome")

    per_seed = per_seed_summary(rounds, results)
    effects = paired_effects(per_seed)
    clean_seed, clean_summary = clean_noninferiority(rounds, results)
    primary = effects[
        (effects.scenario.isin(PRIMARY_SCENARIOS))
        & (effects.comparator == "staleness_decay")
        & (effects.metric == "stress_excess_nll_auc")
    ].copy()
    adjusted = holm(dict(zip(primary.scenario, primary.exact_sign_flip_p)))
    primary["holm_p"] = primary.scenario.map(adjusted)
    primary["relative_damage_reduction"] = (
        -primary.sa_gsa_minus_comparator_mean / primary.comparator_mean
    )
    primary["confirmed"] = (
        (primary.sa_gsa_minus_comparator_mean < 0)
        & (primary.ci95_high < 0)
        & (primary.holm_p < 0.05)
    )
    clean_pass = bool(clean_summary.passed.all())
    strong = bool(primary.confirmed.all() and clean_pass)
    dose = (
        per_seed[per_seed.method.isin(["fedavg", "staleness_decay", "sa_gsa"])]
        .groupby(["scenario", "method"], as_index=False)
        .agg(
            stress_excess_nll_auc_mean=("stress_excess_nll_auc", "mean"),
            recovery_excess_nll_auc_mean=("recovery_excess_nll_auc", "mean"),
            stress_d_spec_after_mean=("stress_d_spec_after", "mean"),
        )
    )
    recommendation = (
        "最终确认通过。论文可把SA-GSA表述为面向陈旧更新退化的梯度谱协调与陈旧度衰减组合机制。"
        "结论必须限定在已测试的陈旧度范围。"
        if strong
        else "最终确认未通过预设规则。SA-GSA只能作为探索性结果，不得写成已确认的可靠性增强机制。"
    )
    decision = {
        "primary_confirmed": int(primary.confirmed.sum()),
        "primary_total": len(primary),
        "clean_noninferiority_passed": clean_pass,
        "strong_staleness_reliability_supported": strong,
        "recommendation": recommendation,
    }
    per_seed.to_csv(OUT / "sa_gsa_per_seed.csv", index=False, encoding="utf-8-sig")
    effects.to_csv(OUT / "sa_gsa_paired_effects.csv", index=False, encoding="utf-8-sig")
    primary.to_csv(OUT / "sa_gsa_primary_outcomes.csv", index=False, encoding="utf-8-sig")
    clean_seed.to_csv(OUT / "sa_gsa_clean_per_seed.csv", index=False, encoding="utf-8-sig")
    clean_summary.to_csv(OUT / "sa_gsa_clean_noninferiority.csv", index=False, encoding="utf-8-sig")
    dose.to_csv(OUT / "sa_gsa_dose_summary.csv", index=False, encoding="utf-8-sig")
    (OUT / "sa_gsa_decision.json").write_text(
        json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(decision, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
