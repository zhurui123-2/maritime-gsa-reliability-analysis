from __future__ import annotations

import argparse
import copy
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.model_selection import StratifiedShuffleSplit


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run_rebuilt_experiments as base  # noqa: E402


OUT = Path(r"E:\航运实验\experiments\results\gsa_reliability_v2_20260803")


def prediction_disagreement(probabilities: list[np.ndarray]) -> float:
    """Mean pairwise JSD on the same anchor samples; logarithm base 2."""
    values: list[float] = []
    eps = 1e-12
    for i in range(len(probabilities)):
        a = np.clip(probabilities[i], eps, 1.0)
        for j in range(i + 1, len(probabilities)):
            b = np.clip(probabilities[j], eps, 1.0)
            m = 0.5 * (a + b)
            js = 0.5 * np.sum(a * np.log2(a / m), axis=1) + 0.5 * np.sum(b * np.log2(b / m), axis=1)
            values.append(float(np.mean(js)))
    return float(np.mean(values)) if values else float("nan")


def models_from_updates(
    global_model: base.MultiModalNet,
    updates: list[dict[str, torch.Tensor]],
) -> list[base.MultiModalNet]:
    models: list[base.MultiModalNet] = []
    for update in updates:
        model = copy.deepcopy(global_model)
        state = model.state_dict()
        for key, value in state.items():
            if key in update and torch.is_floating_point(value):
                state[key] = value + update[key].to(value.device)
        model.load_state_dict(state, strict=True)
        models.append(model)
    return models


def measure_client_models(
    models: list[base.MultiModalNet],
    prepared: base.Prepared,
    indices: np.ndarray,
    device: torch.device,
    cfg: dict[str, Any],
    seed: int,
) -> tuple[float, float]:
    outputs = [
        base.evaluate_model(
            model,
            prepared,
            indices,
            device,
            int(cfg["batch_size"]),
            seed=seed,
            return_repr=True,
        )
        for model in models
    ]
    d_repr = base.pairwise_representation_distance([x["representation"] for x in outputs])
    d_pred = prediction_disagreement([x["prob"] for x in outputs])
    return d_repr, d_pred


def aggregate_trainable_diagnostics(
    model: base.MultiModalNet,
    original: list[dict[str, torch.Tensor]],
    corrected: list[dict[str, torch.Tensor]],
    counts: list[int],
) -> tuple[float, float]:
    weights = np.asarray(counts, dtype=float)
    weights /= weights.sum()
    names = [name for name, _ in model.named_parameters()]

    def aggregate(updates: list[dict[str, torch.Tensor]]) -> torch.Tensor:
        chunks = []
        for name in names:
            chunk = sum(float(w) * update[name].detach().cpu().reshape(-1) for w, update in zip(weights, updates))
            chunks.append(chunk)
        return torch.cat(chunks)

    before = aggregate(original)
    after = aggregate(corrected)
    relative = float(torch.linalg.norm(after - before) / torch.linalg.norm(before).clamp_min(1e-12))
    cosine = float(F.cosine_similarity(before, after, dim=0))
    return relative, cosine


def aggregate_model_copy(
    model: base.MultiModalNet,
    updates: list[dict[str, torch.Tensor]],
    counts: list[int],
) -> base.MultiModalNet:
    candidate = copy.deepcopy(model)
    base.aggregate_updates(candidate, updates, counts, "fedavg")
    return candidate


def split_anchor_for_gate(prepared: base.Prepared, seed: int) -> tuple[np.ndarray, np.ndarray]:
    anchor = prepared.anchor_idx
    strata = prepared.nodes[anchor]
    splitter = StratifiedShuffleSplit(n_splits=1, test_size=0.5, random_state=seed + 70000)
    gate_rel, audit_rel = next(splitter.split(np.zeros(len(anchor)), strata))
    return anchor[gate_rel], anchor[audit_rel]


def run_measurement_fix(
    prepared: base.Prepared,
    method: str,
    seed: int,
    cfg: dict[str, Any],
    device: torch.device,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    base.seed_all(seed)
    train_parts = base.natural_partition(prepared.train_idx, prepared.nodes)
    test_parts = base.natural_partition(prepared.test_idx, prepared.nodes)
    model = base.MultiModalNet(
        prepared.dims,
        int(cfg["hidden_dim"]),
        int(cfg["embedding_dim"]),
        float(cfg["dropout"]),
    ).to(device)
    coordinator = base.GSACoordinator(cfg["gsa"], "gsa") if method == "gsa" else None
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()

    for round_idx in range(1, int(cfg["rounds"]) + 1):
        global_parameters = {name: p.detach().clone() for name, p in model.named_parameters()}
        local_models: list[base.MultiModalNet] = []
        counts: list[int] = []
        for client_idx, indices in enumerate(train_parts):
            local, count, _, _ = base.local_train(
                model,
                prepared,
                indices,
                device,
                cfg,
                method,
                seed + round_idx * 100 + client_idx,
                global_parameters,
            )
            local_models.append(local)
            counts.append(count)

        updates = base.state_updates(model, local_models)
        blocks = model.registered_blocks()
        d_repr_pre, d_pred_pre = measure_client_models(
            local_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
        )

        if coordinator is None:
            corrected = updates
            d_before, _ = base.d_spec(
                updates, blocks, int(cfg["gsa"]["descriptor_bins"]), int(cfg["gsa"]["rank_cap"])
            )
            diagnostics = {
                "d_spec_before": d_before,
                "d_spec_after": d_before,
                "actual_alpha": 0.0,
                "direction_cosine": 1.0,
            }
            post_models = local_models
        else:
            corrected, diagnostics = coordinator.coordinate(updates, blocks)
            post_models = models_from_updates(model, corrected)

        d_repr_post, d_pred_post = measure_client_models(
            post_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
        )
        update_relative_change, update_cosine = aggregate_trainable_diagnostics(
            model, updates, corrected, counts
        )
        base.aggregate_updates(model, corrected, counts, "fedavg")
        validation = base.evaluate_model(
            model,
            prepared,
            prepared.anchor_idx,
            device,
            int(cfg["batch_size"]),
            seed=seed + round_idx,
        )
        rows.append(
            {
                "stage": "measurement_fix",
                "method": method,
                "seed": seed,
                "round": round_idx,
                "d_spec_before": diagnostics["d_spec_before"],
                "d_spec_after": diagnostics["d_spec_after"],
                "d_repr_pre": d_repr_pre,
                "d_repr_post": d_repr_post,
                "d_pred_pre": d_pred_pre,
                "d_pred_post": d_pred_post,
                "validation_nll": validation["nll"],
                "validation_macro_f1": validation["macro_f1"],
                "actual_alpha": diagnostics["actual_alpha"],
                "direction_cosine": diagnostics["direction_cosine"],
                "aggregate_trainable_relative_change": update_relative_change,
                "aggregate_trainable_cosine": update_cosine,
            }
        )

    test_metrics, client_f1 = base.evaluate_per_clients(
        model, prepared, test_parts, device, cfg, None, 0.0, seed
    )
    result = {
        "stage": "measurement_fix",
        "method": method,
        "seed": seed,
        **test_metrics,
        "client_macro_f1": json.dumps(client_f1),
        "wall_seconds": time.perf_counter() - started,
    }
    return pd.DataFrame(rows), result


def local_train_with_optimization_profile(
    global_model: base.MultiModalNet,
    prepared: base.Prepared,
    indices: np.ndarray,
    device: torch.device,
    cfg: dict[str, Any],
    seed: int,
    local_epochs: int,
    learning_rate_multiplier: float,
) -> tuple[base.MultiModalNet, int, int]:
    model = copy.deepcopy(global_model).to(device)
    model.train()
    optimizer = torch.optim.SGD(
        model.parameters(),
        lr=float(cfg["learning_rate"]) * learning_rate_multiplier,
        weight_decay=float(cfg["weight_decay"]),
    )
    steps = 0
    for epoch in range(local_epochs):
        loader = base.make_loader(
            prepared,
            indices,
            int(cfg["batch_size"]),
            True,
            seed + epoch,
        )
        for batch in loader:
            x, y, _ = base.batch_to_device(batch, device)
            optimizer.zero_grad(set_to_none=True)
            logits, _ = model(x, torch.ones(len(y), len(model.modalities), device=device))
            F.cross_entropy(logits, y).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            steps += 1
    return model, len(indices), steps


def staleness_profile(round_idx: int, client_idx: int, severity: str = "moderate") -> tuple[int, str]:
    if 11 <= round_idx <= 20:
        profiles = {
            "mild": [0, 0, 1, 1, 2],
            "moderate": [0, 1, 2, 3, 4],
            "severe": [0, 2, 4, 6, 8],
        }
        delay_profile = profiles[severity]
        return delay_profile[client_idx], "stress"
    phase = "clean" if round_idx <= 10 else "recovery"
    return 0, phase


def run_staleness_stress(
    prepared: base.Prepared,
    method: str,
    seed: int,
    cfg: dict[str, Any],
    device: torch.device,
    severity: str = "moderate",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    base.seed_all(seed)
    train_parts = base.natural_partition(prepared.train_idx, prepared.nodes)
    test_parts = base.natural_partition(prepared.test_idx, prepared.nodes)
    model = base.MultiModalNet(
        prepared.dims,
        int(cfg["hidden_dim"]),
        int(cfg["embedding_dim"]),
        float(cfg["dropout"]),
    ).to(device)
    coordinator = base.GSACoordinator(cfg["gsa"], "gsa") if method == "gsa" else None
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()
    model_history = [base.clone_state(model)]

    for round_idx in range(1, int(cfg["rounds"]) + 1):
        local_models: list[base.MultiModalNet] = []
        counts: list[int] = []
        staleness_delays: list[int] = []
        phase = "clean"
        for client_idx, indices in enumerate(train_parts):
            delay, phase = staleness_profile(round_idx, client_idx, severity)
            history_index = max(0, len(model_history) - 1 - delay)
            starting_model = copy.deepcopy(model)
            starting_model.load_state_dict(model_history[history_index], strict=True)
            local, count, _ = local_train_with_optimization_profile(
                starting_model,
                prepared,
                indices,
                device,
                cfg,
                seed + round_idx * 100 + client_idx,
                1,
                1.0,
            )
            local_models.append(local)
            counts.append(count)
            staleness_delays.append(delay)

        updates = base.state_updates(model, local_models)
        blocks = model.registered_blocks()
        d_repr_pre, d_pred_pre = measure_client_models(
            local_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
        )
        if coordinator is None:
            corrected = updates
            d_before, _ = base.d_spec(
                updates, blocks, int(cfg["gsa"]["descriptor_bins"]), int(cfg["gsa"]["rank_cap"])
            )
            diagnostics = {
                "d_spec_before": d_before,
                "d_spec_after": d_before,
                "actual_alpha": 0.0,
                "direction_cosine": 1.0,
            }
            post_models = local_models
        else:
            corrected, diagnostics = coordinator.coordinate(updates, blocks)
            post_models = models_from_updates(model, corrected)
        d_repr_post, d_pred_post = measure_client_models(
            post_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
        )
        update_relative_change, update_cosine = aggregate_trainable_diagnostics(
            model, updates, corrected, counts
        )
        base.aggregate_updates(model, corrected, counts, "fedavg")
        model_history.append(base.clone_state(model))
        validation = base.evaluate_model(
            model,
            prepared,
            prepared.anchor_idx,
            device,
            int(cfg["batch_size"]),
            seed=seed + round_idx,
        )
        rows.append(
            {
                "stage": "staleness_stress",
                "scenario": severity,
                "method": method,
                "seed": seed,
                "round": round_idx,
                "phase": phase,
                "staleness_delay_profile": json.dumps(staleness_delays),
                "d_spec_before": diagnostics["d_spec_before"],
                "d_spec_after": diagnostics["d_spec_after"],
                "d_repr_pre": d_repr_pre,
                "d_repr_post": d_repr_post,
                "d_pred_pre": d_pred_pre,
                "d_pred_post": d_pred_post,
                "validation_nll": validation["nll"],
                "validation_macro_f1": validation["macro_f1"],
                "actual_alpha": diagnostics["actual_alpha"],
                "direction_cosine": diagnostics["direction_cosine"],
                "aggregate_trainable_relative_change": update_relative_change,
                "aggregate_trainable_cosine": update_cosine,
            }
        )

    test_metrics, client_f1 = base.evaluate_per_clients(
        model, prepared, test_parts, device, cfg, None, 0.0, seed
    )
    result = {
        "stage": "staleness_stress",
        "scenario": severity,
        "method": method,
        "seed": seed,
        **test_metrics,
        "client_macro_f1": json.dumps(client_f1),
        "wall_seconds": time.perf_counter() - started,
    }
    return pd.DataFrame(rows), result


def recovery_round(group: pd.DataFrame, baseline_mean: float, baseline_std: float) -> float:
    threshold = baseline_mean + baseline_std
    recovery = group[group["phase"] == "recovery"].sort_values("round")
    values = recovery.validation_nll.to_numpy()
    rounds = recovery["round"].to_numpy()
    for idx in range(max(0, len(values) - 2)):
        if np.all(values[idx : idx + 3] <= threshold):
            return float(rounds[idx] - 20)
    return float("nan")


def summarize_stage2(rounds: pd.DataFrame, results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[dict[str, Any]] = []
    for (method, seed), group in rounds.groupby(["method", "seed"]):
        group = group.sort_values("round")
        clean = group[(group["phase"] == "clean") & (group["round"] >= 6)]
        stress = group[group["phase"] == "stress"]
        recovery = group[group["phase"] == "recovery"]
        baseline_mean = clean.validation_nll.mean()
        baseline_std = clean.validation_nll.std(ddof=1)
        task = results[(results.method == method) & (results.seed == seed)].iloc[0]
        rows.append(
            {
                "method": method,
                "seed": int(seed),
                "clean_nll_mean": baseline_mean,
                "stress_nll_mean": stress.validation_nll.mean(),
                "stress_excess_nll_auc": float((stress.validation_nll - baseline_mean).sum()),
                "stress_peak_excess_nll": float((stress.validation_nll - baseline_mean).max()),
                "stress_nll_std": stress.validation_nll.std(ddof=1),
                "recovery_nll_std": recovery.validation_nll.std(ddof=1),
                "recovery_rounds": recovery_round(group, baseline_mean, baseline_std),
                "stress_d_spec_after": stress.d_spec_after.mean(),
                "stress_d_repr_post": stress.d_repr_post.mean(),
                "stress_d_pred_post": stress.d_pred_post.mean(),
                "stress_d_pred_immediate_change": (stress.d_pred_post - stress.d_pred_pre).mean(),
                "test_macro_f1": task.macro_f1,
                "test_nll": task.nll,
                "worst_client_macro_f1": task.worst_client_macro_f1,
            }
        )
    per_seed = pd.DataFrame(rows)
    fedavg = per_seed[per_seed.method == "fedavg"].set_index("seed")
    gsa = per_seed[per_seed.method == "gsa"].set_index("seed")
    paired = []
    for metric in [
        "stress_excess_nll_auc",
        "stress_peak_excess_nll",
        "stress_nll_std",
        "recovery_nll_std",
        "stress_d_spec_after",
        "stress_d_repr_post",
        "stress_d_pred_post",
        "test_macro_f1",
        "test_nll",
        "worst_client_macro_f1",
    ]:
        diff = gsa[metric] - fedavg[metric]
        paired.append(
            {
                "metric": metric,
                "fedavg_mean": fedavg[metric].mean(),
                "gsa_mean": gsa[metric].mean(),
                "gsa_minus_fedavg_mean": diff.mean(),
                "gsa_minus_fedavg_std": diff.std(ddof=1),
                "n_pairs": len(diff),
            }
        )
    return per_seed, pd.DataFrame(paired)


def gated_coordinate(
    coordinator: base.GSACoordinator,
    model: base.MultiModalNet,
    updates: list[dict[str, torch.Tensor]],
    counts: list[int],
    prepared: base.Prepared,
    gate_idx: np.ndarray,
    device: torch.device,
    cfg: dict[str, Any],
    seed: int,
) -> tuple[list[dict[str, torch.Tensor]], dict[str, float], dict[str, float]]:
    original_models = models_from_updates(model, updates)
    _, pre_d_pred = measure_client_models(original_models, prepared, gate_idx, device, cfg, seed)
    fedavg_candidate = aggregate_model_copy(model, updates, counts)
    fedavg_gate_nll = base.evaluate_model(
        fedavg_candidate, prepared, gate_idx, device, int(cfg["batch_size"]), seed=seed
    )["nll"]
    alpha_grid = [0.35, 0.175, 0.0875, 0.04375, 0.021875]
    epsilon_nll = 0.001
    last_candidate_coord: base.GSACoordinator | None = None
    last_diagnostics: dict[str, float] | None = None
    for attempted_alpha in alpha_grid:
        candidate_coord = copy.deepcopy(coordinator)
        candidate_coord.cfg = copy.deepcopy(coordinator.cfg)
        candidate_coord.cfg["alpha"] = attempted_alpha
        corrected, diagnostics = candidate_coord.coordinate(updates, model.registered_blocks())
        candidate_models = models_from_updates(model, corrected)
        _, candidate_d_pred = measure_client_models(
            candidate_models, prepared, gate_idx, device, cfg, seed
        )
        candidate_global = aggregate_model_copy(model, corrected, counts)
        candidate_nll = base.evaluate_model(
            candidate_global, prepared, gate_idx, device, int(cfg["batch_size"]), seed=seed
        )["nll"]
        last_candidate_coord = candidate_coord
        last_diagnostics = diagnostics
        if candidate_d_pred <= pre_d_pred and candidate_nll <= fedavg_gate_nll + epsilon_nll:
            coordinator.ema = copy.deepcopy(candidate_coord.ema)
            return corrected, diagnostics, {
                "gate_accepted": 1.0,
                "gate_attempted_alpha": attempted_alpha,
                "gate_d_pred_pre": pre_d_pred,
                "gate_d_pred_post": candidate_d_pred,
                "gate_fedavg_nll": fedavg_gate_nll,
                "gate_candidate_nll": candidate_nll,
            }
    assert last_candidate_coord is not None and last_diagnostics is not None
    coordinator.ema = copy.deepcopy(last_candidate_coord.ema)
    d_before, _ = base.d_spec(
        updates,
        model.registered_blocks(),
        int(cfg["gsa"]["descriptor_bins"]),
        int(cfg["gsa"]["rank_cap"]),
    )
    return updates, {
        "d_spec_before": d_before,
        "d_spec_after": d_before,
        "actual_alpha": 0.0,
        "direction_cosine": 1.0,
    }, {
        "gate_accepted": 0.0,
        "gate_attempted_alpha": 0.0,
        "gate_d_pred_pre": pre_d_pred,
        "gate_d_pred_post": pre_d_pred,
        "gate_fedavg_nll": fedavg_gate_nll,
        "gate_candidate_nll": fedavg_gate_nll,
    }


def run_gated_reliability(
    prepared: base.Prepared,
    scenario: str,
    seed: int,
    cfg: dict[str, Any],
    device: torch.device,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    base.seed_all(seed)
    train_parts = base.natural_partition(prepared.train_idx, prepared.nodes)
    test_parts = base.natural_partition(prepared.test_idx, prepared.nodes)
    gate_idx, audit_idx = split_anchor_for_gate(prepared, seed)
    model = base.MultiModalNet(
        prepared.dims,
        int(cfg["hidden_dim"]),
        int(cfg["embedding_dim"]),
        float(cfg["dropout"]),
    ).to(device)
    coordinator = base.GSACoordinator(cfg["gsa"], "gsa")
    model_history = [base.clone_state(model)]
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()
    for round_idx in range(1, int(cfg["rounds"]) + 1):
        local_models: list[base.MultiModalNet] = []
        counts: list[int] = []
        delays: list[int] = []
        if scenario == "staleness":
            phase = "stress" if 11 <= round_idx <= 20 else ("clean" if round_idx <= 10 else "recovery")
        else:
            phase = "clean"
        for client_idx, indices in enumerate(train_parts):
            delay = [0, 1, 2, 3, 4][client_idx] if phase == "stress" else 0
            history_index = max(0, len(model_history) - 1 - delay)
            starting_model = copy.deepcopy(model)
            starting_model.load_state_dict(model_history[history_index], strict=True)
            local, count, _ = local_train_with_optimization_profile(
                starting_model,
                prepared,
                indices,
                device,
                cfg,
                seed + round_idx * 100 + client_idx,
                1,
                1.0,
            )
            local_models.append(local)
            counts.append(count)
            delays.append(delay)
        updates = base.state_updates(model, local_models)
        d_repr_pre, d_pred_pre = measure_client_models(
            local_models, prepared, audit_idx, device, cfg, seed + round_idx
        )
        corrected, diagnostics, gate = gated_coordinate(
            coordinator,
            model,
            updates,
            counts,
            prepared,
            gate_idx,
            device,
            cfg,
            seed + round_idx,
        )
        post_models = models_from_updates(model, corrected)
        d_repr_post, d_pred_post = measure_client_models(
            post_models, prepared, audit_idx, device, cfg, seed + round_idx
        )
        update_relative_change, update_cosine = aggregate_trainable_diagnostics(
            model, updates, corrected, counts
        )
        base.aggregate_updates(model, corrected, counts, "fedavg")
        model_history.append(base.clone_state(model))
        audit = base.evaluate_model(
            model, prepared, audit_idx, device, int(cfg["batch_size"]), seed=seed + round_idx
        )
        rows.append(
            {
                "stage": "reliability_gate",
                "scenario": scenario,
                "method": "gsa_gate",
                "seed": seed,
                "round": round_idx,
                "phase": phase,
                "staleness_delay_profile": json.dumps(delays),
                "n_gate": len(gate_idx),
                "n_audit": len(audit_idx),
                "d_spec_before": diagnostics["d_spec_before"],
                "d_spec_after": diagnostics["d_spec_after"],
                "d_repr_pre": d_repr_pre,
                "d_repr_post": d_repr_post,
                "d_pred_pre": d_pred_pre,
                "d_pred_post": d_pred_post,
                "validation_nll": audit["nll"],
                "validation_macro_f1": audit["macro_f1"],
                "actual_alpha": diagnostics["actual_alpha"],
                "direction_cosine": diagnostics["direction_cosine"],
                "aggregate_trainable_relative_change": update_relative_change,
                "aggregate_trainable_cosine": update_cosine,
                **gate,
            }
        )
    test_metrics, client_f1 = base.evaluate_per_clients(
        model, prepared, test_parts, device, cfg, None, 0.0, seed
    )
    result = {
        "stage": "reliability_gate",
        "scenario": scenario,
        "method": "gsa_gate",
        "seed": seed,
        **test_metrics,
        "client_macro_f1": json.dumps(client_f1),
        "wall_seconds": time.perf_counter() - started,
    }
    return pd.DataFrame(rows), result


def summarize_stage3(rounds: pd.DataFrame, results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    clean = rounds[rounds.scenario == "clean"]
    stress = rounds[rounds.scenario == "staleness"]
    merged = stress.merge(
        clean[["seed", "round", "validation_nll", "d_repr_post", "d_pred_post"]],
        on=["seed", "round"],
        suffixes=("_stress", "_clean"),
    )
    merged["excess_nll"] = merged.validation_nll_stress - merged.validation_nll_clean
    merged["excess_d_repr"] = merged.d_repr_post_stress - merged.d_repr_post_clean
    merged["excess_d_pred"] = merged.d_pred_post_stress - merged.d_pred_post_clean
    rows: list[dict[str, Any]] = []
    for seed, group in merged.groupby("seed"):
        stress_window = group[group.phase == "stress"]
        recovery_window = group[group.phase == "recovery"]
        clean_result = results[(results.seed == seed) & (results.scenario == "clean")].iloc[0]
        stress_result = results[(results.seed == seed) & (results.scenario == "staleness")].iloc[0]
        gate_rows = rounds[(rounds.seed == seed) & (rounds.scenario == "staleness")]
        rows.append(
            {
                "method": "gsa_gate",
                "seed": int(seed),
                "stress_excess_nll_auc": stress_window.excess_nll.sum(),
                "stress_peak_excess_nll": stress_window.excess_nll.max(),
                "stress_excess_d_repr": stress_window.excess_d_repr.mean(),
                "stress_excess_d_pred": stress_window.excess_d_pred.mean(),
                "recovery_excess_nll_auc": recovery_window.excess_nll.sum(),
                "gate_acceptance_rate": gate_rows.gate_accepted.mean(),
                "gate_mean_alpha": gate_rows.actual_alpha.mean(),
                "clean_test_macro_f1": clean_result.macro_f1,
                "stress_test_macro_f1": stress_result.macro_f1,
                "stress_test_nll": stress_result.nll,
                "stress_worst_client_macro_f1": stress_result.worst_client_macro_f1,
            }
        )
    per_seed = pd.DataFrame(rows)
    summary = per_seed.drop(columns=["seed", "method"]).agg(["mean", "std"]).T.reset_index()
    summary.columns = ["metric", "mean", "std"]
    return per_seed, summary


def summarize_stage4(rounds: pd.DataFrame, results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    clean = pd.read_csv(OUT / "stage1_round_metrics.csv")
    rows: list[dict[str, Any]] = []
    for (scenario, method, seed), group in rounds.groupby(["scenario", "method", "seed"]):
        reference = clean[(clean.method == method) & (clean.seed == seed)]
        merged = group.merge(
            reference[["round", "validation_nll", "d_repr_post", "d_pred_post"]],
            on="round",
            suffixes=("_stress", "_clean"),
        )
        merged["excess_nll"] = merged.validation_nll_stress - merged.validation_nll_clean
        merged["excess_d_repr"] = merged.d_repr_post_stress - merged.d_repr_post_clean
        merged["excess_d_pred"] = merged.d_pred_post_stress - merged.d_pred_post_clean
        stress_window = merged[merged.phase == "stress"]
        recovery_window = merged[merged.phase == "recovery"]
        task = results[
            (results.scenario == scenario) & (results.method == method) & (results.seed == seed)
        ].iloc[0]
        rows.append(
            {
                "scenario": scenario,
                "method": method,
                "seed": int(seed),
                "stress_d_spec_before": stress_window.d_spec_before.mean(),
                "stress_d_spec_after": stress_window.d_spec_after.mean(),
                "stress_excess_nll_auc": stress_window.excess_nll.sum(),
                "stress_peak_excess_nll": stress_window.excess_nll.max(),
                "stress_excess_d_repr": stress_window.excess_d_repr.mean(),
                "stress_excess_d_pred": stress_window.excess_d_pred.mean(),
                "recovery_excess_nll_auc": recovery_window.excess_nll.sum(),
                "test_macro_f1": task.macro_f1,
                "test_nll": task.nll,
                "worst_client_macro_f1": task.worst_client_macro_f1,
            }
        )
    per_seed = pd.DataFrame(rows)
    paired_rows: list[dict[str, Any]] = []
    metrics = [
        "stress_d_spec_before",
        "stress_d_spec_after",
        "stress_excess_nll_auc",
        "stress_peak_excess_nll",
        "stress_excess_d_repr",
        "stress_excess_d_pred",
        "recovery_excess_nll_auc",
        "test_macro_f1",
        "test_nll",
        "worst_client_macro_f1",
    ]
    for scenario in sorted(per_seed.scenario.unique()):
        subset = per_seed[per_seed.scenario == scenario]
        fedavg = subset[subset.method == "fedavg"].set_index("seed")
        gsa = subset[subset.method == "gsa"].set_index("seed")
        for metric in metrics:
            diff = gsa[metric] - fedavg[metric]
            paired_rows.append(
                {
                    "scenario": scenario,
                    "metric": metric,
                    "fedavg_mean": fedavg[metric].mean(),
                    "gsa_mean": gsa[metric].mean(),
                    "gsa_minus_fedavg_mean": diff.mean(),
                    "gsa_minus_fedavg_std": diff.std(ddof=1),
                    "n_pairs": len(diff),
                }
            )
    return per_seed, pd.DataFrame(paired_rows)


def summarize_stage1(rounds: pd.DataFrame, results: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    per_seed_rows: list[dict[str, Any]] = []
    for (method, seed), group in rounds.groupby(["method", "seed"]):
        tail = group.sort_values("round").tail(10)
        task = results[(results.method == method) & (results.seed == seed)].iloc[0]
        per_seed_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "d_spec_after_last10": tail.d_spec_after.mean(),
                "d_repr_post_last10": tail.d_repr_post.mean(),
                "d_pred_post_last10": tail.d_pred_post.mean(),
                "validation_nll_std_last10": tail.validation_nll.std(ddof=1),
                "validation_nll_mean_last10": tail.validation_nll.mean(),
                "test_macro_f1": task.macro_f1,
                "test_nll": task.nll,
                "worst_client_macro_f1": task.worst_client_macro_f1,
                "aggregate_trainable_relative_change": tail.aggregate_trainable_relative_change.mean(),
                "aggregate_trainable_cosine": tail.aggregate_trainable_cosine.mean(),
            }
        )
    per_seed = pd.DataFrame(per_seed_rows)
    fedavg = per_seed[per_seed.method == "fedavg"].set_index("seed")
    gsa = per_seed[per_seed.method == "gsa"].set_index("seed")
    metrics = [
        "d_spec_after_last10",
        "d_repr_post_last10",
        "d_pred_post_last10",
        "validation_nll_std_last10",
        "validation_nll_mean_last10",
        "test_macro_f1",
        "test_nll",
        "worst_client_macro_f1",
    ]
    paired = []
    for metric in metrics:
        diff = gsa[metric] - fedavg[metric]
        paired.append(
            {
                "metric": metric,
                "fedavg_mean": fedavg[metric].mean(),
                "gsa_mean": gsa[metric].mean(),
                "gsa_minus_fedavg_mean": diff.mean(),
                "gsa_minus_fedavg_std": diff.std(ddof=1),
                "n_pairs": len(diff),
            }
        )
    return per_seed, pd.DataFrame(paired)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["stage1", "stage2", "stage3", "stage4"], default="stage1")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--seeds", nargs="*", type=int, default=[42, 43, 44, 45, 46])
    args = parser.parse_args()
    cfg = base.load_config()
    device = torch.device(args.device)
    OUT.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(cfg["data_path"])
    manifest_path = OUT / f"{args.phase}_manifest.json"
    changes = [
        "measure D_repr before and after GSA coordination",
        "add independent prediction-disagreement D_pred",
        "retain original GSA algorithm and hyperparameters",
    ]
    if args.phase == "stage2":
        changes.append("rounds 11-20 use client update delays [0,1,2,3,4] with fixed local epochs and learning rate")
    if args.phase == "stage3":
        changes.extend([
            "split anchor set into gate and independent audit halves",
            "accept spectral correction only when gate prediction disagreement does not increase",
            "require candidate gate NLL no more than 0.001 above the matched FedAvg candidate",
            "run matched clean and staleness scenarios",
        ])
    if args.phase == "stage4":
        changes.append("run mild [0,0,1,1,2] and severe [0,2,4,6,8] staleness with fixed local budget")
    manifest = {
        "status": "RUNNING",
        "phase": args.phase,
        "seeds": args.seeds,
        "device": str(device),
        "started_at": pd.Timestamp.utcnow().isoformat(),
        "changes": changes,
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    all_rounds, all_results = [], []
    try:
        for seed in args.seeds:
            prepared = base.prepare_data(frame, seed)
            if args.phase == "stage3":
                for scenario in ["clean", "staleness"]:
                    print(f"STAGE3 seed={seed} scenario={scenario} method=gsa_gate", flush=True)
                    rounds, result = run_gated_reliability(prepared, scenario, seed, cfg, device)
                    all_rounds.append(rounds)
                    all_results.append(result)
            elif args.phase == "stage4":
                for scenario in ["mild", "severe"]:
                    for method in ["fedavg", "gsa"]:
                        print(f"STAGE4 seed={seed} scenario={scenario} method={method}", flush=True)
                        rounds, result = run_staleness_stress(
                            prepared, method, seed, cfg, device, severity=scenario
                        )
                        all_rounds.append(rounds)
                        all_results.append(result)
            else:
                for method in ["fedavg", "gsa"]:
                    print(f"{args.phase.upper()} seed={seed} method={method}", flush=True)
                    if args.phase == "stage1":
                        rounds, result = run_measurement_fix(prepared, method, seed, cfg, device)
                    else:
                        rounds, result = run_staleness_stress(prepared, method, seed, cfg, device)
                    all_rounds.append(rounds)
                    all_results.append(result)
        round_frame = pd.concat(all_rounds, ignore_index=True)
        result_frame = pd.DataFrame(all_results)
        if args.phase == "stage1":
            per_seed, paired = summarize_stage1(round_frame, result_frame)
        elif args.phase == "stage2":
            per_seed, paired = summarize_stage2(round_frame, result_frame)
        elif args.phase == "stage3":
            per_seed, paired = summarize_stage3(round_frame, result_frame)
        else:
            per_seed, paired = summarize_stage4(round_frame, result_frame)
        round_frame.to_csv(OUT / f"{args.phase}_round_metrics.csv", index=False, encoding="utf-8-sig")
        result_frame.to_csv(OUT / f"{args.phase}_test_results.csv", index=False, encoding="utf-8-sig")
        per_seed.to_csv(OUT / f"{args.phase}_per_seed_summary.csv", index=False, encoding="utf-8-sig")
        paired.to_csv(OUT / f"{args.phase}_paired_differences.csv", index=False, encoding="utf-8-sig")
        manifest["status"] = "COMPLETED"
        manifest["completed_at"] = pd.Timestamp.utcnow().isoformat()
        manifest["counts"] = {"round_rows": len(round_frame), "test_rows": len(result_frame)}
    except Exception as exc:
        manifest["status"] = "FAILED"
        manifest["error"] = repr(exc)
        raise
    finally:
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUT, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
