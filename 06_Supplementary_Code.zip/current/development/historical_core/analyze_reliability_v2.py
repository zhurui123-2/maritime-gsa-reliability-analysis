from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest


ROOT = Path(r"E:\航运实验\experiments\results\gsa_reliability_v2_20260803")
RNG = np.random.default_rng(20260803)


def bootstrap_ci(values: np.ndarray, resamples: int = 10000) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    draws = RNG.choice(values, size=(resamples, len(values)), replace=True).mean(axis=1)
    return float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def exact_sign_p(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[values != 0]
    if len(values) == 0:
        return 1.0
    positives = int((values > 0).sum())
    return float(binomtest(positives, len(values), 0.5, alternative="two-sided").pvalue)


def build_moderate() -> pd.DataFrame:
    clean = pd.read_csv(ROOT / "stage1_round_metrics.csv")
    stress = pd.read_csv(ROOT / "stage2_round_metrics.csv")
    rows = []
    for method in ["fedavg", "gsa"]:
        reference = clean[clean.method == method]
        treatment = stress[stress.method == method]
        merged = treatment.merge(
            reference[["seed", "round", "validation_nll", "d_repr_post", "d_pred_post"]],
            on=["seed", "round"],
            suffixes=("_stress", "_clean"),
        )
        merged["excess_nll"] = merged.validation_nll_stress - merged.validation_nll_clean
        merged["excess_d_repr"] = merged.d_repr_post_stress - merged.d_repr_post_clean
        merged["excess_d_pred"] = merged.d_pred_post_stress - merged.d_pred_post_clean
        for seed, group in merged.groupby("seed"):
            shock = group[group.phase == "stress"]
            recovery = group[group.phase == "recovery"]
            rows.append(
                {
                    "scenario": "moderate",
                    "method": method,
                    "seed": int(seed),
                    "stress_d_spec_before": shock.d_spec_before.mean(),
                    "stress_d_spec_after": shock.d_spec_after.mean(),
                    "stress_excess_nll_auc": shock.excess_nll.sum(),
                    "stress_peak_excess_nll": shock.excess_nll.max(),
                    "stress_excess_d_repr": shock.excess_d_repr.mean(),
                    "stress_excess_d_pred": shock.excess_d_pred.mean(),
                    "recovery_excess_nll_auc": recovery.excess_nll.sum(),
                }
            )
    return pd.DataFrame(rows)


def main() -> int:
    stage1_paired = pd.read_csv(ROOT / "stage1_paired_differences.csv")
    stage4 = pd.read_csv(ROOT / "stage4_per_seed_summary.csv")
    moderate = build_moderate()
    common = list(moderate.columns)
    dose = pd.concat([stage4[common], moderate], ignore_index=True)
    dose_order = {"mild": 1, "moderate": 2, "severe": 3}
    dose["dose"] = dose.scenario.map(dose_order)
    dose.to_csv(ROOT / "dose_per_seed.csv", index=False, encoding="utf-8-sig")

    dose_summary = dose.groupby(["scenario", "method"], as_index=False).mean(numeric_only=True)
    dose_summary.to_csv(ROOT / "dose_summary.csv", index=False, encoding="utf-8-sig")

    metrics = [
        "stress_d_spec_before",
        "stress_d_spec_after",
        "stress_excess_nll_auc",
        "stress_peak_excess_nll",
        "stress_excess_d_repr",
        "stress_excess_d_pred",
        "recovery_excess_nll_auc",
    ]
    effects = []
    for scenario in ["mild", "moderate", "severe"]:
        subset = dose[dose.scenario == scenario]
        fedavg = subset[subset.method == "fedavg"].set_index("seed")
        gsa = subset[subset.method == "gsa"].set_index("seed")
        for metric in metrics:
            diff = (gsa[metric] - fedavg[metric]).to_numpy()
            low, high = bootstrap_ci(diff)
            effects.append(
                {
                    "scenario": scenario,
                    "metric": metric,
                    "fedavg_mean": fedavg[metric].mean(),
                    "gsa_mean": gsa[metric].mean(),
                    "gsa_minus_fedavg_mean": diff.mean(),
                    "ci95_low": low,
                    "ci95_high": high,
                    "exact_sign_p": exact_sign_p(diff),
                    "improved_seed_fraction": float((diff < 0).mean()),
                }
            )
    effects_frame = pd.DataFrame(effects)
    effects_frame.to_csv(ROOT / "paired_effects_with_ci.csv", index=False, encoding="utf-8-sig")

    slopes = []
    for method in ["fedavg", "gsa"]:
        for seed, group in dose[dose.method == method].groupby("seed"):
            group = group.sort_values("dose")
            slopes.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "damage_slope": float(np.polyfit(group.dose, group.stress_excess_nll_auc, 1)[0]),
                    "precoord_dspec_slope": float(np.polyfit(group.dose, group.stress_d_spec_before, 1)[0]),
                    "recovery_damage_slope": float(np.polyfit(group.dose, group.recovery_excess_nll_auc, 1)[0]),
                }
            )
    slopes_frame = pd.DataFrame(slopes)
    slopes_frame.to_csv(ROOT / "dose_slopes.csv", index=False, encoding="utf-8-sig")

    gate = pd.read_csv(ROOT / "stage3_per_seed_summary.csv")
    nll_effects = effects_frame[effects_frame.metric == "stress_excess_nll_auc"].set_index("scenario")
    recovery_effects = effects_frame[effects_frame.metric == "recovery_excess_nll_auc"].set_index("scenario")
    stage1_map = stage1_paired.set_index("metric")
    verdict = {
        "status": "ANALYZED",
        "measurement_fix": {
            "d_pred_last10_difference": float(stage1_map.loc["d_pred_post_last10", "gsa_minus_fedavg_mean"]),
            "d_repr_last10_difference": float(stage1_map.loc["d_repr_post_last10", "gsa_minus_fedavg_mean"]),
            "nll_volatility_difference": float(stage1_map.loc["validation_nll_std_last10", "gsa_minus_fedavg_mean"]),
            "interpretation": "预测分歧与NLL波动呈极小改善，表示分歧未改善。",
        },
        "degradation_identification": {
            "fedavg_damage_means": {
                scenario: float(
                    dose_summary[(dose_summary.scenario == scenario) & (dose_summary.method == "fedavg")][
                        "stress_excess_nll_auc"
                    ].iloc[0]
                )
                for scenario in ["mild", "moderate", "severe"]
            },
            "mean_damage_slope": float(slopes_frame[slopes_frame.method == "fedavg"].damage_slope.mean()),
            "mean_precoord_dspec_slope": float(slopes_frame[slopes_frame.method == "fedavg"].precoord_dspec_slope.mean()),
            "interpretation": "陈旧度与NLL退化存在清楚剂量关系，但协调前D_spec未呈相同剂量关系。",
        },
        "gsa_mitigation": {
            scenario: {
                "stress_nll_auc_difference": float(nll_effects.loc[scenario, "gsa_minus_fedavg_mean"]),
                "ci95": [float(nll_effects.loc[scenario, "ci95_low"]), float(nll_effects.loc[scenario, "ci95_high"])],
                "improved_seed_fraction": float(nll_effects.loc[scenario, "improved_seed_fraction"]),
                "recovery_auc_difference": float(recovery_effects.loc[scenario, "gsa_minus_fedavg_mean"]),
            }
            for scenario in ["mild", "moderate", "severe"]
        },
        "gate": {
            "acceptance_rate": float(gate.gate_acceptance_rate.mean()),
            "stress_damage_mean": float(gate.stress_excess_nll_auc.mean()),
            "verdict": "当前门控未优于原GSA，不进入主方法。",
        },
        "claim_boundary": {
            "supported": "陈旧更新强度增加会提高时序损失退化；原GSA在中重度陈旧条件下呈小幅缓解方向。",
            "not_supported": "D_spec是该可靠性退化的充分解释变量；GSA已获得稳定而实质性的系统级可靠性提升。",
            "next_gate": "使用未参与探索的新随机种子复核剂量效应，并增加FedNova或异步联邦基线。",
        },
        "excluded_result": "不同本地epoch版本改变了总训练预算，已保存到excluded_stage2_budget_confounded且不进入结论。",
    }
    (ROOT / "reliability_v2_verdict.json").write_text(
        json.dumps(verdict, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(verdict, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
