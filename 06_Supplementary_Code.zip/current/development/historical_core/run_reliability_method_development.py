from __future__ import annotations

import argparse
import copy
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
import run_rebuilt_experiments as base  # noqa: E402
from run_reliability_confirmatory import (  # noqa: E402
    DATA_PATH,
    MEASUREMENT_ROUNDS,
    delay_profile,
    diagnostics_without_gsa,
    local_train_masked,
    measure_client_models,
    models_from_updates,
    phase_for_round,
)


OUT = ROOT / "experiments" / "results" / "gsa_reliability_method_development_20260804"
SCENARIOS = ["clean", "stale_moderate", "stale_severe"]
STRESS_METHODS = [
    "fedavg",
    "gsa",
    "staleness_decay",
    "gsa_decay",
    "stale_consensus_gsa",
    "trusted_gsa",
]
CLEAN_METHODS = ["fedavg", "gsa", "trusted_gsa"]


def safe_js_divergence(a: np.ndarray, b: np.ndarray) -> float:
    eps = 1e-12
    left = np.clip(np.asarray(a, dtype=float), eps, None)
    right = np.clip(np.asarray(b, dtype=float), eps, None)
    left /= left.sum()
    right /= right.sum()
    midpoint = 0.5 * (left + right)
    value = 0.5 * np.sum(left * np.log2(left / midpoint)) + 0.5 * np.sum(right * np.log2(right / midpoint))
    return float(max(0.0, value))


def robust_spectrum_descriptor(
    matrix: torch.Tensor, q: int, rank_cap: int
) -> tuple[np.ndarray, tuple[torch.Tensor, torch.Tensor, torch.Tensor], float, int]:
    """Use the frozen descriptor; fall back to CPU float64 only if CUDA SVD fails."""
    try:
        descriptor, svd, norm = base.spectrum_descriptor(matrix, q, rank_cap)
        return descriptor, svd, norm, 0
    except torch._C._LinAlgError:
        mat = matrix.detach().double().cpu()
        if not torch.isfinite(mat).all():
            raise RuntimeError("non-finite values reached the spectral descriptor")
        if mat.ndim != 2:
            mat = mat.reshape(mat.shape[0], -1)
        norm = float(torch.linalg.norm(mat))
        if norm <= 1e-12:
            empty = torch.empty(0, device=matrix.device, dtype=matrix.dtype)
            return np.full(q, 1.0 / q), (empty, empty, empty), norm, 1
        u, singular_values, vh = torch.linalg.svd(mat, full_matrices=False)
        rank = min(rank_cap, len(singular_values))
        u = u[:, :rank].to(device=matrix.device, dtype=matrix.dtype)
        singular_values = singular_values[:rank].to(device=matrix.device, dtype=matrix.dtype)
        vh = vh[:rank].to(device=matrix.device, dtype=matrix.dtype)
        power = (singular_values.double().square() / singular_values.double().square().sum().clamp_min(1e-12)).cpu().numpy()
        cumulative = np.concatenate([[0.0], np.cumsum(power)])
        descriptor = np.diff(
            np.interp(np.linspace(0.0, 1.0, q + 1), np.linspace(0.0, 1.0, len(cumulative)), cumulative)
        )
        descriptor = np.clip(descriptor, 1e-12, None)
        descriptor /= descriptor.sum()
        return descriptor, (u, singular_values, vh), norm, 1


def robust_d_spec(
    updates: list[dict[str, torch.Tensor]], blocks: list[str], q: int, rank_cap: int
) -> tuple[float, int]:
    block_values = []
    fallback_count = 0
    for block in blocks:
        descriptors = []
        for update in updates:
            descriptor, _, _, fallback = robust_spectrum_descriptor(update[block], q, rank_cap)
            descriptors.append(descriptor)
            fallback_count += fallback
        distances = [
            safe_js_divergence(descriptors[i], descriptors[j])
            for i in range(len(descriptors))
            for j in range(i + 1, len(descriptors))
        ]
        block_values.append(float(np.mean(distances)))
    return float(np.mean(block_values)), fallback_count


def weighted_median(values: np.ndarray, weights: np.ndarray) -> float:
    order = np.argsort(values)
    sorted_values = values[order]
    sorted_weights = weights[order]
    threshold = 0.5 * sorted_weights.sum()
    return float(sorted_values[np.searchsorted(np.cumsum(sorted_weights), threshold, side="left")])


class ReliabilityWeightedGSACoordinator:
    """Deterministic coordination; no learned parameters and no validation labels."""

    def __init__(self, cfg: dict[str, Any], trust_mode: str):
        self.cfg = copy.deepcopy(cfg)
        self.trust_mode = trust_mode
        self.ema: dict[str, np.ndarray] = {}

    def coordinate(
        self,
        updates: list[dict[str, torch.Tensor]],
        blocks: list[str],
        delays: list[int],
    ) -> tuple[list[dict[str, torch.Tensor]], dict[str, float], np.ndarray]:
        q = int(self.cfg["descriptor_bins"])
        rank_cap = int(self.cfg["rank_cap"])
        before, before_fallbacks = robust_d_spec(updates, blocks, q, rank_cap)
        started = time.perf_counter()
        decomposed: dict[str, list[tuple[np.ndarray, tuple[torch.Tensor, torch.Tensor, torch.Tensor], float]]] = {}
        preliminary: dict[str, np.ndarray] = {}
        for block in blocks:
            robust_items = [robust_spectrum_descriptor(update[block], q, rank_cap) for update in updates]
            items = [(descriptor, svd, norm) for descriptor, svd, norm, _ in robust_items]
            before_fallbacks += sum(fallback for _, _, _, fallback in robust_items)
            decomposed[block] = items
            stack = np.stack([item[0] for item in items])
            median = np.median(stack, axis=0)
            median = np.clip(median, 1e-12, None)
            preliminary[block] = median / median.sum()

        staleness = 1.0 / (1.0 + np.asarray(delays, dtype=float))
        if self.trust_mode == "staleness_only":
            trust = staleness
            spectral_outlier = np.zeros(len(updates), dtype=float)
        elif self.trust_mode == "staleness_and_spectral":
            spectral_outlier = np.asarray(
                [
                    np.mean(
                        [
                            safe_js_divergence(decomposed[block][client_idx][0], preliminary[block])
                            for block in blocks
                        ]
                    )
                    for client_idx in range(len(updates))
                ],
                dtype=float,
            )
            positive = spectral_outlier[spectral_outlier > 1e-12]
            scale = float(np.median(positive)) if len(positive) else 1.0
            spectral_trust = 1.0 / (1.0 + spectral_outlier / max(scale, 1e-12))
            trust = staleness * spectral_trust
        else:
            raise ValueError(self.trust_mode)
        if not np.isfinite(trust).all():
            raise RuntimeError("non-finite reliability weights before aggregation")
        trust = np.clip(trust, 1e-12, None)

        consensus: dict[str, np.ndarray] = {}
        for block in blocks:
            stack = np.stack([item[0] for item in decomposed[block]])
            current = np.asarray(
                [weighted_median(stack[:, descriptor_idx], trust) for descriptor_idx in range(q)],
                dtype=float,
            )
            current = np.clip(current, 1e-12, None)
            current /= current.sum()
            beta = float(self.cfg["ema_beta"])
            if block in self.ema:
                current = beta * self.ema[block] + (1.0 - beta) * current
                current /= current.sum()
            self.ema[block] = current
            consensus[block] = current

        corrected = [{key: value.clone() for key, value in update.items()} for update in updates]
        alphas: list[float] = []
        cosines: list[float] = []
        fallbacks = 0
        for block in blocks:
            target_descriptor = consensus[block]
            for client_idx, (_, svd, norm) in enumerate(decomposed[block]):
                if norm <= 1e-12 or len(svd[1]) == 0:
                    fallbacks += 1
                    continue
                u, singular_values, vh = svd
                original_power = (
                    singular_values.square() / singular_values.square().sum().clamp_min(1e-12)
                ).detach().cpu().numpy()
                target_power = base.descriptor_to_power(target_descriptor, len(singular_values))
                alpha = float(self.cfg["alpha"])
                accepted = False
                while alpha >= float(self.cfg["min_alpha"]):
                    mixed = (1.0 - alpha) * original_power + alpha * target_power
                    mixed /= mixed.sum()
                    new_singular_values = torch.tensor(
                        np.sqrt(mixed) * norm,
                        device=singular_values.device,
                        dtype=singular_values.dtype,
                    )
                    candidate = (u * new_singular_values.unsqueeze(0)) @ vh
                    cosine = base.cosine_tensor(updates[client_idx][block], candidate)
                    if cosine >= float(self.cfg["tau"]):
                        corrected[client_idx][block] = candidate.reshape_as(updates[client_idx][block])
                        alphas.append(alpha)
                        cosines.append(cosine)
                        accepted = True
                        break
                    alpha *= 0.5
                if not accepted:
                    fallbacks += 1
                    alphas.append(0.0)
                    cosines.append(1.0)
        after, after_fallbacks = robust_d_spec(corrected, blocks, q, rank_cap)
        total = max(1, len(blocks) * len(updates))
        normalized_trust = trust / trust.sum()
        diagnostics = {
            "d_spec_before": before,
            "d_spec_after": after,
            "actual_alpha": float(np.mean(alphas)) if alphas else 0.0,
            "direction_cosine": float(np.mean(cosines)) if cosines else 1.0,
            "fallback_rate": fallbacks / total,
            "trust_min": float(normalized_trust.min()),
            "trust_max": float(normalized_trust.max()),
            "trust_effective_clients": float(1.0 / np.square(normalized_trust).sum()),
            "spectral_outlier_mean": float(spectral_outlier.mean()),
            "svd_fallback_count": int(before_fallbacks + after_fallbacks),
            "svd_seconds": time.perf_counter() - started,
        }
        return corrected, diagnostics, trust


def aggregate_with_trust(
    model: base.MultiModalNet,
    updates: list[dict[str, torch.Tensor]],
    counts: list[int],
    trust: np.ndarray,
) -> None:
    weights = np.asarray(counts, dtype=float) * np.asarray(trust, dtype=float)
    if not np.isfinite(weights).all() or weights.sum() <= 0:
        raise RuntimeError("invalid aggregation weights")
    weights /= weights.sum()
    state = model.state_dict()
    for key, value in state.items():
        if not torch.is_floating_point(value) or key not in updates[0]:
            continue
        delta = sum(float(weight) * update[key].to(value.device) for weight, update in zip(weights, updates))
        state[key] = value + delta
    model.load_state_dict(state, strict=True)


def reference_method(method: str) -> str:
    if method in {"fedavg", "staleness_decay"}:
        return "fedavg"
    if method in {"gsa", "gsa_decay", "stale_consensus_gsa"}:
        return "gsa"
    return "trusted_gsa"


def methods_for_scenario(scenario: str) -> list[str]:
    return CLEAN_METHODS if scenario == "clean" else STRESS_METHODS


def run_one(
    prepared: base.Prepared,
    scenario: str,
    method: str,
    seed: int,
    cfg: dict[str, Any],
    device: torch.device,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    base.seed_all(seed)
    train_parts = base.natural_partition(prepared.train_idx, prepared.nodes)
    test_parts = base.natural_partition(prepared.test_idx, prepared.nodes)
    model = base.MultiModalNet(
        prepared.dims,
        int(cfg["hidden_dim"]),
        int(cfg["embedding_dim"]),
        float(cfg["dropout"]),
    ).to(device)
    original_coordinator = base.GSACoordinator(copy.deepcopy(cfg["gsa"]), "gsa") if method in {"gsa", "gsa_decay"} else None
    weighted_coordinator = None
    if method == "stale_consensus_gsa":
        weighted_coordinator = ReliabilityWeightedGSACoordinator(cfg["gsa"], "staleness_only")
    elif method == "trusted_gsa":
        weighted_coordinator = ReliabilityWeightedGSACoordinator(cfg["gsa"], "staleness_and_spectral")
    model_history = [base.clone_state(model)]
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()

    for round_idx in range(1, int(cfg["rounds"]) + 1):
        delays_all = delay_profile(round_idx, scenario)
        local_models: list[base.MultiModalNet] = []
        counts: list[int] = []
        for client_idx, indices in enumerate(train_parts):
            delay = delays_all[client_idx]
            history_index = max(0, len(model_history) - 1 - delay)
            starting_model = copy.deepcopy(model)
            starting_model.load_state_dict(model_history[history_index], strict=True)
            local, count, _ = local_train_masked(
                starting_model,
                prepared,
                indices,
                device,
                cfg,
                "fedavg",
                seed + round_idx * 100 + client_idx,
                [1.0, 1.0, 1.0, 1.0],
            )
            local_models.append(local)
            counts.append(count)
        updates = base.state_updates(model, local_models)
        blocks = model.registered_blocks()
        if round_idx in MEASUREMENT_ROUNDS:
            d_repr_pre, d_pred_pre = measure_client_models(
                local_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
            )
        else:
            d_repr_pre, d_pred_pre = float("nan"), float("nan")

        if original_coordinator is not None:
            corrected, diagnostics = original_coordinator.coordinate(updates, blocks)
            trust = 1.0 / (1.0 + np.asarray(delays_all, dtype=float)) if method == "gsa_decay" else np.ones(5)
        elif weighted_coordinator is not None:
            corrected, diagnostics, trust = weighted_coordinator.coordinate(updates, blocks, delays_all)
        else:
            corrected = updates
            diagnostics = diagnostics_without_gsa(updates, blocks, cfg)
            trust = 1.0 / (1.0 + np.asarray(delays_all, dtype=float)) if method == "staleness_decay" else np.ones(5)
            normalized_trust = trust / trust.sum()
            diagnostics.update(
                {
                    "trust_min": float(normalized_trust.min()),
                    "trust_max": float(normalized_trust.max()),
                    "trust_effective_clients": float(1.0 / np.square(normalized_trust).sum()),
                    "spectral_outlier_mean": 0.0,
                }
            )

        if round_idx in MEASUREMENT_ROUNDS:
            post_models = models_from_updates(model, corrected)
            d_repr_post, d_pred_post = measure_client_models(
                post_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
            )
        else:
            d_repr_post, d_pred_post = float("nan"), float("nan")
        aggregate_with_trust(model, corrected, counts, trust)
        model_history.append(base.clone_state(model))
        validation = base.evaluate_model(
            model,
            prepared,
            prepared.anchor_idx,
            device,
            int(cfg["batch_size"]),
            seed=seed + round_idx,
        )
        rows.append(
            {
                "scenario": scenario,
                "method": method,
                "seed": seed,
                "round": round_idx,
                "phase": phase_for_round(round_idx, scenario),
                "staleness_delays": json.dumps(delays_all),
                "d_spec_before": diagnostics["d_spec_before"],
                "d_spec_after": diagnostics["d_spec_after"],
                "d_repr_pre": d_repr_pre,
                "d_repr_post": d_repr_post,
                "d_pred_pre": d_pred_pre,
                "d_pred_post": d_pred_post,
                "validation_nll": validation["nll"],
                "validation_brier": validation["brier"],
                "validation_ece": validation["ece"],
                "validation_macro_f1": validation["macro_f1"],
                "actual_alpha": diagnostics["actual_alpha"],
                "direction_cosine": diagnostics["direction_cosine"],
                "fallback_rate": diagnostics.get("fallback_rate", 0.0),
                "trust_min": diagnostics.get("trust_min", 0.2),
                "trust_max": diagnostics.get("trust_max", 0.2),
                "trust_effective_clients": diagnostics.get("trust_effective_clients", 5.0),
                "spectral_outlier_mean": diagnostics.get("spectral_outlier_mean", 0.0),
                "svd_fallback_count": diagnostics.get("svd_fallback_count", 0),
            }
        )

    test_metrics, client_f1 = base.evaluate_per_clients(
        model, prepared, test_parts, device, cfg, None, 0.0, seed
    )
    result = {
        "scenario": scenario,
        "method": method,
        "seed": seed,
        **test_metrics,
        "client_macro_f1": json.dumps(client_f1),
        "wall_seconds": time.perf_counter() - started,
    }
    return pd.DataFrame(rows), result


def combine(run_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    round_files = sorted(run_dir.glob("*.rounds.csv"))
    result_files = sorted(run_dir.glob("*.result.json"))
    rounds = pd.concat([pd.read_csv(path) for path in round_files], ignore_index=True)
    results = pd.DataFrame([json.loads(path.read_text(encoding="utf-8")) for path in result_files])
    return rounds, results


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--seeds", nargs="*", type=int, default=[42, 43, 44, 45, 46])
    parser.add_argument("--scenarios", nargs="*", choices=SCENARIOS, default=SCENARIOS)
    parser.add_argument("--methods", nargs="*", choices=STRESS_METHODS, default=STRESS_METHODS)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    cfg = base.load_config()
    cfg["data_path"] = str(DATA_PATH)
    cfg["rounds"] = 30
    cfg["local_epochs"] = 1
    device = torch.device(args.device)
    OUT.mkdir(parents=True, exist_ok=True)
    run_dir = OUT / "runs"
    run_dir.mkdir(exist_ok=True)
    frame = pd.read_csv(DATA_PATH)
    jobs = [
        (seed, scenario, method)
        for seed in args.seeds
        for scenario in args.scenarios
        for method in args.methods
        if method in methods_for_scenario(scenario)
    ]
    manifest = {
        "status": "RUNNING",
        "stage": "exploratory_method_development",
        "started_at": pd.Timestamp.now("UTC").isoformat(),
        "seeds": args.seeds,
        "scenarios": args.scenarios,
        "methods": args.methods,
        "n_jobs": len(jobs),
        "frozen_gsa": cfg["gsa"],
        "selection_rule": [
            "candidate must beat staleness_decay on mean stress excess NLL AUC in both moderate and severe staleness",
            "candidate must beat original GSA in both staleness severities",
            "candidate recovery excess NLL AUC may not exceed staleness_decay by more than 0.01 in either severity",
            "candidate must not worsen clean NLL by more than 0.01 relative to FedAvg",
            "seeds 47-56 are excluded from method selection",
        ],
    }
    manifest_path = OUT / "development_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    completed = 0
    try:
        for job_idx, (seed, scenario, method) in enumerate(jobs, start=1):
            stem = f"{scenario}__{method}__seed{seed}"
            round_path = run_dir / f"{stem}.rounds.csv"
            result_path = run_dir / f"{stem}.result.json"
            if not args.force and round_path.exists() and result_path.exists():
                completed += 1
                print(f"SKIP {job_idx}/{len(jobs)} {stem}", flush=True)
                continue
            print(f"RUN {job_idx}/{len(jobs)} {stem}", flush=True)
            prepared = base.prepare_data(frame, seed)
            rounds, result = run_one(prepared, scenario, method, seed, cfg, device)
            rounds.to_csv(round_path, index=False, encoding="utf-8-sig")
            result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            completed += 1
        rounds, results = combine(run_dir)
        rounds.to_csv(OUT / "development_round_metrics.csv", index=False, encoding="utf-8-sig")
        results.to_csv(OUT / "development_test_results.csv", index=False, encoding="utf-8-sig")
        manifest["status"] = "COMPLETED"
        manifest["completed_at"] = pd.Timestamp.now("UTC").isoformat()
        manifest["completed_jobs"] = completed
        manifest["counts"] = {"round_rows": len(rounds), "test_rows": len(results)}
    except Exception as exc:
        manifest["status"] = "FAILED"
        manifest["error"] = repr(exc)
        manifest["completed_jobs"] = completed
        raise
    finally:
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
