from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / "experiments" / "results" / "gsa_reliability_method_development_20260804"
SCENARIOS = ["stale_moderate", "stale_severe"]
CANDIDATES = ["gsa_decay", "stale_consensus_gsa", "trusted_gsa"]


def reference_method(method: str) -> str:
    if method in {"fedavg", "staleness_decay"}:
        return "fedavg"
    if method in {"gsa", "gsa_decay", "stale_consensus_gsa"}:
        return "gsa"
    return "trusted_gsa"


def stable_seed(label: str) -> int:
    return int(hashlib.sha256(label.encode("utf-8")).hexdigest()[:8], 16)


def bootstrap_ci(values: np.ndarray, label: str, reps: int = 10000) -> tuple[float, float]:
    rng = np.random.default_rng(stable_seed(label))
    samples = rng.choice(values, size=(reps, len(values)), replace=True).mean(axis=1)
    return float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def exact_sign_flip_p(values: np.ndarray) -> float:
    observed = abs(float(np.mean(values)))
    signs = np.asarray(list(itertools.product([-1.0, 1.0], repeat=len(values))))
    permuted = np.abs((signs * values[None, :]).mean(axis=1))
    return float(np.mean(permuted >= observed - 1e-15))


def build_per_seed(rounds: pd.DataFrame, results: pd.DataFrame) -> pd.DataFrame:
    clean = rounds[rounds.scenario == "clean"]
    rows: list[dict[str, Any]] = []
    for (scenario, method, seed), group in rounds[rounds.scenario != "clean"].groupby(
        ["scenario", "method", "seed"]
    ):
        ref_method = reference_method(method)
        reference = clean[(clean.method == ref_method) & (clean.seed == seed)]
        merged = group.merge(
            reference[["round", "validation_nll", "validation_brier", "validation_ece"]],
            on="round",
            suffixes=("_stress", "_clean"),
            validate="one_to_one",
        )
        for metric in ["nll", "brier", "ece"]:
            merged[f"excess_{metric}"] = (
                merged[f"validation_{metric}_stress"] - merged[f"validation_{metric}_clean"]
            )
        stress = merged[merged.phase == "stress"]
        recovery = merged[merged.phase == "recovery"]
        task = results[
            (results.scenario == scenario) & (results.method == method) & (results.seed == seed)
        ].iloc[0]
        rows.append(
            {
                "scenario": scenario,
                "method": method,
                "seed": int(seed),
                "reference_method": ref_method,
                "stress_excess_nll_auc": stress.excess_nll.sum(),
                "stress_peak_excess_nll": stress.excess_nll.max(),
                "stress_excess_brier_auc": stress.excess_brier.sum(),
                "stress_excess_ece_auc": stress.excess_ece.sum(),
                "recovery_excess_nll_auc": recovery.excess_nll.sum(),
                "stress_d_spec_after": stress.d_spec_after.mean(),
                "stress_d_repr_post": stress.d_repr_post.mean(),
                "stress_d_pred_post": stress.d_pred_post.mean(),
                "stress_trust_effective_clients": stress.trust_effective_clients.mean(),
                "test_macro_f1": task.macro_f1,
                "test_nll": task.nll,
                "worst_client_macro_f1": task.worst_client_macro_f1,
            }
        )
    return pd.DataFrame(rows)


def paired_effects(per_seed: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "stress_excess_nll_auc",
        "stress_peak_excess_nll",
        "recovery_excess_nll_auc",
        "stress_excess_brier_auc",
        "stress_d_spec_after",
        "stress_d_repr_post",
        "stress_d_pred_post",
        "test_macro_f1",
        "test_nll",
        "worst_client_macro_f1",
    ]
    rows = []
    for scenario in SCENARIOS:
        subset = per_seed[per_seed.scenario == scenario]
        for candidate in CANDIDATES:
            candidate_frame = subset[subset.method == candidate].set_index("seed")
            for comparator in ["gsa", "staleness_decay"]:
                comparator_frame = subset[subset.method == comparator].set_index("seed")
                common = candidate_frame.index.intersection(comparator_frame.index)
                for metric in metrics:
                    difference = (
                        candidate_frame.loc[common, metric] - comparator_frame.loc[common, metric]
                    ).to_numpy(float)
                    low, high = bootstrap_ci(difference, f"{scenario}:{candidate}:{comparator}:{metric}")
                    rows.append(
                        {
                            "scenario": scenario,
                            "candidate": candidate,
                            "comparator": comparator,
                            "metric": metric,
                            "candidate_mean": candidate_frame.loc[common, metric].mean(),
                            "comparator_mean": comparator_frame.loc[common, metric].mean(),
                            "candidate_minus_comparator_mean": difference.mean(),
                            "ci95_low": low,
                            "ci95_high": high,
                            "exact_sign_flip_p": exact_sign_flip_p(difference),
                            "candidate_better_seeds": int(np.sum(difference < 0)) if "f1" not in metric else int(np.sum(difference > 0)),
                            "n_pairs": len(difference),
                        }
                    )
    return pd.DataFrame(rows)


def clean_comparison(rounds: pd.DataFrame, results: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for method in ["gsa", "trusted_gsa"]:
        for seed in sorted(rounds.seed.unique()):
            fed = rounds[(rounds.scenario == "clean") & (rounds.method == "fedavg") & (rounds.seed == seed)].tail(10)
            candidate = rounds[(rounds.scenario == "clean") & (rounds.method == method) & (rounds.seed == seed)].tail(10)
            fed_test = results[(results.scenario == "clean") & (results.method == "fedavg") & (results.seed == seed)].iloc[0]
            candidate_test = results[(results.scenario == "clean") & (results.method == method) & (results.seed == seed)].iloc[0]
            rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "validation_nll_last10_diff": candidate.validation_nll.mean() - fed.validation_nll.mean(),
                    "test_nll_diff": candidate_test.nll - fed_test.nll,
                    "test_macro_f1_diff": candidate_test.macro_f1 - fed_test.macro_f1,
                }
            )
    return pd.DataFrame(rows)


def main() -> int:
    rounds = pd.read_csv(OUT / "development_round_metrics.csv")
    results = pd.read_csv(OUT / "development_test_results.csv")
    if rounds[["scenario", "method", "seed", "round"]].duplicated().any():
        raise RuntimeError("duplicate round rows")
    group_sizes = rounds.groupby(["scenario", "method", "seed"]).size()
    if not (group_sizes == 30).all():
        raise RuntimeError("incomplete runs")
    if rounds[["validation_nll", "validation_brier", "validation_ece"]].isna().any().any():
        raise RuntimeError("missing primary outcomes")

    per_seed = build_per_seed(rounds, results)
    effects = paired_effects(per_seed)
    clean = clean_comparison(rounds, results)
    screening_rows = []
    for candidate in CANDIDATES:
        candidate_clean_method = "trusted_gsa" if candidate == "trusted_gsa" else "gsa"
        clean_diff = clean[clean.method == candidate_clean_method].validation_nll_last10_diff.mean()
        criteria: dict[str, bool] = {}
        for scenario in SCENARIOS:
            stress_vs_decay = effects[
                (effects.scenario == scenario)
                & (effects.candidate == candidate)
                & (effects.comparator == "staleness_decay")
                & (effects.metric == "stress_excess_nll_auc")
            ].iloc[0]
            stress_vs_gsa = effects[
                (effects.scenario == scenario)
                & (effects.candidate == candidate)
                & (effects.comparator == "gsa")
                & (effects.metric == "stress_excess_nll_auc")
            ].iloc[0]
            recovery_vs_decay = effects[
                (effects.scenario == scenario)
                & (effects.candidate == candidate)
                & (effects.comparator == "staleness_decay")
                & (effects.metric == "recovery_excess_nll_auc")
            ].iloc[0]
            criteria[f"beat_decay_{scenario}"] = stress_vs_decay.candidate_minus_comparator_mean < 0
            criteria[f"beat_gsa_{scenario}"] = stress_vs_gsa.candidate_minus_comparator_mean < 0
            criteria[f"recovery_not_worse_{scenario}"] = recovery_vs_decay.candidate_minus_comparator_mean <= 0.01
        criteria["clean_nll_within_margin"] = clean_diff <= 0.01
        screening_rows.append(
            {
                "candidate": candidate,
                "clean_validation_nll_diff": clean_diff,
                **criteria,
                "passed_all": all(criteria.values()),
            }
        )
    screening = pd.DataFrame(screening_rows)
    passed = screening[screening.passed_all].candidate.tolist()
    if passed:
        # Choose the candidate with the lowest mean stress AUC across both severities.
        scores = {
            candidate: per_seed[per_seed.method == candidate].stress_excess_nll_auc.mean()
            for candidate in passed
        }
        selected = min(scores, key=scores.get)
        recommendation = (
            f"{selected}通过全部探索性淘汰标准。冻结该候选后，可进入全新种子57—66的确认性实验。"
        )
    else:
        selected = None
        recommendation = (
            "没有候选机制同时优于原GSA和陈旧度衰减基线。停止进入新种子确认阶段；"
            "当前GSA不应作为可靠性增强方法投稿。"
        )
    decision = {
        "selected_candidate": selected,
        "passed_candidates": passed,
        "advance_to_new_seed_confirmation": selected is not None,
        "recommendation": recommendation,
        "development_seeds": [42, 43, 44, 45, 46],
        "reserved_confirmation_seeds": list(range(57, 67)),
    }
    per_seed.to_csv(OUT / "development_per_seed.csv", index=False, encoding="utf-8-sig")
    effects.to_csv(OUT / "development_paired_effects.csv", index=False, encoding="utf-8-sig")
    clean.to_csv(OUT / "development_clean_comparison.csv", index=False, encoding="utf-8-sig")
    screening.to_csv(OUT / "development_screening.csv", index=False, encoding="utf-8-sig")
    (OUT / "development_decision.json").write_text(
        json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(decision, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
