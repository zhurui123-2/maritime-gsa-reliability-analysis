from __future__ import annotations

import argparse
import copy
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
import run_rebuilt_experiments as base  # noqa: E402
from run_reliability_confirmatory import (  # noqa: E402
    DATA_PATH,
    MEASUREMENT_ROUNDS,
    diagnostics_without_gsa,
    local_train_masked,
    measure_client_models,
    models_from_updates,
)
from run_reliability_method_development import aggregate_with_trust  # noqa: E402


OUT = ROOT / "experiments" / "results" / "sa_gsa_confirmatory_20260804"
SCENARIOS = ["clean", "stale_mild", "stale_moderate", "stale_severe"]
CLEAN_METHODS = ["fedavg", "fedprox", "gsa"]
STRESS_METHODS = ["fedavg", "fedprox", "gsa", "staleness_decay", "sa_gsa"]


def delays_for(round_idx: int, scenario: str) -> list[int]:
    if not 11 <= round_idx <= 20:
        return [0, 0, 0, 0, 0]
    profiles = {
        "stale_mild": [0, 0, 1, 1, 2],
        "stale_moderate": [0, 1, 2, 3, 4],
        "stale_severe": [0, 2, 4, 6, 8],
    }
    return profiles.get(scenario, [0, 0, 0, 0, 0])


def phase_for(round_idx: int, scenario: str) -> str:
    if scenario == "clean":
        return "clean"
    if round_idx <= 10:
        return "clean"
    if round_idx <= 20:
        return "stress"
    return "recovery"


def methods_for(scenario: str) -> list[str]:
    return CLEAN_METHODS if scenario == "clean" else STRESS_METHODS


def run_one(
    prepared: base.Prepared,
    scenario: str,
    method: str,
    seed: int,
    cfg: dict[str, Any],
    device: torch.device,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    base.seed_all(seed)
    train_parts = base.natural_partition(prepared.train_idx, prepared.nodes)
    test_parts = base.natural_partition(prepared.test_idx, prepared.nodes)
    model = base.MultiModalNet(
        prepared.dims,
        int(cfg["hidden_dim"]),
        int(cfg["embedding_dim"]),
        float(cfg["dropout"]),
    ).to(device)
    coordinator = (
        base.GSACoordinator(copy.deepcopy(cfg["gsa"]), "gsa")
        if method in {"gsa", "sa_gsa"}
        else None
    )
    model_history = [base.clone_state(model)]
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()

    for round_idx in range(1, int(cfg["rounds"]) + 1):
        delays = delays_for(round_idx, scenario)
        local_models: list[base.MultiModalNet] = []
        counts: list[int] = []
        local_method = "fedprox" if method == "fedprox" else "fedavg"
        for client_idx, indices in enumerate(train_parts):
            history_index = max(0, len(model_history) - 1 - delays[client_idx])
            starting_model = copy.deepcopy(model)
            starting_model.load_state_dict(model_history[history_index], strict=True)
            local, count, _ = local_train_masked(
                starting_model,
                prepared,
                indices,
                device,
                cfg,
                local_method,
                seed + round_idx * 100 + client_idx,
                [1.0, 1.0, 1.0, 1.0],
            )
            local_models.append(local)
            counts.append(count)
        updates = base.state_updates(model, local_models)
        blocks = model.registered_blocks()
        if round_idx in MEASUREMENT_ROUNDS:
            d_repr_pre, d_pred_pre = measure_client_models(
                local_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
            )
        else:
            d_repr_pre, d_pred_pre = float("nan"), float("nan")

        if coordinator is None:
            corrected = updates
            diagnostics = diagnostics_without_gsa(updates, blocks, cfg)
        else:
            corrected, diagnostics = coordinator.coordinate(updates, blocks)
        if round_idx in MEASUREMENT_ROUNDS:
            post_models = models_from_updates(model, corrected)
            d_repr_post, d_pred_post = measure_client_models(
                post_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
            )
        else:
            d_repr_post, d_pred_post = float("nan"), float("nan")

        if method in {"staleness_decay", "sa_gsa"}:
            trust = 1.0 / (1.0 + np.asarray(delays, dtype=float))
        else:
            trust = np.ones(5, dtype=float)
        aggregate_with_trust(model, corrected, counts, trust)
        model_history.append(base.clone_state(model))
        validation = base.evaluate_model(
            model,
            prepared,
            prepared.anchor_idx,
            device,
            int(cfg["batch_size"]),
            seed=seed + round_idx,
        )
        normalized_trust = trust / trust.sum()
        rows.append(
            {
                "scenario": scenario,
                "method": method,
                "seed": seed,
                "round": round_idx,
                "phase": phase_for(round_idx, scenario),
                "staleness_delays": json.dumps(delays),
                "d_spec_before": diagnostics["d_spec_before"],
                "d_spec_after": diagnostics["d_spec_after"],
                "d_repr_pre": d_repr_pre,
                "d_repr_post": d_repr_post,
                "d_pred_pre": d_pred_pre,
                "d_pred_post": d_pred_post,
                "validation_nll": validation["nll"],
                "validation_brier": validation["brier"],
                "validation_ece": validation["ece"],
                "validation_macro_f1": validation["macro_f1"],
                "actual_alpha": diagnostics["actual_alpha"],
                "direction_cosine": diagnostics["direction_cosine"],
                "fallback_rate": diagnostics.get("fallback_rate", 0.0),
                "aggregation_effective_clients": float(1.0 / np.square(normalized_trust).sum()),
            }
        )

    test_metrics, client_f1 = base.evaluate_per_clients(
        model, prepared, test_parts, device, cfg, None, 0.0, seed
    )
    result = {
        "scenario": scenario,
        "method": method,
        "seed": seed,
        **test_metrics,
        "client_macro_f1": json.dumps(client_f1),
        "wall_seconds": time.perf_counter() - started,
    }
    return pd.DataFrame(rows), result


def combine(run_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    rounds = pd.concat(
        [pd.read_csv(path) for path in sorted(run_dir.glob("*.rounds.csv"))], ignore_index=True
    )
    results = pd.DataFrame(
        [json.loads(path.read_text(encoding="utf-8")) for path in sorted(run_dir.glob("*.result.json"))]
    )
    return rounds, results


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--seeds", nargs="*", type=int, default=list(range(57, 67)))
    parser.add_argument("--scenarios", nargs="*", choices=SCENARIOS, default=SCENARIOS)
    parser.add_argument("--methods", nargs="*", choices=STRESS_METHODS, default=STRESS_METHODS)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    cfg = base.load_config()
    cfg["data_path"] = str(DATA_PATH)
    cfg["rounds"] = 30
    cfg["local_epochs"] = 1
    device = torch.device(args.device)
    OUT.mkdir(parents=True, exist_ok=True)
    run_dir = OUT / "runs"
    run_dir.mkdir(exist_ok=True)
    frame = pd.read_csv(DATA_PATH)
    jobs = [
        (seed, scenario, method)
        for seed in args.seeds
        for scenario in args.scenarios
        for method in args.methods
        if method in methods_for(scenario)
    ]
    manifest = {
        "status": "RUNNING",
        "stage": "sa_gsa_final_confirmation",
        "started_at": pd.Timestamp.now("UTC").isoformat(),
        "seeds": args.seeds,
        "scenarios": args.scenarios,
        "methods": args.methods,
        "n_jobs": len(jobs),
        "selected_method": "sa_gsa",
        "selected_on_seeds": [42, 43, 44, 45, 46],
        "excluded_previous_confirmation_seeds": list(range(47, 57)),
        "frozen_gsa": cfg["gsa"],
        "staleness_weight": "1/(1+delay)",
        "primary_scenarios": ["stale_moderate", "stale_severe"],
        "primary_comparator": "staleness_decay",
        "primary_outcome": "matched-trajectory stress excess NLL AUC over rounds 11-20",
        "confirmation_rule": [
            "SA-GSA minus staleness_decay mean < 0 in both primary severities",
            "95% paired bootstrap CI upper < 0 in both primary severities",
            "Holm-adjusted exact sign-flip p < 0.05 in both primary severities",
            "clean GSA versus FedAvg NLL noninferiority upper bound <= 0.01",
        ],
    }
    manifest_path = OUT / "sa_gsa_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    completed = 0
    try:
        for job_idx, (seed, scenario, method) in enumerate(jobs, start=1):
            stem = f"{scenario}__{method}__seed{seed}"
            round_path = run_dir / f"{stem}.rounds.csv"
            result_path = run_dir / f"{stem}.result.json"
            if not args.force and round_path.exists() and result_path.exists():
                completed += 1
                print(f"SKIP {job_idx}/{len(jobs)} {stem}", flush=True)
                continue
            print(f"RUN {job_idx}/{len(jobs)} {stem}", flush=True)
            prepared = base.prepare_data(frame, seed)
            rounds, result = run_one(prepared, scenario, method, seed, cfg, device)
            rounds.to_csv(round_path, index=False, encoding="utf-8-sig")
            result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            completed += 1
        rounds, results = combine(run_dir)
        rounds.to_csv(OUT / "sa_gsa_round_metrics.csv", index=False, encoding="utf-8-sig")
        results.to_csv(OUT / "sa_gsa_test_results.csv", index=False, encoding="utf-8-sig")
        manifest["status"] = "COMPLETED"
        manifest["completed_at"] = pd.Timestamp.now("UTC").isoformat()
        manifest["completed_jobs"] = completed
        manifest["counts"] = {"round_rows": len(rounds), "test_rows": len(results)}
    except Exception as exc:
        manifest["status"] = "FAILED"
        manifest["completed_jobs"] = completed
        manifest["error"] = repr(exc)
        raise
    finally:
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
