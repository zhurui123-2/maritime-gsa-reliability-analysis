$ErrorActionPreference = 'Stop'
$inputDoc = 'C:\CodexQA\input.docx'
$outputPdf = 'C:\CodexQA\output.pdf'
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {
    $doc = $word.Documents.Open($inputDoc, $false, $true, $false)
    $doc.PrintRevisions = $false
    $pages = $doc.ComputeStatistics(2)
    $doc.ExportAsFixedFormat($outputPdf, 17, $false, 0, 0, 1, $pages, 0, $true, $true, 1, $true, $true, $false)
    $doc.Close(0)
}
finally {
    $word.Quit()
    [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($word) | Out-Null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
Write-Output $outputPdf
