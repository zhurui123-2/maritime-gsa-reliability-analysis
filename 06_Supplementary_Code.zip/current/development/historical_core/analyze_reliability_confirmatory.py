from __future__ import annotations

import hashlib
import itertools
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / "experiments" / "results" / "gsa_reliability_confirmatory_20260804"
PRIMARY_SCENARIOS = ["stale_moderate", "modality_heterogeneity", "client_dropout"]
STRESS_SCENARIOS = PRIMARY_SCENARIOS + ["stale_severe"]


def stable_seed(label: str) -> int:
    return int(hashlib.sha256(label.encode("utf-8")).hexdigest()[:8], 16)


def bootstrap_mean_ci(values: np.ndarray, label: str, reps: int = 20000) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(stable_seed(label))
    draws = rng.choice(values, size=(reps, len(values)), replace=True).mean(axis=1)
    return float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def exact_sign_flip_p(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    observed = abs(float(values.mean()))
    signs = np.asarray(list(itertools.product([-1.0, 1.0], repeat=len(values))), dtype=float)
    permuted = np.abs((signs * values[None, :]).mean(axis=1))
    return float(np.mean(permuted >= observed - 1e-15))


def exact_two_sided_sign_p(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    positives = int(np.sum(values > 0))
    negatives = int(np.sum(values < 0))
    n = positives + negatives
    if n == 0:
        return 1.0
    k = min(positives, negatives)
    tail = sum(math.comb(n, i) for i in range(k + 1)) / (2**n)
    return float(min(1.0, 2.0 * tail))


def holm_adjust(p_values: dict[str, float]) -> dict[str, float]:
    ordered = sorted(p_values.items(), key=lambda item: item[1])
    adjusted: dict[str, float] = {}
    running = 0.0
    m = len(ordered)
    for rank, (name, p_value) in enumerate(ordered):
        candidate = min(1.0, (m - rank) * p_value)
        running = max(running, candidate)
        adjusted[name] = running
    return adjusted


def build_per_seed(rounds: pd.DataFrame, results: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    clean = rounds[rounds.scenario == "clean"]
    for (scenario, method, seed), group in rounds[rounds.scenario != "clean"].groupby(
        ["scenario", "method", "seed"]
    ):
        reference_method = "fedavg" if method == "staleness_decay" else method
        reference = clean[(clean.method == reference_method) & (clean.seed == seed)]
        merged = group.merge(
            reference[
                [
                    "round",
                    "validation_nll",
                    "validation_brier",
                    "validation_ece",
                    "validation_macro_f1",
                    "d_repr_post",
                    "d_pred_post",
                ]
            ],
            on="round",
            suffixes=("_stress", "_clean"),
            validate="one_to_one",
        )
        for metric in ["nll", "brier", "ece"]:
            merged[f"excess_{metric}"] = (
                merged[f"validation_{metric}_stress"] - merged[f"validation_{metric}_clean"]
            )
        merged["delta_macro_f1"] = (
            merged.validation_macro_f1_stress - merged.validation_macro_f1_clean
        )
        merged["excess_d_repr"] = merged.d_repr_post_stress - merged.d_repr_post_clean
        merged["excess_d_pred"] = merged.d_pred_post_stress - merged.d_pred_post_clean
        stress = merged[merged.phase == "stress"]
        recovery = merged[merged.phase == "recovery"]
        task = results[
            (results.scenario == scenario) & (results.method == method) & (results.seed == seed)
        ].iloc[0]
        rows.append(
            {
                "scenario": scenario,
                "method": method,
                "seed": int(seed),
                "reference_method": reference_method,
                "stress_excess_nll_auc": stress.excess_nll.sum(),
                "stress_peak_excess_nll": stress.excess_nll.max(),
                "stress_excess_brier_auc": stress.excess_brier.sum(),
                "stress_excess_ece_auc": stress.excess_ece.sum(),
                "stress_macro_f1_delta_auc": stress.delta_macro_f1.sum(),
                "recovery_excess_nll_auc": recovery.excess_nll.sum(),
                "recovery_excess_brier_auc": recovery.excess_brier.sum(),
                "stress_d_spec_before": stress.d_spec_before.mean(),
                "stress_d_spec_after": stress.d_spec_after.mean(),
                "stress_excess_d_repr": stress.excess_d_repr.mean(),
                "stress_excess_d_pred": stress.excess_d_pred.mean(),
                "stress_d_repr_post": stress.d_repr_post_stress.mean(),
                "stress_d_pred_post": stress.d_pred_post_stress.mean(),
                "test_macro_f1": task.macro_f1,
                "test_nll": task.nll,
                "test_brier": task.brier,
                "test_ece": task.ece,
                "worst_client_macro_f1": task.worst_client_macro_f1,
            }
        )
    return pd.DataFrame(rows)


def paired_comparisons(per_seed: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "stress_excess_nll_auc",
        "stress_peak_excess_nll",
        "stress_excess_brier_auc",
        "stress_excess_ece_auc",
        "stress_macro_f1_delta_auc",
        "recovery_excess_nll_auc",
        "stress_d_spec_before",
        "stress_d_spec_after",
        "stress_excess_d_repr",
        "stress_excess_d_pred",
        "test_macro_f1",
        "test_nll",
        "worst_client_macro_f1",
    ]
    rows: list[dict[str, Any]] = []
    for scenario in STRESS_SCENARIOS:
        subset = per_seed[per_seed.scenario == scenario]
        gsa = subset[subset.method == "gsa"].set_index("seed")
        comparators = [name for name in ["fedavg", "fedprox", "staleness_decay"] if name in set(subset.method)]
        for comparator in comparators:
            baseline = subset[subset.method == comparator].set_index("seed")
            common = gsa.index.intersection(baseline.index)
            for metric in metrics:
                diff = (gsa.loc[common, metric] - baseline.loc[common, metric]).to_numpy(float)
                low, high = bootstrap_mean_ci(diff, f"{scenario}:{comparator}:{metric}")
                rows.append(
                    {
                        "scenario": scenario,
                        "comparator": comparator,
                        "metric": metric,
                        "comparator_mean": baseline.loc[common, metric].mean(),
                        "gsa_mean": gsa.loc[common, metric].mean(),
                        "gsa_minus_comparator_mean": diff.mean(),
                        "paired_sd": diff.std(ddof=1),
                        "ci95_low": low,
                        "ci95_high": high,
                        "exact_sign_flip_p": exact_sign_flip_p(diff),
                        "exact_sign_p": exact_two_sided_sign_p(diff),
                        "pairs_gsa_better": int(np.sum(diff < 0)) if "f1" not in metric else int(np.sum(diff > 0)),
                        "n_pairs": len(diff),
                    }
                )
    return pd.DataFrame(rows)


def clean_comparison(rounds: pd.DataFrame, results: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for seed in sorted(rounds.seed.unique()):
        fed = rounds[(rounds.scenario == "clean") & (rounds.method == "fedavg") & (rounds.seed == seed)].tail(10)
        gsa = rounds[(rounds.scenario == "clean") & (rounds.method == "gsa") & (rounds.seed == seed)].tail(10)
        fed_test = results[(results.scenario == "clean") & (results.method == "fedavg") & (results.seed == seed)].iloc[0]
        gsa_test = results[(results.scenario == "clean") & (results.method == "gsa") & (results.seed == seed)].iloc[0]
        rows.append(
            {
                "seed": int(seed),
                "validation_nll_last10_diff": gsa.validation_nll.mean() - fed.validation_nll.mean(),
                "validation_brier_last10_diff": gsa.validation_brier.mean() - fed.validation_brier.mean(),
                "validation_ece_last10_diff": gsa.validation_ece.mean() - fed.validation_ece.mean(),
                "validation_macro_f1_last10_diff": gsa.validation_macro_f1.mean() - fed.validation_macro_f1.mean(),
                "test_nll_diff": gsa_test.nll - fed_test.nll,
                "test_macro_f1_diff": gsa_test.macro_f1 - fed_test.macro_f1,
                "worst_client_macro_f1_diff": gsa_test.worst_client_macro_f1 - fed_test.worst_client_macro_f1,
            }
        )
    return pd.DataFrame(rows)


def degradation_tests(per_seed: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for scenario in STRESS_SCENARIOS:
        values = per_seed[(per_seed.scenario == scenario) & (per_seed.method == "fedavg")][
            "stress_excess_nll_auc"
        ].to_numpy(float)
        low, high = bootstrap_mean_ci(values, f"degradation:{scenario}")
        rows.append(
            {
                "scenario": scenario,
                "fedavg_excess_nll_auc_mean": values.mean(),
                "ci95_low": low,
                "ci95_high": high,
                "exact_sign_flip_p": exact_sign_flip_p(values),
                "seeds_with_positive_damage": int(np.sum(values > 0)),
                "n_seeds": len(values),
            }
        )
    return pd.DataFrame(rows)


def write_report(
    primary: pd.DataFrame,
    clean: pd.DataFrame,
    degradation: pd.DataFrame,
    decision: dict[str, Any],
) -> None:
    lines = [
        "# GSA可靠性确认性实验结果",
        "",
        "本阶段仅使用未参与探索的47—56号种子。GSA参数在运行前冻结。",
        "",
        "## 主要终点：GSA相对FedAvg的压力期累计超额NLL",
        "",
        "| 场景 | FedAvg | GSA | 配对差(GSA-FedAvg) | 95% CI | Holm校正p | 改善种子 | 判定 |",
        "|---|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in primary.itertuples():
        lines.append(
            f"| {row.scenario} | {row.comparator_mean:.6f} | {row.gsa_mean:.6f} | "
            f"{row.gsa_minus_comparator_mean:+.6f} | [{row.ci95_low:+.6f}, {row.ci95_high:+.6f}] | "
            f"{row.holm_p:.4f} | {row.pairs_gsa_better}/{row.n_pairs} | {row.confirmed} |"
        )
    lines.extend(
        [
            "",
            "## FedAvg在压力下的退化",
            "",
            "| 场景 | 累计超额NLL | 95% CI | 正向损伤种子 |",
            "|---|---:|---:|---:|",
        ]
    )
    for row in degradation.itertuples():
        lines.append(
            f"| {row.scenario} | {row.fedavg_excess_nll_auc_mean:.6f} | "
            f"[{row.ci95_low:.6f}, {row.ci95_high:.6f}] | {row.seeds_with_positive_damage}/{row.n_seeds} |"
        )
    lines.extend(
        [
            "",
            "## 干净条件非劣性",
            "",
            f"- 最后10轮验证NLL差：{clean.validation_nll_last10_diff.mean():+.6f}。",
            f"- 测试NLL差：{clean.test_nll_diff.mean():+.6f}。",
            f"- 测试宏F1差：{clean.test_macro_f1_diff.mean():+.6f}。",
            f"- 是否通过预设边界：{decision['clean_noninferiority_passed']}。",
            "",
            "## 冻结判定",
            "",
            decision["claim_recommendation"],
            "",
            "D_spec、D_repr和D_pred结果只能支持机制一致性讨论。未进行正式中介识别，因此不得写成已证明的因果链。",
        ]
    )
    (OUT / "CONFIRMATORY_RESULTS.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    rounds = pd.read_csv(OUT / "confirmatory_round_metrics.csv")
    results = pd.read_csv(OUT / "confirmatory_test_results.csv")
    if rounds[["scenario", "method", "seed", "round"]].duplicated().any():
        raise RuntimeError("Duplicate scenario-method-seed-round rows detected")
    if rounds.validation_nll.isna().any():
        raise RuntimeError("Missing validation NLL values detected")

    per_seed = build_per_seed(rounds, results)
    paired = paired_comparisons(per_seed)
    clean = clean_comparison(rounds, results)
    degradation = degradation_tests(per_seed)

    primary = paired[
        (paired.scenario.isin(PRIMARY_SCENARIOS))
        & (paired.comparator == "fedavg")
        & (paired.metric == "stress_excess_nll_auc")
    ].copy()
    raw_p = dict(zip(primary.scenario, primary.exact_sign_flip_p))
    adjusted = holm_adjust(raw_p)
    primary["holm_p"] = primary.scenario.map(adjusted)
    primary["confirmed"] = (
        (primary.gsa_minus_comparator_mean < 0)
        & (primary.ci95_high < 0)
        & (primary.holm_p < 0.05)
    )

    clean_rules = [
        ("validation_nll_last10_diff", "upper", 0.01),
        ("test_nll_diff", "upper", 0.01),
        ("test_macro_f1_diff", "lower", -0.01),
    ]
    clean_summary_rows = []
    for metric, boundary, margin in clean_rules:
        values = clean[metric].to_numpy(float)
        low, high = bootstrap_mean_ci(values, f"clean_noninferiority:{metric}")
        passed = high <= margin if boundary == "upper" else low >= margin
        clean_summary_rows.append(
            {
                "metric": metric,
                "mean_difference": values.mean(),
                "ci95_low": low,
                "ci95_high": high,
                "boundary": boundary,
                "margin": margin,
                "passed": bool(passed),
                "n_pairs": len(values),
            }
        )
    clean_summary = pd.DataFrame(clean_summary_rows)
    clean_pass = bool(clean_summary.passed.all())
    confirmed_count = int(primary.confirmed.sum())
    strong = bool(confirmed_count >= 2 and clean_pass)
    if strong:
        recommendation = (
            "确认性结果支持跨场景的可靠性缓解表述：至少两个预设主要压力场景达到多重校正后的标准，"
            "且干净条件满足非劣性边界。表述仍应限定为本数据、本模型与已测试压力范围。"
        )
    elif confirmed_count >= 1 and clean_pass:
        supported = "、".join(primary.loc[primary.confirmed, "scenario"].tolist())
        recommendation = (
            f"确认性证据只在{supported}达到预设标准。论文应把结论收窄到该扰动，"
            "不宜概括为普遍的联邦知识融合可靠性提升。"
        )
    else:
        recommendation = (
            "确认性结果未达到预设的强可靠性标准。论文可报告异构压力造成的退化现象和GSA的探索性趋势，"
            "但不应下可靠性增强的确定性结论。"
        )
    decision = {
        "primary_confirmed_count": confirmed_count,
        "primary_total": len(PRIMARY_SCENARIOS),
        "clean_noninferiority_passed": clean_pass,
        "strong_cross_scenario_reliability_supported": strong,
        "claim_recommendation": recommendation,
        "rules": {
            "stress_confirmation": "mean difference < 0, bootstrap CI upper < 0, Holm-adjusted exact sign-flip p < 0.05",
            "strong_claim": "at least 2 of 3 primary stressors confirmed and clean noninferiority passed",
        },
    }

    per_seed.to_csv(OUT / "confirmatory_per_seed.csv", index=False, encoding="utf-8-sig")
    paired.to_csv(OUT / "confirmatory_paired_effects.csv", index=False, encoding="utf-8-sig")
    primary.to_csv(OUT / "confirmatory_primary_outcomes.csv", index=False, encoding="utf-8-sig")
    clean.to_csv(OUT / "confirmatory_clean_noninferiority.csv", index=False, encoding="utf-8-sig")
    clean_summary.to_csv(
        OUT / "confirmatory_clean_noninferiority_summary.csv", index=False, encoding="utf-8-sig"
    )
    degradation.to_csv(OUT / "confirmatory_stress_degradation.csv", index=False, encoding="utf-8-sig")
    (OUT / "confirmatory_decision.json").write_text(
        json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_report(primary, clean, degradation, decision)
    print(json.dumps(decision, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
