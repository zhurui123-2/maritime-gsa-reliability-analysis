from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import platform
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import scipy
import sklearn
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.spatial.distance import jensenshannon
from sklearn.compose import ColumnTransformer
from sklearn.metrics import (
    balanced_accuracy_score,
    brier_score_loss,
    f1_score,
    log_loss,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedShuffleSplit, train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from torch.utils.data import DataLoader, Dataset


ROOT = Path(r"E:\航运实验")
HERE = Path(__file__).resolve().parent
CONFIG_PATH = HERE / "config.json"


def load_config() -> dict[str, Any]:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def seed_all(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(False)


class SafeBatchNorm1d(nn.BatchNorm1d):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training and x.shape[0] == 1:
            return F.batch_norm(
                x, self.running_mean, self.running_var, self.weight, self.bias,
                False, self.momentum, self.eps,
            )
        return super().forward(x)


class MultiModalNet(nn.Module):
    def __init__(self, dims: dict[str, int], hidden: int, emb: int, dropout: float):
        super().__init__()
        self.modalities = list(dims)
        self.encoders = nn.ModuleDict()
        for name, dim in dims.items():
            self.encoders[name] = nn.Sequential(
                nn.Linear(dim, hidden),
                SafeBatchNorm1d(hidden),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(hidden, emb),
                nn.ReLU(),
            )
        self.fusion = nn.Sequential(
            nn.Linear(emb * len(dims) + len(dims), hidden),
            SafeBatchNorm1d(hidden),
            nn.ReLU(),
            nn.Linear(hidden, emb),
            nn.ReLU(),
        )
        self.head = nn.Linear(emb, 5)

    def forward(self, x: dict[str, torch.Tensor], mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        encoded = []
        for j, name in enumerate(self.modalities):
            z = self.encoders[name](x[name])
            z = z * mask[:, j:j + 1]
            encoded.append(z)
        fused_input = torch.cat(encoded + [mask], dim=1)
        representation = self.fusion(fused_input)
        return self.head(representation), representation

    def registered_blocks(self) -> list[str]:
        blocks = [f"encoders.{m}.4.weight" for m in self.modalities]
        return blocks + ["fusion.0.weight", "fusion.3.weight", "head.weight"]


class ArrayDataset(Dataset):
    def __init__(self, arrays: dict[str, np.ndarray], y: np.ndarray, indices: np.ndarray):
        self.arrays = arrays
        self.y = y
        self.indices = np.asarray(indices, dtype=np.int64)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, position: int):
        idx = self.indices[position]
        return {k: torch.from_numpy(v[idx]).float() for k, v in self.arrays.items()}, torch.tensor(self.y[idx]).long(), idx


@dataclass
class Prepared:
    frame: pd.DataFrame
    arrays: dict[str, np.ndarray]
    labels: np.ndarray
    nodes: np.ndarray
    train_idx: np.ndarray
    anchor_idx: np.ndarray
    test_idx: np.ndarray
    train_cutpoints: list[float]
    feature_names: dict[str, list[str]]
    dims: dict[str, int]


def parse_efficiency(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series.astype(str).str.extract(r"([-+]?[0-9]*\.?[0-9]+)")[0], errors="coerce")


def prepare_data(frame: pd.DataFrame, seed: int) -> Prepared:
    node = frame["federated_node"].astype(str).to_numpy()
    splitter = StratifiedShuffleSplit(n_splits=1, test_size=0.20, random_state=seed)
    train_anchor, test_idx = next(splitter.split(np.zeros(len(frame)), node))
    splitter2 = StratifiedShuffleSplit(n_splits=1, test_size=0.1875, random_state=seed + 1000)
    train_rel, anchor_rel = next(splitter2.split(np.zeros(len(train_anchor)), node[train_anchor]))
    train_idx = train_anchor[train_rel]
    anchor_idx = train_anchor[anchor_rel]

    target = pd.to_numeric(frame["total_co2_emissions_tonnes"], errors="coerce").to_numpy(float)
    cutpoints = np.quantile(target[train_idx], [0.2, 0.4, 0.6, 0.8]).tolist()
    labels = np.digitize(target, cutpoints, right=True).astype(np.int64)

    work = frame.copy()
    work["technical_efficiency_value"] = parse_efficiency(work["TechnicalEfficiency"])

    numeric_groups = {
        "ais": ["traj_points", "avg_speed", "max_speed", "speed_std", "avg_lat", "avg_lon", "avg_cog"],
        "weather": ["surface_pressure", "temperature_2m", "relative_humidity_2m", "u_wind_10m", "v_wind_10m"],
        "operations": ["time_at_sea_hours", "imo_observations", "weather_time_diff_hours"],
    }
    arrays: dict[str, np.ndarray] = {}
    names: dict[str, list[str]] = {}
    for modality, cols in numeric_groups.items():
        values = work[cols].apply(pd.to_numeric, errors="coerce")
        med = values.iloc[train_idx].median()
        values = values.fillna(med)
        scaler = StandardScaler().fit(values.iloc[train_idx])
        arrays[modality] = scaler.transform(values).astype(np.float32)
        names[modality] = cols

    registry_num = work[["technical_efficiency_value"]].apply(pd.to_numeric, errors="coerce")
    registry_num = registry_num.fillna(registry_num.iloc[train_idx].median())
    reg_scaler = StandardScaler().fit(registry_num.iloc[train_idx])
    reg_num = reg_scaler.transform(registry_num)
    registry_cat = work[["vessel_type_ais", "PortOfRegistry"]].fillna("UNKNOWN").astype(str)
    encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False, min_frequency=5)
    encoder.fit(registry_cat.iloc[train_idx])
    reg_cat = encoder.transform(registry_cat)
    arrays["registry"] = np.concatenate([reg_num, reg_cat], axis=1).astype(np.float32)
    names["registry"] = ["technical_efficiency_value"] + encoder.get_feature_names_out().tolist()

    dims = {k: int(v.shape[1]) for k, v in arrays.items()}
    return Prepared(
        frame=frame, arrays=arrays, labels=labels, nodes=node,
        train_idx=np.asarray(train_idx), anchor_idx=np.asarray(anchor_idx), test_idx=np.asarray(test_idx),
        train_cutpoints=cutpoints, feature_names=names, dims=dims,
    )


def dirichlet_partition(indices: np.ndarray, labels: np.ndarray, n_clients: int, alpha: float, seed: int) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    for _ in range(200):
        buckets: list[list[int]] = [[] for _ in range(n_clients)]
        for cls in np.unique(labels[indices]):
            cls_idx = indices[labels[indices] == cls].copy()
            rng.shuffle(cls_idx)
            proportions = rng.dirichlet(np.full(n_clients, alpha))
            cuts = (np.cumsum(proportions) * len(cls_idx)).astype(int)[:-1]
            for client, chunk in enumerate(np.split(cls_idx, cuts)):
                buckets[client].extend(chunk.tolist())
        if min(map(len, buckets)) >= 8:
            return [np.asarray(sorted(x), dtype=np.int64) for x in buckets]
    raise RuntimeError(f"Unable to create Dirichlet partition alpha={alpha}")


def iid_partition(indices: np.ndarray, labels: np.ndarray, n_clients: int, seed: int) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    buckets: list[list[int]] = [[] for _ in range(n_clients)]
    for cls in np.unique(labels[indices]):
        cls_idx = indices[labels[indices] == cls].copy()
        rng.shuffle(cls_idx)
        for j, chunk in enumerate(np.array_split(cls_idx, n_clients)):
            buckets[j].extend(chunk.tolist())
    return [np.asarray(sorted(x), dtype=np.int64) for x in buckets]


def natural_partition(indices: np.ndarray, nodes: np.ndarray) -> list[np.ndarray]:
    order = ["container", "tanker", "bulk", "general_cargo", "passenger"]
    return [indices[nodes[indices] == name] for name in order]


def make_partition(prepared: Prepared, indices: np.ndarray, setting: str, seed: int) -> list[np.ndarray]:
    if setting == "natural_ship_type":
        return natural_partition(indices, prepared.nodes)
    if setting == "iid":
        return iid_partition(indices, prepared.labels, 5, seed)
    if setting.startswith("dirichlet_"):
        alpha = float(setting.split("_", 1)[1])
        return dirichlet_partition(indices, prepared.labels, 5, alpha, seed)
    raise ValueError(setting)


def make_loader(prepared: Prepared, indices: np.ndarray, batch_size: int, shuffle: bool, seed: int) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(
        ArrayDataset(prepared.arrays, prepared.labels, indices),
        batch_size=batch_size, shuffle=shuffle, generator=generator, num_workers=0, drop_last=False,
    )


def make_mask(batch: int, n_modalities: int, missing_rate: float, device: torch.device, generator: torch.Generator | None = None) -> torch.Tensor:
    if missing_rate <= 0:
        return torch.ones(batch, n_modalities, device=device)
    mask = (torch.rand(batch, n_modalities, device=device, generator=generator) >= missing_rate).float()
    empty = mask.sum(dim=1) == 0
    if empty.any():
        mask[empty, 0] = 1.0
    return mask


def batch_to_device(batch, device):
    x, y, idx = batch
    return {k: v.to(device) for k, v in x.items()}, y.to(device), idx


def bn_state_keys(model: nn.Module) -> set[str]:
    keys: set[str] = set()
    for module_name, module in model.named_modules():
        if isinstance(module, nn.modules.batchnorm._BatchNorm):
            prefix = f"{module_name}." if module_name else ""
            keys.update({prefix + "weight", prefix + "bias", prefix + "running_mean", prefix + "running_var", prefix + "num_batches_tracked"})
    return keys


def clone_state(model: nn.Module) -> dict[str, torch.Tensor]:
    return {k: v.detach().clone() for k, v in model.state_dict().items()}


def apply_state(model: nn.Module, state: dict[str, torch.Tensor]) -> None:
    model.load_state_dict(state, strict=True)


def evaluate_model(
    model: MultiModalNet,
    prepared: Prepared,
    indices: np.ndarray,
    device: torch.device,
    batch_size: int,
    missing_rate: float = 0.0,
    seed: int = 0,
    return_repr: bool = False,
) -> dict[str, Any]:
    model.eval()
    ys, probs, reps, ids = [], [], [], []
    gen = torch.Generator(device=device).manual_seed(seed)
    with torch.no_grad():
        for batch in make_loader(prepared, indices, batch_size, False, seed):
            x, y, idx = batch_to_device(batch, device)
            mask = make_mask(len(y), len(model.modalities), missing_rate, device, gen)
            logits, rep = model(x, mask)
            ys.append(y.cpu().numpy())
            probs.append(logits.softmax(dim=1).cpu().numpy())
            reps.append(rep.cpu().numpy())
            ids.append(np.asarray(idx))
    y = np.concatenate(ys)
    p = np.concatenate(probs)
    pred = p.argmax(axis=1)
    true_prob = p[np.arange(len(y)), y]
    nll = float(-np.log(np.clip(true_prob, 1e-12, 1)).mean())
    onehot = np.eye(5)[y]
    brier = float(np.mean(np.sum((p - onehot) ** 2, axis=1)))
    confidence = p.max(axis=1)
    correct = (pred == y).astype(float)
    ece = 0.0
    for lo, hi in zip(np.linspace(0, 1, 11)[:-1], np.linspace(0, 1, 11)[1:]):
        sel = (confidence > lo) & (confidence <= hi)
        if sel.any():
            ece += float(sel.mean() * abs(correct[sel].mean() - confidence[sel].mean()))
    result = {
        "y": y, "prob": p, "indices": np.concatenate(ids),
        "macro_f1": float(f1_score(y, pred, average="macro", zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "nll": nll, "brier": brier, "ece": ece,
    }
    if return_repr:
        result["representation"] = np.concatenate(reps)
    return result


def pairwise_representation_distance(representations: list[np.ndarray]) -> float:
    values = []
    for i in range(len(representations)):
        a = representations[i]
        a = a / np.clip(np.linalg.norm(a, axis=1, keepdims=True), 1e-12, None)
        for j in range(i + 1, len(representations)):
            b = representations[j]
            b = b / np.clip(np.linalg.norm(b, axis=1, keepdims=True), 1e-12, None)
            values.append(float(np.mean(1.0 - np.sum(a * b, axis=1))))
    return float(np.mean(values)) if values else float("nan")


def spectrum_descriptor(matrix: torch.Tensor, q: int, rank_cap: int) -> tuple[np.ndarray, tuple[torch.Tensor, torch.Tensor, torch.Tensor], float]:
    mat = matrix.detach().float()
    if mat.ndim != 2:
        mat = mat.reshape(mat.shape[0], -1)
    norm = float(torch.linalg.norm(mat).cpu())
    if norm <= 1e-12:
        return np.full(q, 1.0 / q), (torch.empty(0), torch.empty(0), torch.empty(0)), norm
    u, s, vh = torch.linalg.svd(mat, full_matrices=False)
    r = min(rank_cap, len(s))
    u, s, vh = u[:, :r], s[:r], vh[:r]
    power = (s.square() / s.square().sum().clamp_min(1e-12)).cpu().numpy()
    cumulative = np.concatenate([[0.0], np.cumsum(power)])
    xp = np.linspace(0.0, 1.0, len(cumulative))
    grid = np.linspace(0.0, 1.0, q + 1)
    c = np.interp(grid, xp, cumulative)
    desc = np.clip(np.diff(c), 1e-12, None)
    desc = desc / desc.sum()
    return desc, (u, s, vh), norm


def descriptor_to_power(desc: np.ndarray, r: int) -> np.ndarray:
    cumulative = np.concatenate([[0.0], np.cumsum(desc / np.clip(desc.sum(), 1e-12, None))])
    xp = np.linspace(0.0, 1.0, len(cumulative))
    grid = np.linspace(0.0, 1.0, r + 1)
    c = np.interp(grid, xp, cumulative)
    power = np.clip(np.diff(c), 1e-12, None)
    return power / power.sum()


def js_divergence(a: np.ndarray, b: np.ndarray) -> float:
    return float(jensenshannon(a, b, base=2.0) ** 2)


def d_spec(updates: list[dict[str, torch.Tensor]], blocks: list[str], q: int, rank_cap: int) -> tuple[float, dict[str, float]]:
    per_block = {}
    for block in blocks:
        descs = [spectrum_descriptor(u[block], q, rank_cap)[0] for u in updates]
        distances = [js_divergence(descs[i], descs[j]) for i in range(len(descs)) for j in range(i + 1, len(descs))]
        per_block[block] = float(np.mean(distances)) if distances else float("nan")
    return float(np.nanmean(list(per_block.values()))), per_block


def cosine_tensor(a: torch.Tensor, b: torch.Tensor) -> float:
    av = a.reshape(-1).float()
    bv = b.reshape(-1).float()
    return float(F.cosine_similarity(av, bv, dim=0).detach().cpu())


class GSACoordinator:
    def __init__(self, cfg: dict[str, Any], variant: str = "gsa"):
        self.cfg = cfg
        self.variant = variant
        self.ema: dict[str, np.ndarray] = {}

    def coordinate(self, updates: list[dict[str, torch.Tensor]], blocks: list[str]) -> tuple[list[dict[str, torch.Tensor]], dict[str, float]]:
        q = int(self.cfg["descriptor_bins"])
        rank_cap = int(self.cfg["rank_cap"])
        before, _ = d_spec(updates, blocks, q, rank_cap)
        if self.variant == "norm_only":
            corrected = [{k: v.clone() for k, v in u.items()} for u in updates]
            for block in blocks:
                norms = np.array([float(torch.linalg.norm(u[block]).cpu()) for u in updates])
                target = float(np.median(norms))
                for j, u in enumerate(updates):
                    if norms[j] > 1e-12:
                        corrected[j][block] = u[block] * (target / norms[j])
            after, _ = d_spec(corrected, blocks, q, rank_cap)
            return corrected, {"d_spec_before": before, "d_spec_after": after, "actual_alpha": 0.0, "direction_cosine": 1.0, "fallback_rate": 0.0, "svd_seconds": 0.0}

        start = time.perf_counter()
        decomposed: dict[str, list[tuple[np.ndarray, tuple[torch.Tensor, torch.Tensor, torch.Tensor], float]]] = {}
        consensus: dict[str, np.ndarray] = {}
        for block in blocks:
            items = [spectrum_descriptor(u[block], q, rank_cap) for u in updates]
            decomposed[block] = items
            stack = np.stack([x[0] for x in items])
            if self.variant == "random_consensus":
                rng = np.random.default_rng(abs(hash(block)) % (2**32))
                current = rng.dirichlet(np.ones(q))
            else:
                current = np.median(stack, axis=0)
                current = np.clip(current, 1e-12, None)
                current /= current.sum()
            beta = 0.0 if self.variant == "no_ema" else float(self.cfg["ema_beta"])
            if block in self.ema:
                current = beta * self.ema[block] + (1 - beta) * current
                current /= current.sum()
            self.ema[block] = current
            consensus[block] = current

        block_targets = blocks[1:] + blocks[:1] if self.variant == "nonhomologous" else blocks
        corrected = [{k: v.clone() for k, v in u.items()} for u in updates]
        alphas, cosines, fallbacks = [], [], 0
        for bi, block in enumerate(blocks):
            target_desc = consensus[block_targets[bi]]
            for ci, (desc, svd, norm) in enumerate(decomposed[block]):
                if norm <= 1e-12 or len(svd[1]) == 0:
                    fallbacks += 1
                    continue
                u, s, vh = svd
                original_power = (s.square() / s.square().sum().clamp_min(1e-12)).detach().cpu().numpy()
                target_power = descriptor_to_power(target_desc, len(s))
                alpha = float(self.cfg["alpha"])
                tau = -1.0 if self.variant == "no_direction_bound" else float(self.cfg["tau"])
                accepted = False
                while alpha >= float(self.cfg["min_alpha"]):
                    mixed = (1 - alpha) * original_power + alpha * target_power
                    mixed = mixed / mixed.sum()
                    new_s = torch.tensor(np.sqrt(mixed) * norm, device=s.device, dtype=s.dtype)
                    candidate = (u * new_s.unsqueeze(0)) @ vh
                    cosine = cosine_tensor(updates[ci][block], candidate)
                    if cosine >= tau:
                        corrected[ci][block] = candidate.reshape_as(updates[ci][block])
                        alphas.append(alpha)
                        cosines.append(cosine)
                        accepted = True
                        break
                    alpha *= 0.5
                if not accepted:
                    fallbacks += 1
                    alphas.append(0.0)
                    cosines.append(1.0)
        svd_seconds = time.perf_counter() - start
        after, _ = d_spec(corrected, blocks, q, rank_cap)
        total = max(1, len(blocks) * len(updates))
        return corrected, {
            "d_spec_before": before,
            "d_spec_after": after,
            "actual_alpha": float(np.mean(alphas)) if alphas else 0.0,
            "direction_cosine": float(np.mean(cosines)) if cosines else 1.0,
            "fallback_rate": fallbacks / total,
            "svd_seconds": svd_seconds,
        }


def local_train(
    global_model: MultiModalNet,
    prepared: Prepared,
    indices: np.ndarray,
    device: torch.device,
    cfg: dict[str, Any],
    method: str,
    seed: int,
    global_parameters: dict[str, torch.Tensor],
    scaffold_global: dict[str, torch.Tensor] | None = None,
    scaffold_local: dict[str, torch.Tensor] | None = None,
    client_bn_state: dict[str, torch.Tensor] | None = None,
) -> tuple[MultiModalNet, int, dict[str, torch.Tensor] | None, int]:
    model = copy.deepcopy(global_model).to(device)
    if method == "fedbn" and client_bn_state:
        state = model.state_dict()
        for k, v in client_bn_state.items():
            state[k] = v.to(device)
        model.load_state_dict(state)
    model.train()
    optimizer = torch.optim.SGD(model.parameters(), lr=float(cfg["learning_rate"]), weight_decay=float(cfg["weight_decay"]))
    steps = 0
    for epoch in range(int(cfg["local_epochs"])):
        loader = make_loader(prepared, indices, int(cfg["batch_size"]), True, seed + epoch)
        for batch in loader:
            x, y, _ = batch_to_device(batch, device)
            mask = make_mask(len(y), len(model.modalities), 0.0, device)
            optimizer.zero_grad(set_to_none=True)
            logits, _ = model(x, mask)
            loss = F.cross_entropy(logits, y)
            if method == "fedprox":
                prox = torch.zeros((), device=device)
                for name, p in model.named_parameters():
                    prox = prox + (p - global_parameters[name].to(device)).square().sum()
                loss = loss + 0.5 * float(cfg["fedprox_mu"]) * prox
            loss.backward()
            if method == "scaffold" and scaffold_global is not None and scaffold_local is not None:
                for name, p in model.named_parameters():
                    if p.grad is not None:
                        p.grad.add_(scaffold_global[name].to(device) - scaffold_local[name].to(device))
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            steps += 1

    new_control = None
    if method == "scaffold" and scaffold_global is not None and scaffold_local is not None:
        new_control = {}
        denom = max(1, steps) * float(cfg["learning_rate"])
        for name, p in model.named_parameters():
            new_control[name] = (
                scaffold_local[name].to(device) - scaffold_global[name].to(device)
                + (global_parameters[name].to(device) - p.detach()) / denom
            ).detach().cpu()
    return model, len(indices), new_control, steps


def state_updates(global_model: MultiModalNet, local_models: list[MultiModalNet]) -> list[dict[str, torch.Tensor]]:
    global_state = global_model.state_dict()
    updates = []
    for model in local_models:
        local_state = model.state_dict()
        updates.append({k: (local_state[k].detach() - global_state[k].detach()) for k in global_state if torch.is_floating_point(global_state[k])})
    return updates


def aggregate_updates(
    global_model: MultiModalNet,
    updates: list[dict[str, torch.Tensor]],
    counts: list[int],
    method: str,
) -> None:
    state = global_model.state_dict()
    weights = np.asarray(counts, float)
    weights /= weights.sum()
    bn_keys = bn_state_keys(global_model) if method == "fedbn" else set()
    for key, value in state.items():
        if key in bn_keys or not torch.is_floating_point(value) or key not in updates[0]:
            continue
        delta = sum(float(w) * update[key].to(value.device) for w, update in zip(weights, updates))
        state[key] = value + delta
    global_model.load_state_dict(state)


def evaluate_per_clients(
    model: MultiModalNet,
    prepared: Prepared,
    partitions: list[np.ndarray],
    device: torch.device,
    cfg: dict[str, Any],
    client_bn_states: list[dict[str, torch.Tensor]] | None = None,
    missing_rate: float = 0.0,
    seed: int = 0,
) -> tuple[dict[str, float], list[float]]:
    all_y, all_p = [], []
    client_f1 = []
    for ci, indices in enumerate(partitions):
        eval_model = copy.deepcopy(model)
        if client_bn_states is not None:
            state = eval_model.state_dict()
            for k, v in client_bn_states[ci].items():
                state[k] = v.to(device)
            eval_model.load_state_dict(state)
        res = evaluate_model(eval_model.to(device), prepared, indices, device, int(cfg["batch_size"]), missing_rate, seed + ci)
        all_y.append(res["y"])
        all_p.append(res["prob"])
        client_f1.append(res["macro_f1"])
    y = np.concatenate(all_y)
    p = np.concatenate(all_p)
    pred = p.argmax(1)
    true_prob = p[np.arange(len(y)), y]
    onehot = np.eye(5)[y]
    confidence = p.max(1)
    correct = (pred == y).astype(float)
    ece = 0.0
    edges = np.linspace(0, 1, 11)
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = (confidence > lo) & (confidence <= hi)
        if sel.any():
            ece += float(sel.mean() * abs(correct[sel].mean() - confidence[sel].mean()))
    metrics = {
        "macro_f1": float(f1_score(y, pred, average="macro", zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "nll": float(-np.log(np.clip(true_prob, 1e-12, 1)).mean()),
        "brier": float(np.mean(np.sum((p - onehot) ** 2, axis=1))),
        "ece": ece,
        "worst_client_macro_f1": float(min(client_f1)),
        "client_macro_f1_variance": float(np.var(client_f1, ddof=1)),
    }
    return metrics, client_f1


def membership_attack(
    model: MultiModalNet,
    prepared: Prepared,
    device: torch.device,
    cfg: dict[str, Any],
    seed: int,
) -> dict[str, float]:
    train = evaluate_model(model, prepared, prepared.train_idx, device, int(cfg["batch_size"]), seed=seed)
    test = evaluate_model(model, prepared, prepared.test_idx, device, int(cfg["batch_size"]), seed=seed + 1)
    rows = []
    for membership, result in ((1, train), (0, test)):
        for y, p, idx in zip(result["y"], result["prob"], result["indices"]):
            rows.append({
                "membership": membership,
                "label": int(y),
                "node": str(prepared.nodes[int(idx)]),
                "loss": float(-math.log(max(float(p[y]), 1e-12))),
                "max_confidence": float(p.max()),
                "entropy": float(-(p * np.log(np.clip(p, 1e-12, 1))).sum()),
            })
    attack = pd.DataFrame(rows)
    matched = []
    rng = np.random.default_rng(seed)
    for (_, _), group in attack.groupby(["node", "label"]):
        members = group[group.membership == 1]
        nonmembers = group[group.membership == 0]
        n = min(len(members), len(nonmembers))
        if n >= 2:
            matched.append(members.sample(n, random_state=seed))
            matched.append(nonmembers.sample(n, random_state=seed + 1))
    matched_df = pd.concat(matched, ignore_index=True)
    x = matched_df[["loss", "max_confidence", "entropy"]].to_numpy()
    y = matched_df["membership"].to_numpy()
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, stratify=y, random_state=seed)
    scaler = StandardScaler().fit(x_train)
    clf = LogisticRegression(max_iter=1000, random_state=seed).fit(scaler.transform(x_train), y_train)
    score = clf.predict_proba(scaler.transform(x_test))[:, 1]
    auc = float(roc_auc_score(y_test, score))
    return {"mia_auroc": auc, "mia_advantage": float(2 * auc - 1), "mia_matched_samples": int(len(matched_df))}


def run_federated(
    prepared: Prepared,
    setting: str,
    method: str,
    seed: int,
    cfg: dict[str, Any],
    device: torch.device,
    gsa_variant: str = "gsa",
    participation: float = 1.0,
    rounds_override: int | None = None,
    mechanism: bool = True,
) -> tuple[dict[str, Any], pd.DataFrame, MultiModalNet, list[dict[str, torch.Tensor]] | None]:
    seed_all(seed)
    train_parts = make_partition(prepared, prepared.train_idx, setting, seed)
    test_parts = make_partition(prepared, prepared.test_idx, setting, seed + 9000)
    model = MultiModalNet(prepared.dims, int(cfg["hidden_dim"]), int(cfg["embedding_dim"]), float(cfg["dropout"])).to(device)
    bn_keys = bn_state_keys(model)
    client_bn_states = [{k: v.detach().cpu().clone() for k, v in model.state_dict().items() if k in bn_keys} for _ in train_parts]
    scaffold_global = {n: torch.zeros_like(p, device="cpu") for n, p in model.named_parameters()} if method == "scaffold" else None
    scaffold_local = [{n: torch.zeros_like(p, device="cpu") for n, p in model.named_parameters()} for _ in train_parts] if method == "scaffold" else None
    coordinator = GSACoordinator(cfg["gsa"], gsa_variant) if method == "gsa" else None
    rounds = int(rounds_override or cfg["rounds"])
    round_rows = []
    total_start = time.perf_counter()
    total_svd = 0.0
    rng = np.random.default_rng(seed + 20000)
    for round_idx in range(1, rounds + 1):
        n_active = max(2, int(math.ceil(len(train_parts) * participation)))
        active = sorted(rng.choice(len(train_parts), size=n_active, replace=False).tolist())
        global_parameters = {n: p.detach().clone() for n, p in model.named_parameters()}
        local_models, counts, new_controls = [], [], []
        for ci in active:
            local, count, new_control, _ = local_train(
                model, prepared, train_parts[ci], device, cfg, method, seed + round_idx * 100 + ci,
                global_parameters, scaffold_global, scaffold_local[ci] if scaffold_local else None,
                client_bn_states[ci] if method == "fedbn" else None,
            )
            local_models.append(local)
            counts.append(count)
            new_controls.append(new_control)
            if method == "fedbn":
                state = local.state_dict()
                client_bn_states[ci] = {k: state[k].detach().cpu().clone() for k in bn_keys}
        updates = state_updates(model, local_models)
        blocks = model.registered_blocks()
        pre_dspec, _ = d_spec(updates, blocks, int(cfg["gsa"]["descriptor_bins"]), int(cfg["gsa"]["rank_cap"]))

        drepr = float("nan")
        if mechanism and method in {"fedavg", "gsa"}:
            reps = [evaluate_model(lm, prepared, prepared.anchor_idx, device, int(cfg["batch_size"]), seed=seed, return_repr=True)["representation"] for lm in local_models]
            drepr = pairwise_representation_distance(reps)

        diagnostics = {"d_spec_before": pre_dspec, "d_spec_after": pre_dspec, "actual_alpha": 0.0, "direction_cosine": 1.0, "fallback_rate": 0.0, "svd_seconds": 0.0}
        if coordinator is not None:
            updates, diagnostics = coordinator.coordinate(updates, blocks)
            total_svd += diagnostics["svd_seconds"]
        aggregate_updates(model, updates, counts, method)

        if method == "scaffold" and scaffold_global is not None and scaffold_local is not None:
            for ci, new_control in zip(active, new_controls):
                assert new_control is not None
                delta = {k: new_control[k] - scaffold_local[ci][k] for k in new_control}
                scaffold_local[ci] = new_control
                for k in scaffold_global:
                    scaffold_global[k] = scaffold_global[k] + delta[k] / len(train_parts)

        val = evaluate_model(model, prepared, prepared.anchor_idx, device, int(cfg["batch_size"]), seed=seed + round_idx)
        round_rows.append({
            "setting": setting, "method": method, "variant": gsa_variant if method == "gsa" else "none",
            "seed": seed, "round": round_idx, "active_clients": len(active),
            "d_spec_before": diagnostics["d_spec_before"], "d_spec_after": diagnostics["d_spec_after"],
            "d_repr": drepr, "validation_nll": val["nll"], "validation_macro_f1": val["macro_f1"],
            "actual_alpha": diagnostics["actual_alpha"], "direction_cosine": diagnostics["direction_cosine"],
            "fallback_rate": diagnostics["fallback_rate"], "svd_seconds": diagnostics["svd_seconds"],
        })
    total_seconds = time.perf_counter() - total_start
    metrics, client_f1 = evaluate_per_clients(
        model, prepared, test_parts, device, cfg,
        client_bn_states if method == "fedbn" else None, 0.0, seed,
    )
    attack = membership_attack(model, prepared, device, cfg, seed) if setting == "natural_ship_type" and method in {"fedavg", "gsa"} and gsa_variant == "gsa" else {}
    params = sum(p.numel() for p in model.parameters())
    communication_mb = len(train_parts) * params * 4 * 2 / (1024 ** 2)
    result = {
        "setting": setting, "method": method, "variant": gsa_variant if method == "gsa" else "none", "seed": seed,
        "rounds": rounds, "participation": participation, **metrics, **attack,
        "wall_seconds": total_seconds, "svd_seconds": total_svd,
        "svd_share": total_svd / max(total_seconds, 1e-12), "per_round_communication_mb": communication_mb,
        "client_macro_f1": json.dumps(client_f1),
    }
    return result, pd.DataFrame(round_rows), model, client_bn_states if method == "fedbn" else None


def run_local_only(prepared: Prepared, seed: int, cfg: dict[str, Any], device: torch.device) -> dict[str, Any]:
    seed_all(seed)
    train_parts = natural_partition(prepared.train_idx, prepared.nodes)
    test_parts = natural_partition(prepared.test_idx, prepared.nodes)
    models = []
    start = time.perf_counter()
    for ci, indices in enumerate(train_parts):
        model = MultiModalNet(prepared.dims, int(cfg["hidden_dim"]), int(cfg["embedding_dim"]), float(cfg["dropout"])).to(device)
        optimizer = torch.optim.SGD(model.parameters(), lr=float(cfg["learning_rate"]), weight_decay=float(cfg["weight_decay"]))
        model.train()
        for epoch in range(int(cfg["rounds"])):
            for batch in make_loader(prepared, indices, int(cfg["batch_size"]), True, seed + ci * 1000 + epoch):
                x, y, _ = batch_to_device(batch, device)
                optimizer.zero_grad(set_to_none=True)
                logits, _ = model(x, torch.ones(len(y), 4, device=device))
                F.cross_entropy(logits, y).backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()
        models.append(model)
    all_y, all_p, client_f1 = [], [], []
    for ci, model in enumerate(models):
        res = evaluate_model(model, prepared, test_parts[ci], device, int(cfg["batch_size"]), seed=seed + ci)
        all_y.append(res["y"]); all_p.append(res["prob"]); client_f1.append(res["macro_f1"])
    y = np.concatenate(all_y); p = np.concatenate(all_p); pred = p.argmax(1)
    onehot = np.eye(5)[y]; tp = p[np.arange(len(y)), y]
    return {
        "setting": "natural_ship_type", "method": "local", "variant": "none", "seed": seed,
        "rounds": int(cfg["rounds"]), "participation": 1.0,
        "macro_f1": float(f1_score(y, pred, average="macro", zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "nll": float(-np.log(np.clip(tp, 1e-12, 1)).mean()),
        "brier": float(np.mean(np.sum((p - onehot) ** 2, axis=1))),
        "ece": float("nan"), "worst_client_macro_f1": float(min(client_f1)),
        "client_macro_f1_variance": float(np.var(client_f1, ddof=1)),
        "wall_seconds": time.perf_counter() - start, "svd_seconds": 0.0, "svd_share": 0.0,
        "per_round_communication_mb": 0.0, "client_macro_f1": json.dumps(client_f1),
    }


RESULT_COLUMNS = [
    "setting", "method", "variant", "seed", "rounds", "participation",
    "macro_f1", "balanced_accuracy", "nll", "brier", "ece",
    "worst_client_macro_f1", "client_macro_f1_variance",
    "mia_auroc", "mia_advantage", "mia_matched_samples",
    "wall_seconds", "svd_seconds", "svd_share", "per_round_communication_mb",
    "missing_rate", "client_macro_f1",
]


def append_csv(path: Path, row_or_frame: dict[str, Any] | pd.DataFrame) -> None:
    frame = pd.DataFrame([row_or_frame]) if isinstance(row_or_frame, dict) else row_or_frame
    if isinstance(row_or_frame, dict) and path.name in {"main_results.csv", "ablation_results.csv", "robustness_results.csv"}:
        frame = frame.reindex(columns=RESULT_COLUMNS)
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, mode="a", header=not path.exists(), index=False, encoding="utf-8-sig")


def completed_keys(path: Path, columns: list[str]) -> set[tuple]:
    if not path.exists():
        return set()
    frame = pd.read_csv(path)
    return set(map(tuple, frame[columns].itertuples(index=False, name=None)))


def save_checkpoint(path: Path, model: MultiModalNet, prepared: Prepared, result: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({"state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()}, "dims": prepared.dims, "result": result}, path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["all", "core", "ablation", "robustness", "smoke"], default="all")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--rounds", type=int)
    parser.add_argument("--only-setting", choices=["iid", "dirichlet_1.0", "dirichlet_0.3", "dirichlet_0.1", "natural_ship_type"])
    args = parser.parse_args()
    cfg = load_config()
    out = Path(cfg["output_dir"])
    out.mkdir(parents=True, exist_ok=True)
    data_path = Path(cfg["data_path"])
    frame = pd.read_csv(data_path)
    device = torch.device(args.device)
    seeds = cfg["seeds"] if args.phase != "smoke" else [cfg["seeds"][0]]
    if args.phase == "smoke":
        cfg = copy.deepcopy(cfg)
        cfg["rounds"] = args.rounds or 2
        smoke_tag = f"smoke_r{cfg['rounds']}_{args.only_setting or 'all'}"
        cfg["output_dir"] = str(out / smoke_tag)
        out = Path(cfg["output_dir"]); out.mkdir(parents=True, exist_ok=True)
    if args.rounds is not None and args.phase != "smoke":
        cfg["rounds"] = args.rounds
    if args.only_setting is not None:
        cfg["heterogeneity_settings"] = [args.only_setting]

    manifest = {
        "status": "RUNNING", "experiment_id": cfg["experiment_id"], "started_at": pd.Timestamp.utcnow().isoformat(),
        "data_path": str(data_path), "data_sha256": sha256(data_path), "rows": len(frame), "config": cfg,
        "environment": {"python": platform.python_version(), "platform": platform.platform(), "torch": torch.__version__,
                        "cuda": torch.cuda.is_available(), "device": str(device), "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
                        "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "sklearn": sklearn.__version__},
    }
    (out / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    main_csv = out / "main_results.csv"
    rounds_csv = out / "round_metrics.csv"
    ablation_csv = out / "ablation_results.csv"
    robustness_csv = out / "robustness_results.csv"
    data_audit_rows = []

    try:
        prepared_cache = {seed: prepare_data(frame, seed) for seed in seeds}
        for seed, prepared in prepared_cache.items():
            row = {"seed": seed, "n_total": len(frame), "n_train": len(prepared.train_idx), "n_anchor": len(prepared.anchor_idx), "n_test": len(prepared.test_idx),
                   "cutpoints": json.dumps(prepared.train_cutpoints), "dims": json.dumps(prepared.dims),
                   "train_label_counts": json.dumps(np.bincount(prepared.labels[prepared.train_idx], minlength=5).tolist()),
                   "test_label_counts": json.dumps(np.bincount(prepared.labels[prepared.test_idx], minlength=5).tolist())}
            data_audit_rows.append(row)
        pd.DataFrame(data_audit_rows).to_csv(out / "data_audit.csv", index=False, encoding="utf-8-sig")

        if args.phase in {"all", "core", "smoke"}:
            done = completed_keys(main_csv, ["setting", "method", "variant", "seed", "participation"])
            for seed in seeds:
                prepared = prepared_cache[seed]
                for setting in cfg["heterogeneity_settings"]:
                    for method in ("fedavg", "gsa"):
                        key = (setting, method, "gsa" if method == "gsa" else "none", seed, 1.0)
                        if key in done:
                            continue
                        print(f"RUN core setting={setting} method={method} seed={seed}", flush=True)
                        result, rounds, model, _ = run_federated(prepared, setting, method, seed, cfg, device, mechanism=True)
                        append_csv(main_csv, result); append_csv(rounds_csv, rounds)
                        if setting == "natural_ship_type":
                            save_checkpoint(out / "checkpoints" / f"{method}_seed{seed}.pt", model, prepared, result)
                if args.phase != "smoke":
                    local_key = ("natural_ship_type", "local", "none", seed, 1.0)
                    if local_key not in done:
                        print(f"RUN core method=local seed={seed}", flush=True)
                        append_csv(main_csv, run_local_only(prepared, seed, cfg, device))
                    for method in ("fedprox", "fedbn", "scaffold"):
                        key = ("natural_ship_type", method, "none", seed, 1.0)
                        if key in done:
                            continue
                        print(f"RUN core setting=natural_ship_type method={method} seed={seed}", flush=True)
                        result, rounds, model, _ = run_federated(prepared, "natural_ship_type", method, seed, cfg, device, mechanism=False)
                        append_csv(main_csv, result)

        if args.phase in {"all", "ablation"}:
            done = completed_keys(ablation_csv, ["setting", "method", "variant", "seed", "participation"])
            for seed in seeds:
                prepared = prepared_cache[seed]
                for variant in cfg["ablations"]:
                    if variant == "gsa":
                        continue
                    key = ("natural_ship_type", "gsa", variant, seed, 1.0)
                    if key in done:
                        continue
                    print(f"RUN ablation variant={variant} seed={seed}", flush=True)
                    result, rounds, _, _ = run_federated(prepared, "natural_ship_type", "gsa", seed, cfg, device, gsa_variant=variant, mechanism=True)
                    append_csv(ablation_csv, result); append_csv(rounds_csv, rounds)

        if args.phase in {"all", "robustness"}:
            done = completed_keys(robustness_csv, ["setting", "method", "variant", "seed", "participation", "missing_rate"])
            for seed in seeds:
                prepared = prepared_cache[seed]
                for method in ("fedavg", "gsa"):
                    for participation in (0.8, 0.6):
                        key = ("natural_ship_type", method, "gsa" if method == "gsa" else "none", seed, participation, 0.0)
                        if key in done:
                            continue
                        print(f"RUN robustness participation={participation} method={method} seed={seed}", flush=True)
                        result, rounds, model, bn = run_federated(prepared, "natural_ship_type", method, seed, cfg, device, participation=participation, mechanism=True)
                        result["missing_rate"] = 0.0
                        append_csv(robustness_csv, result)
                # Inference-time modality missingness uses the frozen natural-condition checkpoints.
                for method in ("fedavg", "gsa"):
                    checkpoint = torch.load(out / "checkpoints" / f"{method}_seed{seed}.pt", map_location=device, weights_only=False)
                    model = MultiModalNet(prepared.dims, int(cfg["hidden_dim"]), int(cfg["embedding_dim"]), float(cfg["dropout"])).to(device)
                    model.load_state_dict(checkpoint["state_dict"])
                    test_parts = natural_partition(prepared.test_idx, prepared.nodes)
                    for missing_rate in (0.2, 0.4):
                        key = ("natural_ship_type", method, "gsa" if method == "gsa" else "none", seed, 1.0, missing_rate)
                        if key in done:
                            continue
                        metrics, client_f1 = evaluate_per_clients(model, prepared, test_parts, device, cfg, None, missing_rate, seed)
                        row = {"setting": "natural_ship_type", "method": method, "variant": "gsa" if method == "gsa" else "none", "seed": seed,
                               "rounds": int(cfg["rounds"]), "participation": 1.0, "missing_rate": missing_rate, **metrics,
                               "client_macro_f1": json.dumps(client_f1), "wall_seconds": 0.0, "svd_seconds": 0.0, "svd_share": 0.0,
                               "per_round_communication_mb": checkpoint["result"]["per_round_communication_mb"]}
                        append_csv(robustness_csv, row)

        manifest["status"] = "COMPLETED"
        manifest["completed_at"] = pd.Timestamp.utcnow().isoformat()
    except Exception as exc:
        manifest["status"] = "FAILED"
        manifest["failed_at"] = pd.Timestamp.utcnow().isoformat()
        manifest["error"] = repr(exc)
        raise
    finally:
        (out / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(out, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
