from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / "experiments" / "results" / "sa_gsa_confirmatory_20260804"
DATA = ROOT / "data" / "processed" / "shipping_multimodal.csv"

EXPECTED_SEEDS = set(range(57, 67))
EXPECTED_SCENARIOS = {"clean", "stale_mild", "stale_moderate", "stale_severe"}
EXPECTED_STRESS_METHODS = {"fedavg", "fedprox", "gsa", "staleness_decay", "sa_gsa"}
EXPECTED_CLEAN_METHODS = {"fedavg", "fedprox", "gsa"}
PROFILES = {
    "stale_mild": [0, 0, 1, 1, 2],
    "stale_moderate": [0, 1, 2, 3, 4],
    "stale_severe": [0, 2, 4, 6, 8],
}
REFERENCE = {
    "fedavg": "fedavg",
    "fedprox": "fedprox",
    "gsa": "gsa",
    "staleness_decay": "fedavg",
    "sa_gsa": "gsa",
}
PREFIX_METRICS = [
    "validation_nll",
    "validation_brier",
    "validation_ece",
    "validation_macro_f1",
    "d_spec_before",
    "d_spec_after",
    "actual_alpha",
    "direction_cosine",
    "fallback_rate",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def check(condition: bool, label: str, checks: dict[str, bool]) -> None:
    checks[label] = bool(condition)


def main() -> int:
    rounds_path = OUT / "sa_gsa_round_metrics.csv"
    tests_path = OUT / "sa_gsa_test_results.csv"
    manifest_path = OUT / "sa_gsa_manifest.json"
    primary_path = OUT / "sa_gsa_primary_outcomes.csv"
    clean_path = OUT / "sa_gsa_clean_noninferiority.csv"
    rounds = pd.read_csv(rounds_path)
    tests = pd.read_csv(tests_path)
    primary = pd.read_csv(primary_path)
    clean = pd.read_csv(clean_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    checks: dict[str, bool] = {}

    check(manifest.get("status") == "COMPLETED", "manifest_completed", checks)
    check(set(rounds.seed.unique()) == EXPECTED_SEEDS, "confirmation_seeds_57_66_only", checks)
    check(not set(range(42, 57)).intersection(set(rounds.seed.unique())), "earlier_seeds_excluded", checks)
    check(set(rounds.scenario.unique()) == EXPECTED_SCENARIOS, "all_scenarios_present", checks)
    check(set(rounds.loc[rounds.scenario == "clean", "method"].unique()) == EXPECTED_CLEAN_METHODS, "clean_methods_exact", checks)
    check(set(rounds.loc[rounds.scenario != "clean", "method"].unique()) == EXPECTED_STRESS_METHODS, "stress_methods_exact", checks)
    check(len(rounds) == 5400, "round_row_count_5400", checks)
    check(len(tests) == 180, "test_row_count_180", checks)
    check(not rounds[["scenario", "method", "seed", "round"]].duplicated().any(), "no_duplicate_round_keys", checks)
    check(not tests[["scenario", "method", "seed"]].duplicated().any(), "no_duplicate_test_keys", checks)
    check((rounds.groupby(["scenario", "method", "seed"]).size() == 30).all(), "all_runs_have_30_rounds", checks)
    primary_columns = ["validation_nll", "validation_brier", "validation_ece", "validation_macro_f1"]
    test_columns = ["macro_f1", "balanced_accuracy", "nll", "brier", "ece", "worst_client_macro_f1"]
    check(not rounds[primary_columns].isna().any().any(), "no_missing_primary_round_metrics", checks)
    check(not tests[test_columns].isna().any().any(), "no_missing_test_metrics", checks)
    check(np.isfinite(rounds[primary_columns].to_numpy(float)).all(), "finite_primary_round_metrics", checks)
    check(np.isfinite(tests[test_columns].to_numpy(float)).all(), "finite_test_metrics", checks)

    phase_ok = True
    profile_ok = True
    for row in rounds.itertuples(index=False):
        delays = json.loads(row.staleness_delays)
        if row.scenario == "clean":
            expected_phase = "clean"
            expected_delays = [0, 0, 0, 0, 0]
        elif row.round <= 10:
            expected_phase = "clean"
            expected_delays = [0, 0, 0, 0, 0]
        elif row.round <= 20:
            expected_phase = "stress"
            expected_delays = PROFILES[row.scenario]
        else:
            expected_phase = "recovery"
            expected_delays = [0, 0, 0, 0, 0]
        phase_ok &= row.phase == expected_phase
        profile_ok &= delays == expected_delays
    check(phase_ok, "phase_labels_exact", checks)
    check(profile_ok, "staleness_profiles_stress_only_and_reset", checks)

    prefix_max_abs = 0.0
    prefix_ok = True
    clean_rounds = rounds[rounds.scenario == "clean"]
    for scenario in PROFILES:
        for method in EXPECTED_STRESS_METHODS:
            left = rounds[(rounds.scenario == scenario) & (rounds.method == method) & (rounds["round"] <= 10)]
            right = clean_rounds[clean_rounds.method == REFERENCE[method]]
            merged = left.merge(right, on=["seed", "round"], suffixes=("_stress", "_clean"), validate="one_to_one")
            for metric in PREFIX_METRICS:
                difference = np.abs(merged[f"{metric}_stress"].to_numpy(float) - merged[f"{metric}_clean"].to_numpy(float))
                if difference.size:
                    finite = difference[np.isfinite(difference)]
                    if finite.size:
                        prefix_max_abs = max(prefix_max_abs, float(finite.max()))
                    prefix_ok &= bool(np.allclose(difference, 0.0, atol=1e-12, rtol=0.0, equal_nan=True))
    check(prefix_ok, "pre_stress_prefixes_match_clean_references", checks)

    check(len(primary) == 2, "two_primary_scenarios", checks)
    check(set(primary.scenario) == {"stale_moderate", "stale_severe"}, "primary_scenarios_exact", checks)
    check((primary.n_pairs == 10).all(), "primary_pair_count_10", checks)
    check((primary.comparator == "staleness_decay").all(), "specialized_primary_comparator", checks)
    check(clean.passed.astype(str).str.lower().eq("true").all(), "clean_noninferiority_passed", checks)

    hash_targets = [
        HERE / "run_sa_gsa_confirmatory.py",
        HERE / "analyze_sa_gsa_confirmatory.py",
        Path(__file__).resolve(),
        OUT / "SA_GSA_CONFIRMATORY_PROTOCOL.md",
        rounds_path,
        tests_path,
        primary_path,
        clean_path,
    ]
    if DATA.exists():
        hash_targets.append(DATA)
    hashes = {str(path): sha256(path) for path in hash_targets if path.exists()}
    verification = {
        "all_checks_passed": all(checks.values()),
        "checks": checks,
        "pre_stress_max_absolute_difference": prefix_max_abs,
        "counts": {
            "round_rows": len(rounds),
            "test_rows": len(tests),
            "run_groups": int(rounds.groupby(["scenario", "method", "seed"]).ngroups),
        },
        "sha256": hashes,
    }
    (OUT / "sa_gsa_verification.json").write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding="utf-8")

    fallacy_scan = {
        "status": "PASS_WITH_CLAIM_RESTRICTION",
        "items": [
            {"risk": "把谱差异下降等同于可靠性提升", "finding": "高风险；SA-GSA显著降低D_spec，但相对专用基线的NLL增益未通过确认。", "required_action": "D_spec只作为机制诊断量，不作任务层可靠性的替代终点。"},
            {"risk": "方法开发与最终确认复用随机种子", "finding": "未发生；开发使用42—46，最终确认使用57—66，47—56亦被排除。", "required_action": "正文明确开发集与确认集隔离。"},
            {"risk": "不公平基线", "finding": "已纳入直接针对陈旧更新的staleness_decay，并作为主比较对象。", "required_action": "FedAvg只能作为普通参照，不能承担主要因果归因。"},
            {"risk": "多重检验选择性报告", "finding": "两种主要严重度使用Holm校正；校正后均未通过。", "required_action": "报告原始p值、校正p值与置信区间。"},
            {"risk": "将模拟陈旧度外推为真实异步联邦", "finding": "当前实现是同步轮次中的历史模型启动，不是真实异步到达系统。", "required_action": "称为受控陈旧更新模拟，并列为外部效度限制。"},
            {"risk": "单数据集单架构外推", "finding": "仍存在。", "required_action": "不得宣称对所有联邦异构环境普遍有效。"},
            {"risk": "把组合流程称为新的优化理论", "finding": "不支持。", "required_action": "仅称优化层协调流程或组合机制。"},
            {"risk": "确认失败后继续使用强可靠性结论", "finding": "禁止。", "required_action": "改为退化机理、代理指标边界与安全结论，或开发真正的新机制后再独立确认。"},
        ],
    }
    (OUT / "sa_gsa_fallacy_scan.json").write_text(json.dumps(fallacy_scan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(verification, ensure_ascii=False, indent=2))
    return 0 if verification["all_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
