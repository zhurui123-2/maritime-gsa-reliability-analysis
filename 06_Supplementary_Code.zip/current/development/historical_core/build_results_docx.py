import hashlib
import json
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


BASE = Path(__file__).resolve().parents[2]
RESULTS = BASE / "experiments" / "results" / "gsa_reliability_rebuild_20260803"
OUT = BASE / "投稿实验重构_20260803" / "GSA投稿实验正式结果与投稿判断.docx"
BLUE = "2E74B5"
DARK = "1F4D78"
LIGHT = "F4F6F9"
PALE_RED = "FCE8E6"
PALE_GREEN = "E8F3ED"
GRAY = "666666"


def set_font(run, name="Calibri", size=10.5, bold=False, color=None, italic=False):
    run.font.name = name
    rfonts = run._element.get_or_add_rPr().rFonts
    rfonts.set(qn("w:ascii"), name)
    rfonts.set(qn("w:hAnsi"), name)
    rfonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=70, start=90, bottom=70, end=90):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for name, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{name}"))
        if node is None:
            node = OxmlElement(f"w:{name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    total = sum(widths)
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(total))
    tbl_w.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        for i, cell in enumerate(row.cells):
            cell.width = Inches(widths[i] / 1440)
            tc_w = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                cell._tc.get_or_add_tcPr().append(tc_w)
            tc_w.set(qn("w:w"), str(widths[i]))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def mark_header_row(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = tr_pr.find(qn("w:tblHeader"))
    if tbl_header is None:
        tbl_header = OxmlElement("w:tblHeader")
        tr_pr.append(tbl_header)
    tbl_header.set(qn("w:val"), "true")


def add_table(doc, headers, rows, widths, status_col=None):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    mark_header_row(table.rows[0])
    for i, header in enumerate(headers):
        shade(table.rows[0].cells[i], LIGHT)
        p = table.rows[0].cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(header), size=8.8, bold=True, color=DARK)
    for values in rows:
        cells = table.add_row().cells
        for i, value in enumerate(values):
            if status_col is not None and i == status_col:
                fill = PALE_GREEN if "支持" in str(value) and "不支持" not in str(value) else PALE_RED
                shade(cells[i], fill)
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if i == 0 else WD_ALIGN_PARAGRAPH.LEFT
            set_font(p.add_run(str(value)), size=8.6)
    set_table_geometry(table, widths)
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)
    return table


def add_body(doc, text, bold_lead=None):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.25
    if bold_lead and text.startswith(bold_lead):
        set_font(p.add_run(bold_lead), bold=True)
        set_font(p.add_run(text[len(bold_lead):]))
    else:
        set_font(p.add_run(text))
    return p


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.line_spacing = 1.2
    set_font(p.add_run(text))
    return p


def add_callout(doc, title, text, fill=PALE_RED):
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    mark_header_row(table.rows[0])
    shade(table.cell(0, 0), fill)
    p = table.cell(0, 0).paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    set_font(p.add_run(title + "："), bold=True, color=DARK)
    set_font(p.add_run(text))
    set_table_geometry(table, [9360])
    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def configure_styles(doc):
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25
    for name, size, color, before, after in (
        ("Heading 1", 15, BLUE, 15, 8),
        ("Heading 2", 12.5, BLUE, 10, 5),
        ("Heading 3", 11.5, DARK, 7, 3),
    ):
        style = doc.styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
    for name in ("List Bullet", "List Number"):
        style = doc.styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        style.font.size = Pt(10.5)


def add_header_footer(section):
    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_font(header.add_run("GSA可靠性机制 | 正式结果与投稿判断"), size=8.5, color=GRAY)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    footer._p.append(field)


def ci(mean, low, high, digits=3):
    return f"{mean:.{digits}f} [{low:.{digits}f}, {high:.{digits}f}]"


def build():
    summary = pd.read_csv(RESULTS / "summary_main.csv").set_index("method")
    paired = pd.read_csv(RESULTS / "paired_method_tests.csv")
    mechanism = pd.read_csv(RESULTS / "mechanism_summary.csv")
    ablation = pd.read_csv(RESULTS / "ablation_summary.csv").set_index("variant")
    robust = pd.read_csv(RESULTS / "robustness_summary.csv")
    assoc = pd.read_csv(RESULTS / "heterogeneity_gradient_association.csv")
    lags = pd.read_csv(RESULTS / "lag_associations.csv")
    verdicts = json.loads((RESULTS / "hypothesis_verdicts.json").read_text(encoding="utf-8"))
    manifest = json.loads((RESULTS / "run_manifest.json").read_text(encoding="utf-8"))

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = Document()
    configure_styles(doc)
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.86)
    section.bottom_margin = Inches(0.86)
    section.left_margin = Inches(0.92)
    section.right_margin = Inches(0.92)
    section.header_distance = Inches(0.42)
    section.footer_distance = Inches(0.42)
    add_header_footer(section)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run("正式实验结果与投稿判断"), size=23, bold=True, color=DARK)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(12)
    set_font(p.add_run("航运联邦多模态知识融合中的梯度谱协调机制（GSA）"), size=12.5, color=GRAY)
    for label, value in (
        ("数据", "1,172艘船舶；AIS、气象、登记与运营/MRV四模态"),
        ("规模", "70个核心运行、25个消融运行、20个参与率重训、20个冻结模型缺失评估"),
        ("重复", "5个配对随机种子（42—46），每次30轮"),
        ("完成时间", "2026年8月3日"),
    ):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(1)
        set_font(p.add_run(label + "："), bold=True, color=DARK)
        set_font(p.add_run(value))

    doc.add_heading("1. 结论先行", level=1)
    add_callout(
        doc,
        "核心判断",
        "当前结果不支持把GSA写成已被验证的“可靠性增强方法”。GSA稳定降低D_spec，但没有改善D_repr、校准、最差客户端或主任务性能。更严谨的表述是：GSA是一种能够改变客户端梯度谱统计的优化层协调机制；其系统级可靠性收益尚未得到验证。",
    )
    add_bullet(doc, "自然船型场景中，GSA相对FedAvg的macro-F1差为+0.0012，95% CI为[-0.0026, +0.0047]。")
    add_bullet(doc, "GSA将聚合后的D_spec降低0.0170，95% CI为[-0.0192, -0.0152]。该机制指标变化稳定。")
    add_bullet(doc, "D_repr反而增加0.00017，95% CI为[0.00007, 0.00029]。谱协调没有传导为更一致的锚点表示。")
    add_bullet(doc, "随机共识和非同源块消融获得相近或更高的任务性能。功能同源性叙事尚未被消融支持。")
    add_bullet(doc, "MIA AUROC差为-0.0014，区间跨0。训练时间平均增加4.52秒，约44.6%。")

    doc.add_heading("2. 实验执行与数据完整性", level=1)
    add_body(doc, "每个随机种子按船舶实体划分761个训练样本、176个锚点验证样本和235个测试样本。排放分位阈值、标准化、缺失填补和类别编码均只在训练集拟合。直接燃料、CO2、CO2eq及派生排放字段未进入模型输入。")
    add_body(doc, "核心实验覆盖IID、三档Dirichlet异构和自然船型异构。自然船型场景比较Local-only、FedAvg、FedProx、FedBN、SCAFFOLD和GSA。运行清单状态为COMPLETED。逐轮日志共2,250行。十个自然场景检查点已保存。")
    add_table(doc, ["证据层", "数量", "完整性判断"], [
        ("核心实验", "70", "5种子、方法与异构设置键唯一"),
        ("机制消融", "25", "5个消融变体×5种子"),
        ("鲁棒性", "40", "参与率重训20行；模态缺失评估20行"),
        ("逐轮轨迹", "2,250", "用于D_spec、D_repr和NLL滞后分析"),
        ("模型检查点", "10", "自然场景FedAvg/GSA各5个"),
    ], [1600, 1200, 6560])

    doc.add_heading("3. 预注册假设判定", level=1)
    v = verdicts
    add_table(doc, ["假设", "判定", "直接证据", "可写范围"], [
        ("H1", v["H1"]["status"], f"种子内严重度—D_spec的Spearman均值={v['H1']['mean_seed_spearman']:.2f}", "可写方向性关联，不写普遍规律"),
        ("H2", v["H2"]["status"], f"FedAvg滞后ρ：D_repr={v['H2']['fedavg_lag_rho_drepr']:.3f}；ΔNLL={v['H2']['fedavg_lag_rho_nll_change']:.3f}", "不能写D_spec导致表示退化"),
        ("H3", v["H3"]["status"], "D_spec显著下降；D_repr略升；macro-F1区间跨0", "只写机制指标缓解，不写可靠性提升"),
        ("H4", v["H4"]["status"], "MIA差异不可分辨；墙钟时间增加", "写安全—工程权衡，不写隐私改善"),
    ], [760, 1800, 3860, 2940], status_col=1)

    doc.add_heading("4. 自然船型场景的主结果", level=1)
    method_names = {"local": "Local-only", "fedavg": "FedAvg", "fedprox": "FedProx", "fedbn": "FedBN", "scaffold": "SCAFFOLD", "gsa": "GSA"}
    rows = []
    for key in ["local", "fedavg", "fedprox", "fedbn", "scaffold", "gsa"]:
        r = summary.loc[key]
        rows.append((
            method_names[key],
            ci(r.macro_f1_mean, r.macro_f1_ci95_low, r.macro_f1_ci95_high),
            f"{r.nll_mean:.3f}",
            ci(r.worst_client_macro_f1_mean, r.worst_client_macro_f1_ci95_low, r.worst_client_macro_f1_ci95_high),
            f"{r.wall_seconds_mean:.2f}",
        ))
    add_table(doc, ["方法", "macro-F1 [95% CI]", "NLL", "最差客户端F1 [95% CI]", "时间/s"], rows, [1350, 2500, 900, 3010, 1600])
    add_body(doc, "Local-only的总体macro-F1最高，但最差客户端并未同步改善。这说明自然船型客户端存在强专属性。该结果不能被解释为联邦共享无条件有益，也不能用Local-only的总体优势替代跨客户端公平性判断。")
    add_body(doc, "GSA与FedAvg的总体性能接近。GSA的NLL和Brier略差，最差客户端F1也略低。所有自然场景配对差异均应结合区间解释。五个配对种子的精确双侧符号检验最小p值为0.0625，因此本研究不能依赖p<0.05作二元判断。")

    doc.add_heading("5. 异构性与性能方向", level=1)
    task_rows = []
    labels = {"iid": "IID", "dirichlet_1.0": "Dirichlet α=1.0", "dirichlet_0.3": "Dirichlet α=0.3", "dirichlet_0.1": "Dirichlet α=0.1", "natural_ship_type": "自然船型"}
    for setting in labels:
        r = paired[(paired.setting == setting) & (paired.metric == "macro_f1")].iloc[0]
        task_rows.append((labels[setting], f"{r.control_mean:.4f}", f"{r.treatment_mean:.4f}", f"{r.mean_difference:+.4f}", f"[{r.ci95_low:+.4f}, {r.ci95_high:+.4f}]"))
    add_table(doc, ["设置", "FedAvg", "GSA", "差值", "95% CI"], task_rows, [2100, 1300, 1300, 1300, 3360])
    add_body(doc, "GSA的任务收益不随异构程度单调变化。Dirichlet α=1.0为正，α=0.3为负，α=0.1接近零。由此不能声称“异构越强，GSA收益越大”。")
    add_body(doc, f"五个种子内，受控异构严重度与FedAvg平均D_spec的Spearman相关分别为{', '.join(f'{x:.1f}' for x in assoc.spearman_severity_dspec)}，均值为{assoc.spearman_severity_dspec.mean():.2f}。方向总体为正，但种子间波动明显。H1只能获得有限支持。")

    doc.add_heading("6. 机制链检验", level=1)
    nat_f = mechanism[(mechanism.setting == "natural_ship_type") & (mechanism.method == "fedavg")].iloc[0]
    nat_g = mechanism[(mechanism.setting == "natural_ship_type") & (mechanism.method == "gsa")].iloc[0]
    add_table(doc, ["指标", "FedAvg", "GSA", "判断"], [
        ("D_spec（协调前）", f"{nat_f.d_spec_before_mean:.5f}", f"{nat_g.d_spec_before_mean:.5f}", "起点接近"),
        ("D_spec（协调后）", f"{nat_f.d_spec_after_mean:.5f}", f"{nat_g.d_spec_after_mean:.5f}", "GSA稳定降低"),
        ("D_repr", f"{nat_f.d_repr_mean:.5f}", f"{nat_g.d_repr_mean:.5f}", "GSA略高"),
        ("验证NLL轮间标准差", f"{nat_f.validation_nll_std_mean:.5f}", f"{nat_g.validation_nll_std_mean:.5f}", "差异很小"),
        ("方向余弦", "1.00000", f"{nat_g.direction_cosine_mean:.5f}", "方向约束未触发边界"),
    ], [2500, 1700, 1700, 3460])
    add_body(doc, "机制链要求D_spec的变化先传导到D_repr或训练稳定性，再传导到任务性能。当前结果只满足第一步。D_repr未下降，任务收益也不可分辨。")
    fedavg_lag = lags[(lags.method == "fedavg") & (lags.outcome == "next_d_repr")].spearman_rho.mean()
    fedavg_nll_lag = lags[(lags.method == "fedavg") & (lags.outcome == "next_nll_change")].spearman_rho.mean()
    add_body(doc, f"FedAvg中，D_spec(t)与D_repr(t+1)的种子平均Spearman ρ为{fedavg_lag:.3f}；与下一轮NLL变化的平均ρ为{fedavg_nll_lag:.3f}。方向不稳定，且个别种子结果相反。因此H2不成立。")

    doc.add_heading("7. 消融与反证性结果", level=1)
    variant_names = {"gsa": "完整GSA", "no_ema": "无EMA", "no_direction_bound": "无方向界", "random_consensus": "随机共识", "nonhomologous": "非同源块", "norm_only": "仅范数对齐"}
    rows = []
    for key in ["gsa", "no_ema", "no_direction_bound", "random_consensus", "nonhomologous", "norm_only"]:
        r = ablation.loc[key]
        rows.append((variant_names[key], f"{r.macro_f1_mean:.4f}", f"{r.d_spec_after_mean:.5f}", f"{r.d_repr_mean:.5f}", f"{r.direction_cosine_mean:.4f}"))
    add_table(doc, ["变体", "macro-F1", "D_spec后", "D_repr", "方向余弦"], rows, [2300, 1500, 1700, 1700, 2160])
    add_callout(doc, "反证结论", "无方向界与完整GSA结果相同，说明本设置中方向界没有发挥实际作用。随机共识和非同源块没有导致任务性能崩溃，甚至略高于完整GSA。现有消融不能证明共享谱、功能同源映射或回投影是任务收益的必要来源。")
    add_body(doc, "仅范数对齐无法降低归一化D_spec，macro-F1也较低。这一结果说明谱形状处理与范数校准并不等价。但它不能反向证明完整GSA的全部模块有效。")

    doc.add_heading("8. 鲁棒性、MIA与工程代价", level=1)
    robust_rows = []
    for participation, missing, label in [(0.8, 0.0, "参与率0.8"), (0.6, 0.0, "参与率0.6"), (1.0, 0.2, "模态缺失0.2"), (1.0, 0.4, "模态缺失0.4")]:
        f = robust[(robust.method == "fedavg") & (robust.participation == participation) & (robust.missing_rate == missing)].iloc[0]
        g = robust[(robust.method == "gsa") & (robust.participation == participation) & (robust.missing_rate == missing)].iloc[0]
        robust_rows.append((label, f"{f.macro_f1_mean:.4f}", f"{g.macro_f1_mean:.4f}", f"{g.macro_f1_mean-f.macro_f1_mean:+.4f}", f"{f.worst_client_macro_f1_mean:.4f}/{g.worst_client_macro_f1_mean:.4f}"))
    add_table(doc, ["压力条件", "FedAvg F1", "GSA F1", "差值", "最差客户端 FedAvg/GSA"], robust_rows, [1900, 1450, 1450, 1300, 3260])
    add_body(doc, "GSA在低参与率和模态缺失下呈现小幅平均收益，但最差客户端没有一致改善。结果可作为稳健性描述，不能独立支撑可靠性增强。")
    f = summary.loc["fedavg"]
    g = summary.loc["gsa"]
    mia = paired[(paired.setting == "natural_ship_type") & (paired.metric == "mia_auroc")].iloc[0]
    wall = paired[(paired.setting == "natural_ship_type") & (paired.metric == "wall_seconds")].iloc[0]
    add_body(doc, f"黑盒MIA AUROC由FedAvg的{f.mia_auroc_mean:.4f}变为GSA的{g.mia_auroc_mean:.4f}。配对差为{mia.mean_difference:+.4f}，95% CI为[{mia.ci95_low:+.4f}, {mia.ci95_high:+.4f}]。该实验没有发现可分辨的隐私风险变化，也不构成隐私保证。")
    overhead_pct = wall.mean_difference / wall.control_mean * 100
    add_body(doc, f"GSA平均训练时间由{wall.control_mean:.2f}秒增加至{wall.treatment_mean:.2f}秒，增幅约{overhead_pct:.1f}%。SVD耗时占GSA总时间的{g.svd_share_mean*100:.1f}%。当前实现不增加每轮通信量，因为协调完全发生在服务器侧。")

    doc.add_heading("9. 投稿表述边界", level=1)
    add_table(doc, ["不宜使用", "可审计替代表述"], [
        ("GSA显著提高联邦知识融合可靠性", "GSA稳定降低客户端梯度谱差异，但下游可靠性收益尚未得到验证"),
        ("梯度谱不一致导致表示退化", "梯度谱差异与表示分歧的滞后关系在本实验中不稳定"),
        ("共享谱空间和同源回投影是性能来源", "当前消融未证明这些模块是任务收益的必要来源"),
        ("GSA改善隐私安全", "匹配黑盒MIA未发现可分辨差异；GSA增加计算开销"),
        ("航运安全风险得到改善", "本研究任务是排放五分类知识融合，不是事故或险情预测"),
    ], [4300, 5060])
    add_body(doc, "如果维持当前方法与任务，建议将论文收窄为“梯度谱协调的诊断与负/中性系统结果”。如果仍以可靠性增强为核心主张，需要修改方法或下游任务，并重新冻结实验。新实验应优先建立能够被D_spec改善所影响的可审计可靠性终点。")
    add_body(doc, "旧版跨模态投影器实验未与本轮结果合并。旧实现与当前稿件中的客户端参数块SVD机制不是同一方法。混报会造成定义漂移。")

    doc.add_heading("10. 可复现性清单", level=1)
    main_hash = hashlib.sha256((RESULTS / "main_results.csv").read_bytes()).hexdigest()
    add_table(doc, ["对象", "位置或标识"], [
        ("运行脚本", str(BASE / "experiments" / "gsa_reliability_rebuild" / "run_rebuilt_experiments.py")),
        ("统计脚本", str(BASE / "experiments" / "gsa_reliability_rebuild" / "analyze_results.py")),
        ("完整性核验", str(BASE / "experiments" / "gsa_reliability_rebuild" / "verify_experiment_outputs.py")),
        ("冻结配置", str(BASE / "experiments" / "gsa_reliability_rebuild" / "config.json")),
        ("原始结果", str(RESULTS)),
        ("主结果SHA-256", main_hash),
        ("生成说明", "由CSV、逐轮日志和运行清单自动生成；不含手工抄录或未运行比较"),
    ], [2100, 7260])

    doc.core_properties.title = "GSA投稿实验正式结果与投稿判断"
    doc.core_properties.subject = "航运联邦多模态知识融合可靠性机制实验"
    doc.core_properties.author = "Codex实验重构"
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
