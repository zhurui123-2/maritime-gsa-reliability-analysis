from __future__ import annotations

import argparse
import copy
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
import run_rebuilt_experiments as base  # noqa: E402
from run_reliability_v2 import (  # noqa: E402
    measure_client_models,
    models_from_updates,
)


OUT = ROOT / "experiments" / "results" / "gsa_reliability_confirmatory_20260804"
DATA_PATH = ROOT / "final_four_modal_dataset.csv"
STRESS_ROUNDS = set(range(11, 21))
MEASUREMENT_ROUNDS = {10, 11, 15, 20, 21, 25, 30}
SCENARIOS = ["clean", "stale_moderate", "stale_severe", "modality_heterogeneity", "client_dropout"]
CORE_METHODS = ["fedavg", "fedprox", "gsa"]


def phase_for_round(round_idx: int, scenario: str) -> str:
    if scenario == "clean":
        return "clean"
    if round_idx <= 10:
        return "clean"
    if round_idx <= 20:
        return "stress"
    return "recovery"


def delay_profile(round_idx: int, scenario: str) -> list[int]:
    if round_idx not in STRESS_ROUNDS:
        return [0, 0, 0, 0, 0]
    if scenario == "stale_moderate":
        return [0, 1, 2, 3, 4]
    if scenario == "stale_severe":
        return [0, 2, 4, 6, 8]
    return [0, 0, 0, 0, 0]


def modality_profile(round_idx: int, scenario: str) -> list[list[float]]:
    all_present = [[1.0, 1.0, 1.0, 1.0] for _ in range(5)]
    if scenario != "modality_heterogeneity" or round_idx not in STRESS_ROUNDS:
        return all_present
    # Modality order is [AIS, weather, operations, registry]. One client remains intact.
    return [
        [1.0, 1.0, 1.0, 1.0],
        [1.0, 0.0, 1.0, 1.0],
        [1.0, 1.0, 1.0, 0.0],
        [0.0, 1.0, 1.0, 1.0],
        [1.0, 0.0, 0.0, 1.0],
    ]


def active_clients(round_idx: int, scenario: str, seed: int) -> list[int]:
    if scenario != "client_dropout" or round_idx not in STRESS_ROUNDS:
        return list(range(5))
    rng = np.random.default_rng(seed * 10000 + round_idx)
    return sorted(rng.choice(5, size=3, replace=False).tolist())


def local_train_masked(
    starting_model: base.MultiModalNet,
    prepared: base.Prepared,
    indices: np.ndarray,
    device: torch.device,
    cfg: dict[str, Any],
    method: str,
    seed: int,
    modality_mask: list[float],
) -> tuple[base.MultiModalNet, int, int]:
    model = copy.deepcopy(starting_model).to(device)
    reference = {name: p.detach().clone() for name, p in starting_model.named_parameters()}
    model.train()
    optimizer = torch.optim.SGD(
        model.parameters(),
        lr=float(cfg["learning_rate"]),
        weight_decay=float(cfg["weight_decay"]),
    )
    steps = 0
    for epoch in range(int(cfg["local_epochs"])):
        loader = base.make_loader(prepared, indices, int(cfg["batch_size"]), True, seed + epoch)
        for batch in loader:
            x, y, _ = base.batch_to_device(batch, device)
            mask = torch.tensor(modality_mask, dtype=torch.float32, device=device).repeat(len(y), 1)
            optimizer.zero_grad(set_to_none=True)
            logits, _ = model(x, mask)
            loss = F.cross_entropy(logits, y)
            if method == "fedprox":
                prox = torch.zeros((), device=device)
                for name, parameter in model.named_parameters():
                    prox = prox + (parameter - reference[name].to(device)).square().sum()
                loss = loss + 0.5 * float(cfg["fedprox_mu"]) * prox
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            steps += 1
    return model, len(indices), steps


def diagnostics_without_gsa(
    updates: list[dict[str, torch.Tensor]],
    blocks: list[str],
    cfg: dict[str, Any],
) -> dict[str, float]:
    d_before, _ = base.d_spec(
        updates,
        blocks,
        int(cfg["gsa"]["descriptor_bins"]),
        int(cfg["gsa"]["rank_cap"]),
    )
    return {
        "d_spec_before": d_before,
        "d_spec_after": d_before,
        "actual_alpha": 0.0,
        "direction_cosine": 1.0,
        "fallback_rate": 0.0,
    }


def aggregate_weighted(
    model: base.MultiModalNet,
    updates: list[dict[str, torch.Tensor]],
    counts: list[int],
    delays: list[int],
    method: str,
) -> None:
    if method != "staleness_decay":
        base.aggregate_updates(model, updates, counts, "fedavg")
        return
    state = model.state_dict()
    weights = np.asarray(counts, dtype=float) / (1.0 + np.asarray(delays, dtype=float))
    weights /= weights.sum()
    for key, value in state.items():
        if not torch.is_floating_point(value) or key not in updates[0]:
            continue
        delta = sum(float(weight) * update[key].to(value.device) for weight, update in zip(weights, updates))
        state[key] = value + delta
    model.load_state_dict(state, strict=True)


def run_one(
    prepared: base.Prepared,
    scenario: str,
    method: str,
    seed: int,
    cfg: dict[str, Any],
    device: torch.device,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    base.seed_all(seed)
    train_parts = base.natural_partition(prepared.train_idx, prepared.nodes)
    test_parts = base.natural_partition(prepared.test_idx, prepared.nodes)
    model = base.MultiModalNet(
        prepared.dims,
        int(cfg["hidden_dim"]),
        int(cfg["embedding_dim"]),
        float(cfg["dropout"]),
    ).to(device)
    coordinator = base.GSACoordinator(copy.deepcopy(cfg["gsa"]), "gsa") if method == "gsa" else None
    model_history = [base.clone_state(model)]
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()

    for round_idx in range(1, int(cfg["rounds"]) + 1):
        delays_all = delay_profile(round_idx, scenario)
        masks_all = modality_profile(round_idx, scenario)
        participants = active_clients(round_idx, scenario, seed)
        local_method = "fedprox" if method == "fedprox" else "fedavg"
        local_models: list[base.MultiModalNet] = []
        counts: list[int] = []
        delays: list[int] = []
        steps: list[int] = []

        for client_idx in participants:
            delay = delays_all[client_idx]
            history_index = max(0, len(model_history) - 1 - delay)
            starting_model = copy.deepcopy(model)
            starting_model.load_state_dict(model_history[history_index], strict=True)
            local, count, step_count = local_train_masked(
                starting_model,
                prepared,
                train_parts[client_idx],
                device,
                cfg,
                local_method,
                seed + round_idx * 100 + client_idx,
                masks_all[client_idx],
            )
            local_models.append(local)
            counts.append(count)
            delays.append(delay)
            steps.append(step_count)

        updates = base.state_updates(model, local_models)
        blocks = model.registered_blocks()
        if round_idx in MEASUREMENT_ROUNDS:
            d_repr_pre, d_pred_pre = measure_client_models(
                local_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
            )
        else:
            d_repr_pre, d_pred_pre = float("nan"), float("nan")

        if coordinator is None:
            corrected = updates
            diagnostics = diagnostics_without_gsa(updates, blocks, cfg)
        else:
            corrected, diagnostics = coordinator.coordinate(updates, blocks)

        if round_idx in MEASUREMENT_ROUNDS:
            post_models = models_from_updates(model, corrected)
            d_repr_post, d_pred_post = measure_client_models(
                post_models, prepared, prepared.anchor_idx, device, cfg, seed + round_idx
            )
        else:
            d_repr_post, d_pred_post = float("nan"), float("nan")

        aggregate_weighted(model, corrected, counts, delays, method)
        model_history.append(base.clone_state(model))
        validation = base.evaluate_model(
            model,
            prepared,
            prepared.anchor_idx,
            device,
            int(cfg["batch_size"]),
            seed=seed + round_idx,
        )
        rows.append(
            {
                "scenario": scenario,
                "method": method,
                "seed": seed,
                "round": round_idx,
                "phase": phase_for_round(round_idx, scenario),
                "active_clients": json.dumps(participants),
                "participation_rate": len(participants) / 5.0,
                "staleness_delays": json.dumps(delays_all),
                "training_modality_masks": json.dumps(masks_all),
                "local_steps": json.dumps(steps),
                "d_spec_before": diagnostics["d_spec_before"],
                "d_spec_after": diagnostics["d_spec_after"],
                "d_repr_pre": d_repr_pre,
                "d_repr_post": d_repr_post,
                "d_pred_pre": d_pred_pre,
                "d_pred_post": d_pred_post,
                "validation_nll": validation["nll"],
                "validation_brier": validation["brier"],
                "validation_ece": validation["ece"],
                "validation_macro_f1": validation["macro_f1"],
                "actual_alpha": diagnostics["actual_alpha"],
                "direction_cosine": diagnostics["direction_cosine"],
                "fallback_rate": diagnostics.get("fallback_rate", 0.0),
            }
        )

    test_metrics, client_f1 = base.evaluate_per_clients(
        model, prepared, test_parts, device, cfg, None, 0.0, seed
    )
    result = {
        "scenario": scenario,
        "method": method,
        "seed": seed,
        **test_metrics,
        "client_macro_f1": json.dumps(client_f1),
        "wall_seconds": time.perf_counter() - started,
    }
    return pd.DataFrame(rows), result


def methods_for_scenario(scenario: str) -> list[str]:
    methods = list(CORE_METHODS)
    if scenario.startswith("stale_"):
        methods.append("staleness_decay")
    return methods


def valid_pair(scenario: str, method: str) -> bool:
    return method in methods_for_scenario(scenario)


def combine_outputs(run_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    round_files = sorted(run_dir.glob("*.rounds.csv"))
    result_files = sorted(run_dir.glob("*.result.json"))
    rounds = pd.concat([pd.read_csv(path) for path in round_files], ignore_index=True)
    results = pd.DataFrame([json.loads(path.read_text(encoding="utf-8")) for path in result_files])
    return rounds, results


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--seeds", nargs="*", type=int, default=list(range(47, 57)))
    parser.add_argument("--scenarios", nargs="*", choices=SCENARIOS, default=SCENARIOS)
    parser.add_argument(
        "--methods",
        nargs="*",
        choices=CORE_METHODS + ["staleness_decay"],
        default=CORE_METHODS + ["staleness_decay"],
    )
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    cfg = base.load_config()
    cfg["data_path"] = str(DATA_PATH)
    cfg["rounds"] = 30
    cfg["local_epochs"] = 1
    device = torch.device(args.device)
    OUT.mkdir(parents=True, exist_ok=True)
    run_dir = OUT / "runs"
    run_dir.mkdir(exist_ok=True)
    frame = pd.read_csv(DATA_PATH)
    jobs = [
        (seed, scenario, method)
        for seed in args.seeds
        for scenario in args.scenarios
        for method in args.methods
        if valid_pair(scenario, method)
    ]
    manifest_path = OUT / "confirmatory_manifest.json"
    manifest = {
        "status": "RUNNING",
        "started_at": pd.Timestamp.utcnow().isoformat(),
        "device": str(device),
        "seeds": args.seeds,
        "scenarios": args.scenarios,
        "methods": args.methods,
        "n_jobs": len(jobs),
        "frozen_gsa": cfg["gsa"],
        "primary_outcome": "sum of per-round NLL stress minus matched clean trajectory over rounds 11-20",
        "recovery_outcome": "sum of per-round NLL stress minus matched clean trajectory over rounds 21-30",
        "clean_noninferiority_margins": {"nll": 0.01, "macro_f1": -0.01},
        "primary_stressors": ["stale_moderate", "modality_heterogeneity", "client_dropout"],
        "secondary_stressor": "stale_severe",
        "notes": [
            "Seeds 47-56 were not used in exploratory stages.",
            "No GSA hyperparameter is tuned in this confirmatory run.",
            "staleness_decay is a synchronous staleness-aware comparator, not labeled FedAsync.",
        ],
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    completed = 0
    try:
        for job_index, (seed, scenario, method) in enumerate(jobs, start=1):
            stem = f"{scenario}__{method}__seed{seed}"
            round_path = run_dir / f"{stem}.rounds.csv"
            result_path = run_dir / f"{stem}.result.json"
            if not args.force and round_path.exists() and result_path.exists():
                completed += 1
                print(f"SKIP {job_index}/{len(jobs)} {stem}", flush=True)
                continue
            print(f"RUN {job_index}/{len(jobs)} {stem}", flush=True)
            prepared = base.prepare_data(frame, seed)
            rounds, result = run_one(prepared, scenario, method, seed, cfg, device)
            rounds.to_csv(round_path, index=False, encoding="utf-8-sig")
            result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            completed += 1
        round_frame, result_frame = combine_outputs(run_dir)
        round_frame.to_csv(OUT / "confirmatory_round_metrics.csv", index=False, encoding="utf-8-sig")
        result_frame.to_csv(OUT / "confirmatory_test_results.csv", index=False, encoding="utf-8-sig")
        manifest["status"] = "COMPLETED"
        manifest["completed_at"] = pd.Timestamp.utcnow().isoformat()
        manifest["completed_jobs"] = completed
        manifest["counts"] = {"round_rows": len(round_frame), "test_rows": len(result_frame)}
    except Exception as exc:
        manifest["status"] = "FAILED"
        manifest["failed_at"] = pd.Timestamp.utcnow().isoformat()
        manifest["completed_jobs"] = completed
        manifest["error"] = repr(exc)
        raise
    finally:
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUT, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
