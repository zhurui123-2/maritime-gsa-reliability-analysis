from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT = Path(r"E:\航运实验\投稿实验重构_20260803\GSA投稿实验重构方案.docx")
BLUE = "2E74B5"
DARK = "1F4D78"
LIGHT = "F4F6F9"
GRAY = "666666"


def set_font(run, name="Calibri", size=11, bold=False, color=None, italic=False):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def shade(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    total = sum(widths)
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(total))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        for i, cell in enumerate(row.cells):
            cell.width = Inches(widths[i] / 1440)
            tc_w = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                cell._tc.get_or_add_tcPr().append(tc_w)
            tc_w.set(qn("w:w"), str(widths[i]))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def mark_header_row(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = tr_pr.find(qn("w:tblHeader"))
    if tbl_header is None:
        tbl_header = OxmlElement("w:tblHeader")
        tr_pr.append(tbl_header)
    tbl_header.set(qn("w:val"), "true")


def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    mark_header_row(table.rows[0])
    set_table_geometry(table, widths)
    for i, h in enumerate(headers):
        shade(table.rows[0].cells[i], LIGHT)
        p = table.rows[0].cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(h)
        set_font(r, size=9.5, bold=True, color=DARK)
    for values in rows:
        cells = table.add_row().cells
        for i, value in enumerate(values):
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if i == 0 else WD_ALIGN_PARAGRAPH.LEFT
            r = p.add_run(str(value))
            set_font(r, size=9.3)
    set_table_geometry(table, widths)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def add_bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.208
    r = p.add_run(text)
    set_font(r)
    return p


def add_body(doc, text, bold_lead=None):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_after = Pt(8)
    p.paragraph_format.line_spacing = 1.333
    if bold_lead and text.startswith(bold_lead):
        r = p.add_run(bold_lead)
        set_font(r, bold=True)
        r = p.add_run(text[len(bold_lead):])
        set_font(r)
    else:
        r = p.add_run(text)
        set_font(r)
    return p


def configure_styles(doc):
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(8)
    normal.paragraph_format.line_spacing = 1.333
    for name, size, color, before, after in (
        ("Heading 1", 16, BLUE, 18, 10),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK, 8, 4),
    ):
        style = doc.styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
    for name in ("List Bullet", "List Number"):
        style = doc.styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        style.font.size = Pt(11)


def add_header_footer(section):
    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = header.add_run("GSA可靠性机制 | 投稿实验重构方案")
    set_font(r, size=9, color=GRAY)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    footer._p.append(fld)


def build():
    doc = Document()
    configure_styles(doc)
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)
    add_header_footer(section)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run("投稿实验重构方案")
    set_font(r, size=24, bold=True, color=DARK)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(14)
    r = p.add_run("航运联邦多模态知识融合中的可靠性退化与梯度谱协调机制")
    set_font(r, size=13, color=GRAY)
    meta = [
        ("研究对象", "1,172艘已完成实体关联的船舶；AIS、气象、登记和MRV/运营信息"),
        ("主任务", "无安全代理标签的多模态知识融合：总CO2排放五分类预测"),
        ("核心机制", "客户端异构性—梯度谱差异—表示/训练稳定性—任务收益"),
        ("冻结日期", "2026年8月3日"),
    ]
    for label, value in meta:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(f"{label}：")
        set_font(r, bold=True, color=DARK)
        r = p.add_run(value)
        set_font(r)

    doc.add_heading("1. 重构结论与研究边界", level=1)
    add_body(doc, "本次实验不再把旧版跨模态投影器结果直接套入新稿。新稿中的GSA是一种优化层协调机制。它对客户端的功能同源参数块进行谱描述、稳健共识、有界校准和原空间回投影。实验必须围绕该定义重新运行。")
    add_body(doc, "主任务不采用未经领域确认的安全风险代理标签。现有数据没有可审计的事故或险情标签。为避免把构造标签写成真实安全结论，主实验改为多模态知识融合任务。模型预测由训练集阈值定义的总CO2排放五分类。所有直接燃料、CO2、CO2eq和派生强度字段均从输入中排除。")
    add_bullet(doc, "船型客户端只用于模拟具有运行含义的分布异构，不等同于真实公司或监管机构。")
    add_bullet(doc, "知识融合任务支持机制研究，但不支持“航运安全系统已经获得事故风险改善”的结论。")
    add_bullet(doc, "所有阈值、数据划分、随机种子和超参数在运行前冻结；结果方向不能反向修改研究假设。")

    doc.add_heading("2. 研究问题与预注册假设", level=1)
    add_table(doc, ["编号", "可检验问题", "判定指标"], [
        ("H1", "异构增强是否提高优化演化不一致？", "FedAvg的D_spec均值、轮间波动及异构斜率"),
        ("H2", "谱差异是否先于表示分歧和训练波动？", "D_spec(t)与D_repr(t+1)、NLL波动的滞后关联"),
        ("H3", "GSA是否优先缓解机制指标，并在强异构下减少退化？", "D_spec、D_repr、最差客户端macro-F1和退化率"),
        ("H4", "可靠性收益是否伴随安全暴露或工程代价？", "MIA AUROC、墙钟时间、SVD耗时和通信量"),
    ], [900, 5220, 3240])

    doc.add_heading("3. 数据、任务与无泄漏划分", level=1)
    doc.add_heading("3.1 数据审计", level=2)
    add_body(doc, "最终表包含1,172条船舶级记录，MMSI唯一率为100%。AIS、气象、登记和MRV模态覆盖率均为100%。五个自然客户端为bulk 272、container 162、general cargo 189、passenger 70和tanker 479。样本量变异系数为0.590。各客户端排放五分位分布与全局分布的Jensen-Shannon散度为0.008至0.159，说明自然划分同时包含样本量和标签分布异构。")
    doc.add_heading("3.2 任务定义与泄漏控制", level=2)
    add_body(doc, "标签由训练集total_co2_emissions_tonnes的五分位点生成。验证集与测试集只应用训练阈值。输入包含AIS运动统计、匹配气象、登记特征和运营时长。total_fuel、CO2、CO2eq、fuel/co2 per distance、co2 per hour及其派生字段全部排除。")
    add_body(doc, "划分以船舶实体为单位。每个种子使用65%训练、15%验证锚点和20%测试。验证锚点不参与本地训练，用于每轮D_repr和早停评估。标准化、缺失值填补、类别编码和标签阈值只在训练集拟合。")

    doc.add_heading("4. 模型、协调块与公平性", level=1)
    add_body(doc, "所有方法共享相同的四模态编码器、门控融合层和五分类任务头。每个模态先经两层MLP投影到16维表示。融合层根据模态掩码生成归一化权重。GSA不改变编码器、融合层或任务头。")
    add_body(doc, "登记块包括各模态适配器的输出投影矩阵、融合投影矩阵和分类头矩阵。只有同一参数名、同一功能的客户端更新进入同一块比较。非同源块消融会故意打乱块映射，用于证伪。")
    add_table(doc, ["方法", "作用环节", "公平性约束"], [
        ("Local-only", "各客户端独立训练", "同一客户端数据、相同本地更新总量"),
        ("FedAvg", "样本量加权聚合", "作为未协调主对照"),
        ("FedProx", "本地目标加入近端项", "μ预先固定为0.01"),
        ("FedBN", "BN统计与仿射参数本地保留", "其余参数按FedAvg聚合"),
        ("SCAFFOLD", "控制变量校正客户端漂移", "相同通信轮次和本地epoch"),
        ("FedAvg+GSA", "聚合前的有界谱协调", "模型容量、划分和训练预算不变"),
    ], [1500, 3300, 4560])

    doc.add_heading("5. 实验矩阵", level=1)
    add_table(doc, ["阶段", "对照与操纵", "主要输出"], [
        ("A 退化识别", "FedAvg；IID、Dirichlet α=1.0/0.3/0.1、自然船型", "D_spec异构斜率、D_repr、NLL波动"),
        ("B 方法比较", "自然船型；六种核心方法；5个相同种子", "macro-F1、balanced accuracy、NLL、Brier、最差客户端"),
        ("C 机制消融", "无EMA、无方向界、随机共识、非同源块、范数对齐", "D_spec优先改善与失败路径"),
        ("D 鲁棒性", "模态缺失0/0.2/0.4；参与率1/0.8/0.6", "性能退化率、最差客户端斜率"),
        ("E 安全与开销", "匹配黑盒MIA；服务器侧SVD计时", "MIA AUROC、时间增幅、通信变化"),
    ], [1300, 4480, 3580])
    add_body(doc, "计算预算优先保证5个随机种子和配对设计。阶段A、B和核心GSA对比使用5个种子。消融和敏感性若资源不足，可先运行3个种子作为机制筛查，但不能与正式5种子结果混报。")

    doc.add_heading("6. GSA冻结参数与审计量", level=1)
    add_table(doc, ["项目", "冻结值", "审计目的"], [
        ("谱描述符", "8个累计秩区间，截断秩上限8", "统一不同矩阵大小的能量轮廓"),
        ("共识", "按坐标中位数；EMA β=0.80", "降低大客户端支配和轮间噪声"),
        ("校准强度", "α=0.35；每次不满足约束则减半", "避免固定强校准"),
        ("方向约束", "τ=0.90；最低α=0.021875", "限制校准后更新方向偏转"),
        ("执行间隔", "h=1轮", "完整观察机制演化"),
        ("记录项", "实际α、方向余弦、回退率、SVD时间", "确保机制可审计"),
    ], [1800, 3300, 4260])

    doc.add_heading("7. 指标与统计分析", level=1)
    add_body(doc, "机制指标包括D_spec、校准前后D_spec、D_repr、滚动验证NLL方差、跨客户端macro-F1方差、最差客户端macro-F1和跨种子变异。任务指标包括macro-F1、balanced accuracy、NLL、Brier score和ECE。")
    add_body(doc, "所有主比较按相同种子配对。报告均值、标准差、95% bootstrap置信区间、配对置换检验和标准化配对效应量。同一研究问题内采用Holm校正。D_spec(t)与D_repr(t+1)及NLL波动使用分种子Spearman相关，再对Fisher z进行汇总。该分析只解释时序关联，不写成因果中介。")
    add_body(doc, "成员推断使用loss、最大置信度和熵。成员与非成员按船型和标签匹配。攻击模型的训练/测试划分与目标模型划分分离。只报告固定威胁模型下的AUROC与advantage，不宣称隐私保证。")

    doc.add_heading("8. 预设判定规则与收窄路径", level=1)
    add_bullet(doc, "若异构增强未提高FedAvg的D_spec，H1不支持，论文不得把谱差异写成主要退化源。")
    add_bullet(doc, "若GSA降低D_spec但D_repr、稳定性和任务指标均不改善，只能称为描述性谱整齐化。")
    add_bullet(doc, "若随机共识或非同源块取得相近改善，功能同源谱协调解释不成立。")
    add_bullet(doc, "若无方向界获得更低D_spec但任务恶化，可支持有界校准的必要性；不能据此声称完整GSA普遍最优。")
    add_bullet(doc, "若MIA AUROC上升，必须把结果写成可靠性—安全权衡；若下降，也只能解释为该威胁模型下的协同收益。")

    doc.add_heading("9. 可复现性与交付", level=1)
    add_body(doc, "运行目录保存冻结配置、数据SHA-256、软件/硬件环境、每轮日志、每种子检查点、原始CSV、统计汇总和异常记录。实验代码与结果文档均由同一输出目录生成。任何失败或资源缩减都会在结果Word中单列，不以补跑结果替换原始失败记录。")
    add_body(doc, "本方案通过后，执行顺序为：数据与泄漏审计 → 退化识别 → 核心方法比较 → 消融与证伪 → 鲁棒性 → MIA与开销 → 配对统计 → 结果Word。")

    doc.core_properties.title = "GSA投稿实验重构方案"
    doc.core_properties.subject = "可靠性退化识别、梯度谱协调、消融、鲁棒性、安全权衡与工程开销"
    doc.core_properties.author = "Research workflow"
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build()
