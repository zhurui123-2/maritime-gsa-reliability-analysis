from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / "experiments" / "results" / "gsa_reliability_confirmatory_20260804"
REPORT_DIR = ROOT / "投稿实验重构_20260803"
BASE_DOCX = REPORT_DIR / "GSA可靠性确认性实验_新种子47-56_基础版.docx"

DOC_SKILL = Path(
    r"C:\Users\zhurui\.codex\plugins\cache\openai-primary-runtime\documents\26.802.11031\skills\documents"
)
sys.path.insert(0, str(DOC_SKILL / "scripts"))
from table_geometry import apply_table_geometry  # noqa: E402


NAVY = RGBColor(31, 77, 120)
BLUE = RGBColor(46, 116, 181)
GRAY = RGBColor(89, 89, 89)
LIGHT_GRAY = "F2F4F7"
PALE_BLUE = "E8EEF5"
PALE_GOLD = "FFF4CE"
BLACK = RGBColor(0, 0, 0)


SCENARIO_LABELS = {
    "stale_moderate": "中度陈旧更新",
    "stale_severe": "重度陈旧更新",
    "modality_heterogeneity": "训练期模态异构",
    "client_dropout": "客户端掉线（60%参与）",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def set_run_font(run, name: str = "Calibri", size: float | None = None, bold=None, color=None, italic=None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = color
    if italic is not None:
        run.italic = italic


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_paragraph_shading(paragraph, fill: str) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    shd = p_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        p_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    header = OxmlElement("w:tblHeader")
    header.set(qn("w:val"), "true")
    tr_pr.append(header)


def add_page_number(paragraph) -> None:
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instr, separate, text, end])


def configure_styles(doc: Document) -> None:
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(11)
    normal.font.color.rgb = BLACK
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10

    heading_tokens = {
        "Heading 1": (16, BLUE, 16, 8),
        "Heading 2": (13, BLUE, 12, 6),
        "Heading 3": (12, NAVY, 8, 4),
    }
    for style_name, (size, color, before, after) in heading_tokens.items():
        style = styles[style_name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    header = section.header.paragraphs[0]
    header.paragraph_format.space_after = Pt(0)
    header.paragraph_format.tab_stops.add_tab_stop(Inches(6.5), WD_TAB_ALIGNMENT.RIGHT)
    left = header.add_run("GSA可靠性确认性实验")
    set_run_font(left, size=9, color=GRAY)
    right = header.add_run("\t内部研究汇报 | 2026-08-04")
    set_run_font(right, size=9, color=GRAY)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    prefix = footer.add_run("第 ")
    set_run_font(prefix, size=9, color=GRAY)
    add_page_number(footer)
    suffix = footer.add_run(" 页")
    set_run_font(suffix, size=9, color=GRAY)


def add_label_paragraph(doc: Document, label: str, text: str, *, after: float = 4):
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.space_after = Pt(after)
    label_run = paragraph.add_run(label)
    set_run_font(label_run, bold=True)
    body_run = paragraph.add_run(text)
    set_run_font(body_run)
    return paragraph


def add_heading(doc: Document, text: str, level: int = 1):
    return doc.add_paragraph(text, style=f"Heading {level}")


def add_formula(doc: Document, text: str) -> None:
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_before = Pt(6)
    paragraph.paragraph_format.space_after = Pt(8)
    run = paragraph.add_run(text)
    set_run_font(run, name="Cambria Math", size=11, italic=True)


def add_primary_table(doc: Document, primary: list[dict[str, str]]) -> None:
    headers = ["压力场景", "FedAvg损伤", "GSA损伤", "配对差（95% CI）", "Holm p", "判定"]
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    widths = [1800, 1200, 1200, 2700, 960, 1500]
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        cell.text = header
        set_cell_shading(cell, LIGHT_GRAY)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        paragraph = cell.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.space_after = Pt(0)
        for run in paragraph.runs:
            set_run_font(run, size=8.5, bold=True)
    set_repeat_table_header(table.rows[0])

    for row in primary:
        difference = float(row["gsa_minus_comparator_mean"])
        low = float(row["ci95_low"])
        high = float(row["ci95_high"])
        values = [
            SCENARIO_LABELS[row["scenario"]],
            f"{float(row['comparator_mean']):.4f}",
            f"{float(row['gsa_mean']):.4f}",
            f"{difference:+.4f} [{low:+.4f}, {high:+.4f}]",
            f"{float(row['holm_p']):.4f}",
            "达到预设标准" if row["confirmed"].lower() == "true" else "未达到预设标准",
        ]
        cells = table.add_row().cells
        for index, value in enumerate(values):
            cells[index].text = value
            cells[index].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            paragraph = cells[index].paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT if index in (0, 3, 5) else WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.space_after = Pt(0)
            for run in paragraph.runs:
                set_run_font(run, size=8.5)
        if row["confirmed"].lower() == "true":
            set_cell_shading(cells[-1], PALE_BLUE)
    apply_table_geometry(table, widths, table_width_dxa=9360, indent_dxa=120)
    after = doc.add_paragraph("注：损伤为压力期逐轮NLL相对同方法干净轨迹的累计差。负的GSA-FedAvg差值表示GSA损伤更小。")
    after.paragraph_format.space_before = Pt(4)
    after.paragraph_format.space_after = Pt(8)
    for run in after.runs:
        set_run_font(run, size=9, color=GRAY)


def find_effect(
    effects: Iterable[dict[str, str]], scenario: str, comparator: str, metric: str
) -> dict[str, str] | None:
    for row in effects:
        if row["scenario"] == scenario and row["comparator"] == comparator and row["metric"] == metric:
            return row
    return None


def build_document() -> Path:
    decision = json.loads((OUT / "confirmatory_decision.json").read_text(encoding="utf-8"))
    primary = read_csv(OUT / "confirmatory_primary_outcomes.csv")
    degradation = read_csv(OUT / "confirmatory_stress_degradation.csv")
    effects = read_csv(OUT / "confirmatory_paired_effects.csv")
    clean = read_csv(OUT / "confirmatory_clean_noninferiority.csv")
    clean_summary = {
        row["metric"]: row
        for row in read_csv(OUT / "confirmatory_clean_noninferiority_summary.csv")
    }
    per_seed = read_csv(OUT / "confirmatory_per_seed.csv")
    verification = json.loads((OUT / "confirmatory_verification.json").read_text(encoding="utf-8"))

    clean_nll = sum(float(row["validation_nll_last10_diff"]) for row in clean) / len(clean)
    clean_test_nll = sum(float(row["test_nll_diff"]) for row in clean) / len(clean)
    clean_test_f1 = sum(float(row["test_macro_f1_diff"]) for row in clean) / len(clean)

    doc = Document()
    configure_styles(doc)

    title = doc.add_paragraph()
    title.paragraph_format.space_before = Pt(12)
    title.paragraph_format.space_after = Pt(4)
    run = title.add_run("GSA可靠性确认性实验")
    set_run_font(run, size=24, bold=True, color=BLACK)
    subtitle = doc.add_paragraph()
    subtitle.paragraph_format.space_after = Pt(14)
    subrun = subtitle.add_run("新种子47—56｜冻结协议｜多压力场景｜正式结果与论文修改建议")
    set_run_font(subrun, size=13, color=GRAY)
    add_label_paragraph(doc, "研究对象：", "航运多模态联邦知识融合中的异构优化演化与可靠性。", after=2)
    add_label_paragraph(doc, "确认性范围：", "10个未参与探索的新种子。GSA参数在运行前冻结。", after=2)
    add_label_paragraph(doc, "主要终点：", "压力期累计超额NLL。恢复期累计超额NLL为支持性终点。", after=12)

    lead = doc.add_paragraph()
    lead.paragraph_format.left_indent = Inches(0.16)
    lead.paragraph_format.right_indent = Inches(0.16)
    lead.paragraph_format.space_before = Pt(6)
    lead.paragraph_format.space_after = Pt(12)
    set_paragraph_shading(lead, PALE_BLUE if decision["strong_cross_scenario_reliability_supported"] else PALE_GOLD)
    lead_run = lead.add_run("冻结判定：" + decision["claim_recommendation"])
    set_run_font(lead_run, size=11, bold=True, color=NAVY if decision["strong_cross_scenario_reliability_supported"] else BLACK)

    add_heading(doc, "1 先回答核心问题", 1)
    p = doc.add_paragraph()
    r = p.add_run("可靠性不是一次性的精度排名。")
    set_run_font(r, bold=True)
    r = p.add_run("本文把可靠性操作化为三个量：压力损伤、恢复残差和干净条件非劣性。三者缺一不可。")
    set_run_font(r)
    add_label_paragraph(doc, "结论状态：", decision["claim_recommendation"])
    add_label_paragraph(doc, "是否放弃可靠性主线：", "不放弃。结论强度由冻结标准决定。未达到的部分必须收窄，不能靠措辞补强。")

    add_heading(doc, "2 冻结实验协议", 1)
    add_label_paragraph(doc, "种子隔离：", "探索阶段为42—46。确认阶段为47—56。两组不重叠。")
    add_label_paragraph(doc, "时间结构：", "第1—10轮为干净期。第11—20轮为压力期。第21—30轮为恢复期。")
    add_label_paragraph(doc, "压力一：", "中度陈旧延迟为[0,1,2,3,4]。重度陈旧延迟为[0,2,4,6,8]。")
    add_label_paragraph(doc, "压力二：", "训练期客户端具有不同模态可用性。测试仍使用完整模态。")
    add_label_paragraph(doc, "压力三：", "压力期每轮仅3/5客户端参与。各方法使用相同参与客户端。")
    add_label_paragraph(doc, "方法：", "FedAvg、FedProx、GSA。陈旧场景另设陈旧度衰减聚合。")
    p = doc.add_paragraph()
    r = p.add_run("GSA被表述为梯度层协调机制。")
    set_run_font(r, bold=True)
    r = p.add_run("它不是新的理论体系，也不被称为可学习的多主体协同框架。")
    set_run_font(r)

    add_heading(doc, "3 可靠性终点", 1)
    doc.add_paragraph("对场景s、方法m、种子k，压力损伤定义为：")
    add_formula(doc, "R_stress(s,m,k) = ∑(t=11…20) [NLL(s,m,k,t) − NLL(clean,m,k,t)]")
    doc.add_paragraph("恢复残差采用相同定义，但求和范围为第21—30轮。方法差定义为：")
    add_formula(doc, "ΔR(s,k) = R_stress(s,GSA,k) − R_stress(s,FedAvg,k)")
    doc.add_paragraph("ΔR小于0表示GSA承受的可靠性损伤更小。主检验使用同种子配对差。三个主要场景执行Holm校正。")

    add_heading(doc, "4 确认性结果", 1)
    add_heading(doc, "4.1 主要终点", 2)
    add_primary_table(doc, primary)

    add_heading(doc, "4.2 压力是否真的造成退化", 2)
    for row in degradation:
        label = SCENARIO_LABELS[row["scenario"]]
        text = (
            f"FedAvg累计超额NLL为{float(row['fedavg_excess_nll_auc_mean']):.4f}。"
            f"95%区间为[{float(row['ci95_low']):.4f}, {float(row['ci95_high']):.4f}]。"
            f"{row['seeds_with_positive_damage']}/{row['n_seeds']}个种子出现正向损伤。"
        )
        add_label_paragraph(doc, label + "：", text)

    add_heading(doc, "4.3 干净条件是否受损", 2)
    validation_clean = clean_summary["validation_nll_last10_diff"]
    test_nll_clean = clean_summary["test_nll_diff"]
    test_f1_clean = clean_summary["test_macro_f1_diff"]
    add_label_paragraph(
        doc,
        "最后10轮验证NLL差：",
        f"GSA−FedAvg = {clean_nll:+.6f}。95%区间为"
        f"[{float(validation_clean['ci95_low']):+.6f}, {float(validation_clean['ci95_high']):+.6f}]。预设上界为+0.01。",
    )
    add_label_paragraph(
        doc,
        "测试NLL差：",
        f"GSA−FedAvg = {clean_test_nll:+.6f}。95%区间为"
        f"[{float(test_nll_clean['ci95_low']):+.6f}, {float(test_nll_clean['ci95_high']):+.6f}]。预设上界为+0.01。",
    )
    add_label_paragraph(
        doc,
        "测试宏F1差：",
        f"GSA−FedAvg = {clean_test_f1:+.6f}。95%区间为"
        f"[{float(test_f1_clean['ci95_low']):+.6f}, {float(test_f1_clean['ci95_high']):+.6f}]。预设下界为−0.01。",
    )
    add_label_paragraph(doc, "冻结判定：", "通过。" if decision["clean_noninferiority_passed"] else "未通过。")

    add_heading(doc, "4.4 恢复期与强化基线", 2)
    for scenario in ["stale_moderate", "stale_severe", "modality_heterogeneity", "client_dropout"]:
        recovery = find_effect(effects, scenario, "fedavg", "recovery_excess_nll_auc")
        if recovery:
            add_label_paragraph(
                doc,
                SCENARIO_LABELS[scenario] + "：",
                f"恢复期GSA−FedAvg累计超额NLL差为{float(recovery['gsa_minus_comparator_mean']):+.6f}。",
            )
    stale_decay = find_effect(effects, "stale_moderate", "staleness_decay", "stress_excess_nll_auc")
    if stale_decay:
        p = doc.add_paragraph()
        r = p.add_run("陈旧度衰减聚合")
        set_run_font(r, bold=True)
        r = p.add_run(
            f"是专门的陈旧度感知比较方法。中度陈旧下，GSA相对它的压力损伤差为"
            f"{float(stale_decay['gsa_minus_comparator_mean']):+.6f}。本实验仍是按轮聚合。因此不把该比较方法写成FedAsync。"
        )
        set_run_font(r)

    add_heading(doc, "5 机制结果怎么写", 1)
    for scenario in ["stale_moderate", "modality_heterogeneity", "client_dropout"]:
        spec = find_effect(effects, scenario, "fedavg", "stress_d_spec_after")
        repr_effect = find_effect(effects, scenario, "fedavg", "stress_excess_d_repr")
        pred_effect = find_effect(effects, scenario, "fedavg", "stress_excess_d_pred")
        if spec and repr_effect and pred_effect:
            add_label_paragraph(
                doc,
                SCENARIO_LABELS[scenario] + "：",
                f"GSA相对FedAvg的D_spec差为{float(spec['gsa_minus_comparator_mean']):+.6f}；"
                f"D_repr超额差为{float(repr_effect['gsa_minus_comparator_mean']):+.6f}；"
                f"D_pred超额差为{float(pred_effect['gsa_minus_comparator_mean']):+.6f}。",
            )
    doc.add_paragraph("这些量用于检查机制方向是否一致。它们不能单独证明D_spec下降导致NLL改善。本文没有完成正式中介识别。因果链必须保持克制。")

    mentor_heading = add_heading(doc, "6 导师意见与本次落实", 1)
    mentor_heading.paragraph_format.page_break_before = True
    add_label_paragraph(
        doc,
        "导师原意见一：",
        "不要把航运场景拔高为必须使用GSA的真实多主体协同系统。",
    )
    add_label_paragraph(
        doc,
        "本次落实一：",
        "系统背景保留航运多源数据。核心问题改为异构优化演化下的联邦知识融合可靠性。",
    )
    add_label_paragraph(
        doc,
        "导师原意见二：",
        "不要使用update space mismatch。不要把GSA写成可学习机制。",
    )
    add_label_paragraph(
        doc,
        "本次落实二：",
        "方法层使用gradient spectral discrepancy。方法定位为optimization-level coordination mechanism。",
    )
    add_label_paragraph(
        doc,
        "导师原意见三：",
        "必须形成退化机理识别—缓解—权衡的证据链。",
    )
    add_label_paragraph(
        doc,
        "本次落实三：",
        "先验证压力损伤。再比较GSA缓解。最后检查干净条件代价和恢复残差。安全结果仍单列为权衡。",
    )
    add_label_paragraph(
        doc,
        "导师原意见四：",
        "可解释性不能靠概念包装。必须有分解实验支撑。",
    )
    add_label_paragraph(
        doc,
        "本次落实四：",
        "D_spec、D_repr和D_pred分开报告。未观察到的中介关系不强写。",
    )

    add_heading(doc, "7 论文中可以写什么", 1)
    add_label_paragraph(doc, "可以写：", "异构训练压力能够使验证NLL相对匹配的干净轨迹发生系统性变化。")
    if decision["strong_cross_scenario_reliability_supported"]:
        add_label_paragraph(doc, "可以写：", "固定参数的GSA在多个预设压力场景下降低了累计可靠性损伤，并保持干净条件非劣。")
    else:
        confirmed = [SCENARIO_LABELS[row["scenario"]] for row in primary if row["confirmed"].lower() == "true"]
        if confirmed:
            add_label_paragraph(doc, "可以写：", "确认性缓解证据集中在" + "、".join(confirmed) + "。其他场景仅报告趋势。")
        else:
            add_label_paragraph(doc, "可以写：", "GSA在部分指标上出现缓解趋势，但未达到预设的跨场景确认标准。")
    add_label_paragraph(doc, "不能写：", "GSA已经建立新的更新空间理论。")
    add_label_paragraph(doc, "不能写：", "D_spec下降已经证明知识表示可靠性提高。")
    add_label_paragraph(doc, "不能写：", "当前同步陈旧更新模拟等同于真实异步航运系统。")
    add_label_paragraph(doc, "结论边界：", "只对本数据、本模型和已测试压力范围负责。")

    add_heading(doc, "8 可直接替换进论文的中文表述", 1)
    add_heading(doc, "8.1 实验设计", 2)
    doc.add_paragraph(
        "为检验联邦知识融合在异构环境下的可靠性，本研究采用匹配轨迹设计。每次运行包含30轮训练。"
        "第1—10轮为干净期。第11—20轮施加异构压力。第21—30轮恢复干净条件。"
        "压力场景包括陈旧更新、训练期模态异构和客户端掉线。主要终点为压力轨迹相对同方法干净轨迹的累计超额负对数似然。"
        "该终点直接描述预测分布的受损程度。它不以一次性精度替代可靠性。"
    )
    add_heading(doc, "8.2 统计策略", 2)
    doc.add_paragraph(
        "确认性分析使用10个未参与探索的新随机种子。GSA参数在结果计算前固定。"
        "所有方法在同一压力场景中使用相同的数据划分、客户端参与序列和本地训练预算。"
        "GSA与FedAvg采用同种子配对比较。本文报告配对均值差、95%自助法区间和精确符号翻转检验。"
        "三个主要压力场景采用Holm方法控制多重检验。"
    )
    add_heading(doc, "8.3 结果段", 2)
    result_sentence = decision["claim_recommendation"]
    doc.add_paragraph(
        "确认性实验首先验证了各类异构压力对联邦预测轨迹的影响。随后，本文比较固定参数GSA与FedAvg的累计超额NLL。"
        + result_sentence
        + "D_spec、D_repr和D_pred仅作为机制一致性证据。本文不据此主张完整的因果中介链。"
    )

    add_heading(doc, "9 完整性与复现", 1)
    add_label_paragraph(doc, "验证状态：", "全部通过。" if verification["all_checks_passed"] else "存在待复核项。")
    add_label_paragraph(doc, "确认性运行：", f"{verification['diagnostics']['run_count']}个方法—场景—种子组合。")
    add_label_paragraph(doc, "轮次记录：", f"{verification['diagnostics']['round_rows']}行。每个组合30轮。")
    add_label_paragraph(doc, "测试记录：", f"{verification['diagnostics']['test_rows']}行。")
    add_label_paragraph(doc, "轨迹匹配：", f"压力场景前10轮与干净轨迹的最大NLL差为{verification['diagnostics']['max_clean_prefix_nll_difference']:.3e}。")
    add_label_paragraph(doc, "代码：", str(HERE / "run_reliability_confirmatory.py"))
    add_label_paragraph(doc, "分析：", str(HERE / "analyze_reliability_confirmatory.py"))
    add_label_paragraph(doc, "校验：", str(HERE / "verify_reliability_confirmatory.py"))
    add_label_paragraph(doc, "完整结果目录：", str(OUT))

    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    doc.save(BASE_DOCX)
    return BASE_DOCX


if __name__ == "__main__":
    print(build_document())
