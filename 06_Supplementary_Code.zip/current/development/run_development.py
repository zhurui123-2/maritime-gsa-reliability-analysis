"""55 dated development/ablation jobs; no cross-partition or MIA claims."""
from pathlib import Path
import argparse,copy,hashlib,json,os,platform,sys,time
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ.setdefault(key,'1')
if os.environ.get('PYTHONHASHSEED')!='0':raise RuntimeError('Launch Python with PYTHONHASHSEED=0 for random-consensus reproducibility')
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'historical_core'))
import numpy as np
import pandas as pd
import torch
import run_rebuilt_experiments as base
base.membership_attack=lambda *args,**kwargs:{} # Omit only the post-training audit.
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str),encoding='utf-8');tmp.replace(p)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--shards',type=int,default=1);ap.add_argument('--shard',type=int,default=0);ap.add_argument('--combine',action='store_true');args=ap.parse_args()
    assert 0<=args.shard<args.shards
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    frame=pd.read_csv(ROOT/'data'/'vessels.csv');cfg=base.load_config();cfg.update(rounds=30,local_epochs=1,data_path=str(ROOT/'data'/'vessels.csv'))
    seeds=list(range(42,47));mine=np.array_split(seeds,args.shards)[args.shard].tolist();jobs=[]
    methods=['local','fedavg','fedprox','fedbn','scaffold','gsa']
    variants=['no_ema','no_direction_bound','random_consensus','nonhomologous','norm_only']
    for seed in seeds:
        jobs +=[(seed,m,'gsa' if m=='gsa' else 'none','main') for m in methods]
        jobs +=[(seed,'gsa',v,'ablation') for v in variants]
    selected=[x for x in jobs if x[0] in mine];out=ROOT/'results';out.mkdir(exist_ok=True)
    protocol={'execution_date':'2026-10-24','status':'RUNNING','started_at_utc':pd.Timestamp.now('UTC').isoformat(),
      'seeds':seeds,'total_jobs':55,'setting':'natural_ship_type','rounds':30,'config':cfg,
      'data_sha256':sha(ROOT/'data'/'vessels.csv'),'wrapper_sha256':sha(__file__),
      'historical_sources_sha256':{p.name:sha(p) for p in sorted((ROOT/'historical_core').iterdir()) if p.is_file()},
      'environment':{'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'device':'cpu','torch_threads':1,'PYTHONHASHSEED':os.environ['PYTHONHASHSEED']},
      'random_consensus':'Recovered implementation seeds NumPy per parameter block by abs(hash(block)) mod 2**32; Python hash seed frozen to 0 for this new execution. Original process hash seed unknown.',
      'MIA':'Post-training membership_attack replaced by empty output; all training, prediction, and mechanism calculations unchanged.',
      'scope':'New execution of original 1172-vessel natural-ship-type development and five ablations; no additional four partition settings; complete GSA reused from main, not trained twice.',
      'timing':'Concurrent execution elapsed values retained for audit only, not a dedicated-hardware benchmark.'}
    write(out/f'manifest_shard{args.shard}.json',protocol)
    if args.combine:
        metrics=[];rounds=[]
        for seed,method,variant,phase in jobs:
            stem=f'{phase}__{method}__{variant}__seed{seed}';metrics.append(json.loads((out/'runs'/(stem+'.result.json')).read_text(encoding='utf-8')))
            p=out/'runs'/(stem+'.rounds.csv')
            if method!='local':
                x=pd.read_csv(p);assert len(x)==30;rounds.append(x)
        tt=pd.DataFrame(metrics);rr=pd.concat(rounds,ignore_index=True)
        assert len(tt)==55 and len(rr)==1500 and not rr[['phase','method','variant','seed','round']].duplicated().any()
        tt.to_csv(out/'all_results.csv',index=False);rr.to_csv(out/'all_rounds.csv',index=False)
        protocol.update(status='COMPLETED',result_rows=len(tt),round_rows=len(rr));write(out/'protocol.json',protocol)
        print('COMPLETED',len(tt),len(rr));return
    start=time.monotonic()
    for i,(seed,method,variant,phase) in enumerate(selected,1):
        stem=f'{phase}__{method}__{variant}__seed{seed}';rp=out/'runs'/(stem+'.rounds.csv');jp=out/'runs'/(stem+'.result.json')
        if rp.exists() or jp.exists():raise RuntimeError('Refusing overwrite/partial restart '+stem)
        prepared=base.prepare_data(frame,seed)
        sp=out/'splits'/f'seed{seed}.json'
        if not sp.exists():write(sp,{'train':prepared.train_idx.tolist(),'validation':prepared.anchor_idx.tolist(),'test':prepared.test_idx.tolist(),'train_cutpoints':prepared.train_cutpoints,'dims':prepared.dims,'features':prepared.feature_names})
        t0=time.monotonic()
        if method=='local':result=base.run_local_only(prepared,seed,copy.deepcopy(cfg),torch.device('cpu'))
        else:
            result,r,_,_=base.run_federated(prepared,'natural_ship_type',method,seed,copy.deepcopy(cfg),torch.device('cpu'),gsa_variant=variant,mechanism=True)
            r['phase']=phase;rp.parent.mkdir(exist_ok=True);r.to_csv(rp,index=False)
        result.update(phase=phase,execution='development_new_execution_20261024');write(jp,result)
        write(out/f'progress_shard{args.shard}.json',{'completed':i,'total':len(selected),'elapsed_seconds':time.monotonic()-start,'last':stem,'run_seconds':time.monotonic()-t0})
        print(f'{i}/{len(selected)} {stem} seconds={time.monotonic()-t0:.2f}',flush=True)
    protocol.update(status='COMPLETED',elapsed_seconds=time.monotonic()-start,completed_at_utc=pd.Timestamp.now('UTC').isoformat());write(out/f'manifest_shard{args.shard}.json',protocol)
if __name__=='__main__':main()

