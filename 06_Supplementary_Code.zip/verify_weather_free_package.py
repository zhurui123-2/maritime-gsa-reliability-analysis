from pathlib import Path
import csv,hashlib,json
r=Path(__file__).resolve().parent
manifest=json.loads((r/'weather_free_validation_20261027'/'package_manifest.json').read_text(encoding='utf-8'))
for item in manifest['new_payload_files']:
 p=r/item['path']
 if not p.is_file():raise SystemExit('Missing: '+item['path']+'; extract both supplementary ZIPs together.')
 if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:raise SystemExit('Hash mismatch: '+item['path'])
q=r/'weather_free_validation_20261027'
with (q/'results/all_new_test_results.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
recovery=[x for x in rows if x['family']=='recovery']
assert len(rows)==320 and len(recovery)==200
assert sum(x['scenario']=='clean' for x in recovery)==40
assert sum(x['scenario']!='clean' for x in recovery)==160
with (q/'results/all_new_rounds.csv').open(encoding='utf-8-sig',newline='') as f:assert sum(1 for _ in csv.DictReader(f))==15600
print('Verified:320 new formal runs;15,600 round records;200 recovery trajectories=160 stressed+40 clean; all new payload hashes match.')
