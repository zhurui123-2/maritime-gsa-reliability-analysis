# Data access and units

The analyses use the same linked cohort of1172 vessel records. Cohort CSV SHA256:03ddbf7bdb9364c0dd07ffdee5be8248a747a8f8ecfbfc13bbec66c3ac4ef0eb. Vessel identities are not redistributed. The data archive supplies derived summaries and, for the new recovery extension, all6000 validation-round records and100 final test summaries.

Full model retraining requires an authorized copy of the linked cohort, not merely downloading the source datasets independently. Preprocessing and linkage determine the exact cohort. Original raw acquisition and access conditions remain with their providers and the authors; this package does not grant or automatically arrange that access.

The cohort combines AIS from1–7 January2024, matched hourly3km HRRR weather, registry attributes and annual2024 EU MRV information. Annual total_co2_emissions_tonnes is the five-class target; training-only quintiles define labels. CO2 totals and direct fuel variables are excluded from primary-model predictors. The independent earlier Local-only audit in the article uses a separate feature specification and is not supplied as this recovery training dataset specification.

Required recovery fields include federated_node, total_co2_emissions_tonnes, MMSI, TechnicalEfficiency, vessel_type_ais, PortOfRegistry, traj_points, avg_speed, max_speed, speed_std, avg_lat, avg_lon, avg_cog, surface_pressure, temperature_2m, relative_humidity_2m, u_wind_10m, v_wind_10m, time_at_sea_hours, imo_observations, and weather_time_diff_hours. Exact imputation, encoding and split logic are in recovery_extension/historical_core/run_rebuilt_experiments.py. Split indices and cutpoints are provided per seed.

Recovery outcomes use NLL summed over rounds. Screening recall, precision, coverage and oracle shortfall are fractions in per-run CSVs; derived presentation tables use percentages or percentage points as specified in the Data_Tables README. Statistical units are seeds. Five screening rotations are averaged within seed; the recovery extension uses one cyclic assignment per seed, balanced twice across ten seeds.
