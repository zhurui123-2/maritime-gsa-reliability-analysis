from pathlib import Path
import json
import numpy as np
import pandas as pd
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.colors import HexColor
import pypdfium2 as pdfium

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'analysis'
OUT=ROOT/'Data_Tables'
FIG=ROOT/'Figures'
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
CELLS=[('primary','moderate'),('primary','severe'),('no_annual','moderate')]
METHODS=['FedAvg','StalenessAware','Combined']
CLIENTS=['bulk','container','general_cargo','passenger','tanker']
NAMES={'bulk':'Bulk carrier','container':'Container','general_cargo':'General cargo','passenger':'Passenger','tanker':'Tanker'}
LABEL={('primary','moderate'):'Annual / moderate',('primary','severe'):'Annual / severe',('no_annual','moderate'):'No annual / moderate'}

def ci(x):
    x=np.asarray(x,float)
    rng=np.random.default_rng(90210)
    means=rng.choice(x,(10000,len(x)),replace=True).mean(1)
    return float(x.mean()),float(np.quantile(means,.025)),float(np.quantile(means,.975))

def analyze():
    base=pd.read_csv(SOURCE/'baseline_by_seed.csv')
    means=pd.read_csv(SOURCE/'seed_means_over_rotations.csv')
    runs=pd.read_csv(SOURCE/'all_450_runs.csv')
    assert len(runs)==450 and runs[['regime','severity','seed','rotation','method']].drop_duplicates().shape[0]==450
    assert base.shape[0]==120
    baseline=[]
    for (reg,method),g in base.groupby(['regime','method']):
        for metric in ['miss_rate_10','emission_coverage_10','regret_10']:
            values=1-g.recall_10 if metric=='miss_rate_10' else g[metric]
            m,lo,hi=ci(100*values)
            baseline.append(dict(regime=reg,method=method,metric=metric,mean=m,ci_low=lo,ci_high=hi,n_seeds=10))
    baseline=pd.DataFrame(baseline);baseline.to_csv(OUT/'clean_management_outcomes.csv',index=False)
    metrics=['stress_recall10_loss','stress_coverage10_loss','stress_regret10_increase']
    outcome=[];paired=[]
    for reg,sev in CELLS:
        g=means[(means.regime==reg)&(means.severity==sev)]
        for metric in metrics:
            p=g.pivot(index='seed',columns='method',values=metric)
            assert p.shape==(10,3)
            for method in METHODS:
                m,lo,hi=ci(100*p[method])
                outcome.append(dict(regime=reg,severity=sev,method=method,metric=metric,mean=m,ci_low=lo,ci_high=hi,n_seeds=10))
            for left,right in [('StalenessAware','FedAvg'),('Combined','StalenessAware')]:
                m,lo,hi=ci(100*(p[left]-p[right]))
                paired.append(dict(regime=reg,severity=sev,contrast=left+' - '+right,metric=metric,mean=m,ci_low=lo,ci_high=hi,n_seeds=10))
    outcome=pd.DataFrame(outcome);paired=pd.DataFrame(paired)
    outcome.to_csv(OUT/'stress_management_outcomes.csv',index=False)
    paired.to_csv(OUT/'management_paired_differences.csv',index=False)
    client=pd.read_csv(SOURCE/'client_nll_at20.csv')
    cseed=client.groupby(['regime','severity','seed','method','client']).nll_at20.mean().reset_index()
    fleet=[]
    for reg,sev in CELLS:
        for c in CLIENTS:
            g=cseed[(cseed.regime==reg)&(cseed.severity==sev)&(cseed.client==c)].pivot(index='seed',columns='method',values='nll_at20')
            m,lo,hi=ci(g.StalenessAware-g.FedAvg)
            fleet.append(dict(regime=reg,severity=sev,client=c,FedAvg=g.FedAvg.mean(),StalenessAware=g.StalenessAware.mean(),Combined=g.Combined.mean(),difference=m,ci_low=lo,ci_high=hi,n_seeds=10))
    fleet=pd.DataFrame(fleet);fleet.to_csv(OUT/'fleet_nll_and_paired_differences.csv',index=False)
    w=pd.read_csv(SOURCE/'client_weights.csv'); w=w[w.regime=='primary']
    weight=[]
    for sev in ['moderate','severe']:
        for c in CLIENTS:
            g=w[(w.severity==sev)&(w.client==c)]
            f=g[g.method=='FedAvg'];a=g[g.method=='StalenessAware']
            assert len(a)==50
            weight.append(dict(severity=sev,client=c,sample_weight=100*f.weight.mean(),aware_mean=100*a.weight.mean(),aware_min=100*a.weight.min(),aware_max=100*a.weight.max(),n_rotations=5,n_seeds=10))
    weight=pd.DataFrame(weight);weight.to_csv(OUT/'fleet_aggregation_weights.csv',index=False)
    for filename in ['primary_paired_tests_12.csv','baseline_by_seed.csv','rotation_summary.csv','all_450_runs.csv','recovery_curves.csv']:
        (OUT/filename).write_bytes((SOURCE/filename).read_bytes())
    plotting(outcome,fleet,weight)
    stats={'stress_trajectories':450,'seeds':10,'rotations':5,'source':str(SOURCE),'new_model_training':False,'new_significance_tests':False,'additional_intervals':'10000 percentile seed bootstrap samples; rotations averaged within seed; descriptive 95% intervals; bootstrap seed 90210','input_label_primary':'Annual operating inputs retained in the independent extension'}
    (ROOT/'working'/'management_analysis_checks.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    print(fleet.to_string(index=False))
    print(paired.to_string(index=False))

def plotting(outcome,fleet,weight):
    colors=['#677884','#168579','#C76D40']; cc=['#168579','#C76D40','#6E62A6']
    def label(c,x,y,t,size=8,align='left',bold=False):
        c.setFillColor(HexColor('#111111'));c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
        getattr(c,{'left':'drawString','center':'drawCentredString','right':'drawRightString'}[align])(x,y,t)
    def dot(c,x,y,color):
        c.setFillColor(HexColor(color));c.setStrokeColor(HexColor(color));c.circle(x,y,2.2,stroke=1,fill=1)
    def export(c,name):
        c.save();pdf=pdfium.PdfDocument(ROOT/'working'/f'{name}.pdf')
        im=pdf[0].render(scale=300/72).to_pil();im.save(FIG/f'{name}.png',dpi=(300,300));pdf.close()
    def legend(c,x,y,items):
        for color,txt in items:
            if txt=='Sample-size weight':
                c.setStrokeColor(HexColor(color));c.setLineWidth(1);c.line(x,y-2,x,y+6)
            else:dot(c,x,y+2,color)
            label(c,x+7,y,txt,7.6);x+=len(txt)*4.1+29
    name='Fig_11_management_outcomes';c=Canvas(str(ROOT/'working'/f'{name}.pdf'),pagesize=(460,438))
    legend(c,65,423,list(zip(colors,['FedAvg','Delay weighting','Weighting + GSA'])))
    metrics=['stress_recall10_loss','stress_coverage10_loss','stress_regret10_increase']
    titles=['(a) High-emitter recall loss','(b) Emission coverage loss','(c) Oracle shortfall increase']
    for k,(metric,title) in enumerate(zip(metrics,titles)):
        bottom=306-k*137;left=55;right=445;h=88
        g=outcome[outcome.metric==metric];low=min(0,g.ci_low.min());high=max(0,g.ci_high.max())
        span=high-low;raw=span/4;power=10**np.floor(np.log10(raw));step=next(v*power for v in [1,2,5,10] if v*power>=raw)
        lo=np.floor(low/step)*step;hi=np.ceil(high/step)*step
        yp=lambda val:bottom+(val-lo)/(hi-lo)*h
        label(c,left,bottom+h+10,title,9,bold=True)
        for tick in np.arange(lo,hi+step*.2,step):
            y=yp(tick);c.setStrokeColor(HexColor('#D8D8D8' if abs(tick)>1e-12 else '#777777'));c.setLineWidth(.4);c.line(left,y,right,y)
            label(c,left-7,y-2.5,f'{tick:.2f}'.rstrip('0').rstrip('.') if tick else '0',7.5,'right')
        c.setStrokeColor(HexColor('#333333'));c.setLineWidth(.6);c.line(left,bottom,left,bottom+h)
        for j,m in enumerate(METHODS):
            for q,(reg,sev) in enumerate(CELLS):
                row=g[(g.regime==reg)&(g.severity==sev)&(g.method==m)].iloc[0]
                x=left+(q+.5)*(right-left)/3+(j-1)*12
                c.setStrokeColor(HexColor(colors[j]));c.setLineWidth(.8);a=yp(row.ci_low);b=yp(row.ci_high)
                c.line(x,a,x,b);c.line(x-3,a,x+3,a);c.line(x-3,b,x+3,b);dot(c,x,yp(row['mean']),colors[j])
        for q,(a,b) in enumerate([('Annual inputs','Moderate lag'),('Annual inputs','Severe lag'),('No annual inputs','Moderate lag')]):
            x=left+(q+.5)*(right-left)/3;label(c,x,bottom-12,a,7.8,'center');label(c,x,bottom-22,b,7.5,'center')
        c.saveState();c.translate(12,bottom+h/2);c.rotate(90);label(c,0,0,'Percentage points',8,'center');c.restoreState()
    export(c,name)
    name='Fig_S4_fleet_representation';c=Canvas(str(ROOT/'working'/f'{name}.pdf'),pagesize=(460,425))
    label(c,20,409,'(a) Fleet-specific prediction response',9.5,bold=True)
    legend(c,88,392,list(zip(cc,[LABEL[x] for x in CELLS])))
    label(c,20,202,'(b) Participation weights across delay assignments',9.5,bold=True)
    legend(c,100,185,[(cc[0],'Moderate lag'),(cc[1],'Severe lag'),('#111111','Sample-size weight')])
    for panel in [0,1]:
        bottom=246 if panel==0 else 38;top=369 if panel==0 else 161;left=99;right=447
        xmin,xmax=(-.20,.15) if panel==0 else (0,100)
        xp=lambda v:left+(v-xmin)/(xmax-xmin)*(right-left)
        ticks=np.arange(-.20,.151,.05) if panel==0 else np.arange(0,101,20)
        for tick in ticks:
            x=xp(tick);c.setStrokeColor(HexColor('#777777' if abs(tick)<1e-12 else '#DDDDDD'));c.setLineWidth(.5);c.line(x,bottom,x,top)
            label(c,x,bottom-12,('0.00' if abs(tick)<1e-8 else f'{tick:.2f}') if panel==0 else str(int(tick)),7.5,'center')
        for q,client in enumerate(CLIENTS):
            y=top-8-q*25;label(c,left-7,y-2,NAMES[client],7.8,'right')
            if panel==0:
                for j,(reg,sev) in enumerate(CELLS):
                    row=fleet[(fleet.regime==reg)&(fleet.severity==sev)&(fleet.client==client)].iloc[0]
                    yy=y+(j-1)*5;c.setStrokeColor(HexColor(cc[j]));c.setLineWidth(.8);a=xp(row.ci_low);b=xp(row.ci_high)
                    c.line(a,yy,b,yy);c.line(a,yy-2,a,yy+2);c.line(b,yy-2,b,yy+2);dot(c,xp(row.difference),yy,cc[j])
            else:
                for j,sev in enumerate(['moderate','severe']):
                    row=weight[(weight.severity==sev)&(weight.client==client)].iloc[0];yy=y+(j-.5)*7
                    c.setStrokeColor(HexColor(cc[j]));c.setLineWidth(.9);a=xp(row.aware_min);b=xp(row.aware_max)
                    c.line(a,yy,b,yy);c.line(a,yy-2,a,yy+2);c.line(b,yy-2,b,yy+2);dot(c,xp(row.aware_mean),yy,cc[j])
                c.setStrokeColor(HexColor('#111111'));c.setLineWidth(1);x=xp(row.sample_weight);c.line(x,y-5,x,y+5)
        label(c,(left+right)/2,bottom-27,'Round-20 NLL difference: weighting minus FedAvg' if panel==0 else 'Normalized aggregation weight (%)',8,'center')
    export(c,name)

if __name__=='__main__':analyze()
