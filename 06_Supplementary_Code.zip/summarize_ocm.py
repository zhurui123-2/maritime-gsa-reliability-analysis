from pathlib import Path
import itertools
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'analysis'
OUT.mkdir(exist_ok=True)

def ci(values,seed=90210):
    values=np.asarray(values,float);rng=np.random.default_rng(seed)
    boots=rng.choice(values,(10000,len(values)),replace=True).mean(1)
    return float(np.mean(values)),float(np.quantile(boots,.025)),float(np.quantile(boots,.975))

def exact_p(values):
    values=np.asarray(values,float)
    signs=np.array(list(itertools.product([-1,1],repeat=len(values))))
    obs=abs(values.mean());null=np.abs((signs*values).mean(1))
    return float(np.mean(null>=obs-1e-12))

def holm(values):
    order=np.argsort(values);out=np.empty(len(values));running=0
    for r,i in enumerate(order):
        running=max(running,min(1,(len(values)-r)*values[i]));out[i]=running
    return out

def main():
    workers=sorted((ROOT/'results').glob('worker_*'))
    for worker in workers:
        completion=worker/'completion.json'
        assert completion.exists(),f'Worker is incomplete: {worker}'
        assert json.loads(completion.read_text())['status']=='completed'
    runs=pd.concat([pd.read_csv(w/'run_summary.csv') for w in workers],ignore_index=True)
    assert len(runs)==450 and runs.seed.nunique()==10
    assert not runs.duplicated(['regime','seed','severity','rotation','method']).any()
    expected={('primary','moderate'),('primary','severe'),('no_annual','moderate')}
    assert set(zip(runs.regime,runs.severity))==expected
    assert (runs.groupby(['regime','seed','severity','method']).size()==5).all()
    assert np.isfinite(runs.select_dtypes('number')).all().all()
    runs.to_csv(OUT/'all_450_runs.csv',index=False)
    outcomes=['stress_nll_damage','stress_nll_positive','recovery10_nll_residual',
              'recovery_late_nll_residual','stress_recall10_loss','stress_regret10_increase',
              'stress_coverage10_loss','stress_absolute_nll','stress_absolute_recall10',
              'nll_at20','nll_at30','nll_at60','recall10_at20','recall10_at60','macro_f1_at60']
    seedmeans=runs.groupby(['regime','severity','seed','method'])[outcomes].mean().reset_index()
    seedmeans.to_csv(OUT/'seed_means_over_rotations.csv',index=False)
    descriptions=[]
    for key,g in seedmeans.groupby(['regime','severity','method']):
        for metric in outcomes:
            mean,lo,hi=ci(g[metric]);descriptions.append(dict(zip(['regime','severity','method'],key),
                                       metric=metric,mean=mean,ci_low=lo,ci_high=hi,n_seeds=len(g)))
    pd.DataFrame(descriptions).to_csv(OUT/'condition_summary.csv',index=False)
    primary=[];paired=[]
    for (regime,severity),g in seedmeans.groupby(['regime','severity']):
        for metric in outcomes:
            pivot=g.pivot(index='seed',columns='method',values=metric)
            for left,right in [('StalenessAware','FedAvg'),('Combined','StalenessAware')]:
                d=pivot[left]-pivot[right];mean,lo,hi=ci(d)
                row={'regime':regime,'severity':severity,'comparison':left+' - '+right,
                     'metric':metric,'mean_difference':mean,'ci_low':lo,'ci_high':hi,
                     'n_seeds':len(d),'favorable_seeds':int((d<0).sum()),'raw_signflip_p':exact_p(d)}
                if metric in ['stress_nll_damage','stress_recall10_loss']:primary.append(row)
                paired.extend([{'regime':regime,'severity':severity,'comparison':left+' - '+right,
                                'metric':metric,'seed':int(s),'difference':float(v)} for s,v in d.items()])
    tests=pd.DataFrame(primary);assert len(tests)==12
    tests['holm_p_12']=holm(tests.raw_signflip_p.to_numpy())
    tests['passes_direction_ci_holm']=(tests.mean_difference<0)&(tests.ci_high<0)&(tests.holm_p_12<.05)
    tests.to_csv(OUT/'primary_paired_tests_12.csv',index=False)
    pd.DataFrame(paired).to_csv(OUT/'all_paired_seed_differences.csv',index=False)
    baseline_files=list((ROOT/'results').glob('worker_*/*_s*/baseline_metrics.csv'))
    baseline=pd.concat([pd.read_csv(x) for x in baseline_files],ignore_index=True)
    assert len(baseline_files)==20 and len(baseline)==120
    baseline.to_csv(OUT/'baseline_by_seed.csv',index=False)
    bs=[]
    for (regime,method),g in baseline.groupby(['regime','method']):
        for metric in ['macro_f1','nll','recall_5','recall_10','recall_20',
                       'emission_coverage_10','regret_10','worst_client_f1']:
            mean,lo,hi=ci(g[metric]);bs.append({'regime':regime,'method':method,'metric':metric,
                                             'mean':mean,'ci_low':lo,'ci_high':hi})
    pd.DataFrame(bs).to_csv(OUT/'baseline_summary.csv',index=False)
    rotations=runs.groupby(['regime','severity','rotation','method'])[outcomes].mean().reset_index()
    rotations.to_csv(OUT/'rotation_summary.csv',index=False)
    client=[]
    for row in runs.to_dict('records'):
        for c in ['bulk','container','general_cargo','passenger','tanker']:
            client.append({k:row[k] for k in ['regime','severity','seed','rotation','method']}|
                          {'client':c,'nll_at20':row['client_nll_'+c]})
    pd.DataFrame(client).to_csv(OUT/'client_nll_at20.csv',index=False)
    curves=[];weights=[]
    for worker in workers:
        for folder in worker.glob('*_s*'):
            if not folder.is_dir():continue
            regime,seedstr=folder.name.rsplit('_s',1);seed=int(seedstr)
            for child in folder.iterdir():
                if not child.is_dir() or child.name.startswith('clean_'):continue
                severity,rot,method=child.name.split('_',2)
                curve=pd.read_csv(child/'metrics.csv')
                refmethod='Combined' if method=='Combined' else 'FedAvg'
                ref=pd.read_csv(folder/f'clean_{refmethod}'/'metrics.csv')
                assert np.max(np.abs(curve.val_nll.iloc[:10]-ref.val_nll.iloc[:10]))<1e-8
                curves.extend([{'regime':regime,'seed':seed,'severity':severity,'rotation':int(rot[1:]),
                                 'method':method,'round':int(r),'nll_delta':float(v)}
                                for r,v in zip(curve['round'],curve.nll-ref.nll)])
                w=pd.read_csv(child/'client_weights.csv');w=w.assign(regime=regime,seed=seed,
                    severity=severity,rotation=int(rot[1:]),method=method)
                weights.extend(w.to_dict('records'))
    curves=pd.DataFrame(curves);curves.to_csv(OUT/'recovery_curves.csv',index=False)
    pd.DataFrame(weights).to_csv(OUT/'client_weights.csv',index=False)
    figures(baseline,seedmeans,rotations,curves)
    summary={'stress_runs':len(runs),'clean_runs':40,'baseline_rows':len(baseline),
             'primary_tests':tests.to_dict('records'),'cohorts':1,'input_regimes':2,'seeds':10,'rotations':5,
             'status':'completed; exploratory computational results on one existing cohort',
             'ci_scope':'seed randomness, conditional on fixed vessel cohort; unadjusted percentile paired bootstrap CIs',
             'p_scope':'all 1024 sign flips, requiring symmetry/exchangeability; Holm over 12 fixed comparisons',
             'no_external_validation':True}
    (OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(tests.to_string(index=False))
    print(pd.DataFrame(bs).query("metric in ['macro_f1','recall_10','emission_coverage_10']").to_string(index=False))

def figures(baselines,seedmeans,rotations,curves):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                         'axes.spines.right':False,'savefig.dpi':220})
    colors={'FedAvg':'#607585','StalenessAware':'#138b87','Combined':'#cc7143'}
    cells=[('primary','moderate'),('primary','severe'),('no_annual','moderate')]
    labels=['Annual time at sea\nModerate lag','Annual time at sea\nSevere lag','Annual inputs removed\nModerate lag']
    fig,axes=plt.subplots(1,2,figsize=(12,4.4))
    for ax,metric,title in zip(axes,['stress_nll_damage','stress_recall10_loss'],
                              ['Cumulative test NLL damage during stress','Mean loss in high-emitter recall at 10% budget']):
        for j,method in enumerate(colors):
            vals=[ci(seedmeans.loc[(seedmeans.regime==reg)&(seedmeans.severity==sev)&(seedmeans.method==method),metric])
                  for reg,sev in cells]
            m=np.array([v[0] for v in vals]);low=m-np.array([v[1] for v in vals]);high=np.array([v[2] for v in vals])-m
            ax.errorbar(np.arange(3)+(j-1)*.16,m,yerr=[low,high],fmt='o',capsize=3,
                        color=colors[method],label=method)
        ax.axhline(0,color='#999',lw=.7);ax.set_xticks(range(3),labels);ax.set_title(title,fontsize=10)
        ax.grid(axis='y',alpha=.2)
    axes[0].set_ylabel('NLL difference summed over 10 rounds')
    axes[1].set_ylabel('Recall loss (fraction; lower is better)')
    axes[0].legend(frameon=False,fontsize=8)
    fig.suptitle('Exploratory stress and management consequences | 10 seeds, 5 rotated lag assignments',fontsize=12)
    fig.tight_layout();fig.savefig(OUT/'01_stress_and_screening.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.6),sharey=True)
    marks=['o','s','^','D','v','P']
    for ax,regime,title in zip(axes,['primary','no_annual'],['Annual time at sea retained','Annual MRV inputs removed']):
        for marker,method in zip(marks,['FedAvg','CentralMLP','LocalPersonalized','RandomForest','Logistic','ShipTypeRule']):
            g=baselines.query('regime==@regime and method==@method')
            means=[g[f'recall_{b}'].mean() for b in [5,10,20]]
            ax.plot([5,10,20],means,marker=marker,label=method,lw=1.3)
        ax.plot([5,10,20],[.05,.10,.20],'k:',label='Random selection (approx.)')
        ax.set_title(title);ax.set_xlabel('Review budget (% of vessels)');ax.set_xticks([5,10,20]);ax.grid(alpha=.2)
    axes[0].set_ylabel('Recall of highest annual CO2 quintile');axes[1].legend(frameon=False,fontsize=8)
    fig.suptitle('Clean-condition screening at round 60 | Retrospective annual-data audit, not future forecasting')
    fig.tight_layout();fig.savefig(OUT/'02_clean_screening_baselines.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.2))
    for ax,severity in zip(axes,['moderate','severe']):
        for method in colors:
            g=rotations.query('regime=="primary" and severity==@severity and method==@method')
            ax.plot(g.rotation,g.stress_recall10_loss,'o-',label=method,color=colors[method])
        ax.axhline(0,color='#999',lw=.7);ax.set_title(severity.capitalize()+' lag');ax.set_xlabel('Cyclic assignment rotation')
        ax.set_xticks(range(5));ax.grid(alpha=.2)
    axes[0].set_ylabel('Mean stress-period recall loss at 10% budget');axes[0].legend(frameon=False,fontsize=8)
    fig.suptitle('Sensitivity to which ship type receives the largest delay')
    fig.tight_layout();fig.savefig(OUT/'03_rotation_sensitivity.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.3))
    for ax,severity in zip(axes,['moderate','severe']):
        for method in colors:
            x=curves.query('regime=="primary" and severity==@severity and method==@method')
            x=x.groupby(['seed','round']).nll_delta.mean().unstack('round')
            rng=np.random.default_rng(903);boot=x.to_numpy()[rng.integers(0,len(x),(3000,len(x)))].mean(1)
            rounds=x.columns.to_numpy();ax.plot(rounds,x.mean(axis=0),color=colors[method],label=method)
            ax.fill_between(rounds,np.quantile(boot,.025,axis=0),np.quantile(boot,.975,axis=0),alpha=.12,color=colors[method])
        ax.axvspan(11,20,color='#f2d2be',alpha=.35);ax.axhline(0,color='#999',lw=.7)
        ax.set_title(severity.capitalize()+' lag');ax.set_xlabel('Training round');ax.grid(alpha=.2)
    axes[0].set_ylabel('Test NLL minus method-matched clean trajectory');axes[0].legend(frameon=False,fontsize=8)
    fig.suptitle('Recovery extended to round 60 | Shaded bands describe seed uncertainty')
    fig.tight_layout();fig.savefig(OUT/'04_recovery_to_round60.png');plt.close(fig)

if __name__=='__main__':main()
