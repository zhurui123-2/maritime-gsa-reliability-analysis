# Supplementary code update 27 October 2026

Original code entries are retained unchanged. Added executed sources, frozen
configuration, and the unmodified historical core are under
`weather_free_validation_20261027/`.

Extract this code ZIP and the companion data ZIP into the same directory. To
check the new evidence is present without recomputing any statistics, run:

    python verify_weather_free_package.py

To regenerate the archived statistics separately when required, run:

    python run_weather_free_reanalysis.py

That optional command uses NumPy and pandas, reads the derived outputs in the
companion data archive, and runs no model training. Retraining requires the
authorized linked cohort and local path routing documented in the frozen plan.

Table14 copies saved means,paired differences,unadjusted95% intervals and
Holm-adjusted p-values directly from the archived recovery test output.
The update adds no experiment,seed,bootstrap draw or new statistical estimate.
