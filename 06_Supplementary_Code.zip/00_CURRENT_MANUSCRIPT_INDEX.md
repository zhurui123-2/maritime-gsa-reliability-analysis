# Current manuscript and experiment index — 19 November 2026

Manuscript: Version staleness disrupts vessel emissions assessment: Reliability and update strategies in federated learning

This index supersedes historical manuscript titles and figure/table numbers in older README files. Original numerical records, code, and historical provenance remain unchanged. Filenames such as Data_Tables/Fig05_data.csv are historical identifiers, not automatically the current Figure 5.

| Experiment | Current location | Data archive location |
|---|---|---|
| Weather-free severity; seeds 57–66; 1,172 and 1,155 cohorts separately; 280 trajectories including 160 reused | Main 5.1.1; S14 | weather_free_validation_20261027/analysis/dose_eight_paired_tests.csv |
| Weather-free recovery; seeds 3001–3010; two cohorts; 200 trajectories | Main Fig. 5, Table 4; Table S18 | weather_free_validation_20261027/analysis/recovery_twelve_paired_tests.csv |
| Full-year weather-free screening; 1,155 vessels; seeds 57–66; 24/231 slots; fixed lag assignment | Main Table 5; S12.1 | current/quality_screening/analysis/ |
| Linked-input primary mechanism; seeds 57–66; 180 trajectories | Main Figs. 6–9; Tables 8–9; S10 | current/new_primary/ |
| Gated screening; 1,172 vessels; seeds 1001–1010; 450 stress runs, five rotations; exponential 0.70 and full-rank GSA | Main Tables 6–7; S1–S6, S15.3 | Data_Tables/all_450_runs.csv; Data_Tables/primary_paired_tests_12.csv; Data_Tables/*management*; Data_Tables/fleet* |
| Learned projection GSA; seeds 2001–2010; 600 stress runs | S7, Tables S10–S12 | Data_Tables/projection* |
| Linked-input recovery; seeds 3001–3010; 100 trajectories | Main Table 10; S8, Table S13 | Data_Tables/recovery* |
| Fixed-backbone weighting/reference sensitivity; seeds 4001–4020; 520 trajectories | Main Table 11; S11 | current/fixed_backbone/ |
| Weather-free cohort quality contrasts; seeds 57–66; 160 trajectories | Main Table 12; S12 | current/quality/ |
| Development and ablation; seeds 42–46 | Main 5.4; S15.1–S15.2; Fig. S6; Tables S19–S20 | current/development/ |
| Secondary audits; seeds 67–69; includes near-target fuel covariates | S9; Fig. S5; Tables S14–S16 | Historical outputs retained in current/new_primary/; audit correspondence requires protocol-specific inspection |

Do not pool seed blocks as independent fleets. The 80 full-year screening trajectories replay previous quality trajectories with additional read-only measurements. The 160 reused severity trajectories are not new runs. Do not sum all protocol counts to claim independent experiments or vessels.

The primary backbone uses 24/16 encoders, masked concatenation, reciprocal weights and rank-eight/eight-bin GSA. The gated extension uses 32/16 encoders, gating, exponential 0.70 weights and full-rank GSA. Learned projection GSA is a third distinct implementation. The no-time-at-sea sensitivity condition differs from full annual-block removal.

Extract both data and code ZIPs into the same directory for reanalysis. See README_CODE_20261027.md for existing entry points. Full retraining requires authorized access to the linked cohort; derived outputs do not substitute for that cohort.

This packaging audit checks archive integrity, document pairing, caption numbering and selected headline values; it is not a rerun of training or full statistical replication.
