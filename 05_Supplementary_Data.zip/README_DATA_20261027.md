# Supplementary data update 27 October 2026

The original supplementary-data entries are retained unchanged. New records are
under `weather_free_validation_20261027/` and are part of this formal data file.

- results/dose/runs:120 new30-round trajectories.
- results/recovery/runs:200 new60-round trajectories, comprising160 stressed
  trajectories and40 clean references across two cohorts.
- results/all_new_rounds.csv:15,600 new round records.
- results/all_new_test_results.csv:320 formal trajectory summaries.
- inputs/reused_quality_rounds.csv:4,800 archived round records from160 reused
  weather-free trajectories. They are not320 additional training runs.
- analysis/recovery_twelve_paired_tests.csv:the saved12-contrast recovery tests,
  including the Table14 weighting-versus-FedAvg and incremental-GSA contrasts.
- analysis/dose_eight_paired_tests.csv:the saved8-contrast severity tests.

The companion code ZIP uses the same directory prefix. Extract both ZIPs into
one directory to reproduce statistics using its documented analysis entry point.
No confidence interval or p-value was recalculated for this packaging update.
