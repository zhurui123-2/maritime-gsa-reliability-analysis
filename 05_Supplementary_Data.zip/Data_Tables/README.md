# Supplementary Data

Manuscript: Reliability and recovery of collaborative maritime analytics under delayed model updates

The independent screening extension uses one linked cohort of 1,172 vessels, seeds 1001–1010, five cyclic delay assignments, and a 60-round horizon. The archive contains derived summaries for the 450 stress trajectories and their management and fleet outcomes.

Input conditions: `primary` denotes annual operating inputs retained in this extension; `no_annual` denotes the annual MRV block disabled. Client order is bulk, container, general_cargo, passenger, tanker. Moderate and severe lag vectors are [0,1,2,3,4] and [0,2,4,6,8].

## Files and units

- `clean_management_outcomes.csv`: means and descriptive 95% seed-bootstrap intervals for missed-high-emitter rate, emission coverage, and oracle-relative ranking shortfall at the 10% review budget. Values are percentages. Corresponds to Supplementary Table S6. The duplicate main screening table was removed when the main focus returned to reliability and recovery.
- `stress_management_outcomes.csv`: recall loss, coverage loss, and increase in relative oracle shortfall, averaged over stress rounds 11–20 against matched clean trajectories. Values and intervals are in percentage points. Corresponds to Supplementary Table S7.
- `management_paired_differences.csv`: within-seed method contrasts for those outcomes, in percentage points, after averaging rotations.
- `fleet_nll_and_paired_differences.csv`: fleet-specific test NLL at round 20 and paired weighting-minus-FedAvg differences. Corresponds to Table S8 and Fig. S4a.
- `fleet_aggregation_weights.csv`: sample-size weights and means and minimum–maximum ranges of normalized stress-period weights. All weights are percentages. Corresponds to Table S9 and Fig. S4b.
- `primary_paired_tests_12.csv`: the 12 principal NLL-damage and recall-loss comparisons, including exact sign-flip p values and the Holm adjustment. Recall differences in this source table are fractions.
- `baseline_by_seed.csv`: per-seed clean baselines, including 5%, 10%, and 20% budgets. Recall, precision, coverage, and regret fields are fractions.
- `rotation_summary.csv`: outcome means for each cyclic assignment. Management fields use fractions.
- `all_450_runs.csv`: one summary per stress trajectory. Management fields use fractions; NLL damage is summed over stress rounds.
- `recovery_curves.csv`: per-round stressed-minus-clean test NLL, for all seeds, assignments, and methods.

## Definitions

At budget b, the list contains ceil(b × 235) test vessels, ranked by predicted membership in the highest CO2 quintile. Missed-high-emitter rate is 1 minus highest-quintile recall. Emission coverage is selected annual emissions divided by total test-fleet annual emissions. Relative oracle shortfall is (oracle-selected emissions minus model-selected emissions) divided by oracle-selected emissions, using the same list size. Ties are broken by vessel identifier.

Descriptive intervals use 10,000 percentile bootstrap samples of seeds, with random seed 90210. For stressed outcomes and fleet errors, the five assignments are averaged within each seed before bootstrap or pairing. Weight ranges describe variation across assignments. The principal tests retain their specified 12-comparison Holm family.

The Combined method in these extension tables uses full-rank normalized squared-singular-value calibration, as described in main Section 4.9 and Supplementary Table S2. The Supplementary Code archive provides its executed source and worker protocols.

Files prefixed projection_ describe the separate four-method projection-space GSA comparison (seeds 2001–2010). projection_direct_management_summary.csv supplies Supplementary Table S12; projection_all_primary_tests_24.csv supplies Tables S10–S11. All 600 stress trajectories are retained in projection_all_600_runs.csv. GSA alone and GSA plus delay weighting are separate configurations. Intervals are descriptive unless interpreted with the paired tests; Holm adjustment covers all 24 new component comparisons.


## Recovery extension

Files prefixed recovery_ describe seeds3001–3010, the recovered primary SVD-GSA implementation, and single versus recurrent severe delay. The four primary method-by-pattern contrasts use positive cumulative validation-NLL excess over20 rounds after the final disruption, paired seed-bootstrap intervals, exact sign-flip tests, and Holm adjustment. Values are NLL-round units; negative paired differences favor GSA. Main Table11 summarizes these recovery outcomes, and Supplementary TableS13 reports the four paired tests. These new runs do not restore the original seed57–66 raw outputs.
